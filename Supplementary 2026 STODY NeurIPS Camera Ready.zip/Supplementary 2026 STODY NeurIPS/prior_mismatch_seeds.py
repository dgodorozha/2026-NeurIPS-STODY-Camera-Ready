"""Replicated prior mismatch (Appendix D, "Forward diagnostics").

The prior mismatch in the tables is computed from one forward bank per confinement.  Here it is
recomputed from the three forward banks that trained the three networks of each model (the
training seeds of experiments_cr.py and experiments_h3.py), each against an independent sample
of mu_c of the same size, so that the diagnostic carries the same replication as the generation
results.  Also reports the fit of log(mismatch) against lambda_1(c) T for the confinements at
which the mismatch is above estimator noise.

usage: python3 prior_mismatch_seeds.py       -> prior_mismatch_seeds.json (A, B, H^3, C, W)
"""
import json
import numpy as np
import experiments as ex, experiments_cr as cr, experiments_h3 as h3

LAM2 = {0.25: 0.037881362393303836, 0.5: 0.17618098152649228, 1.0: 0.5645125369059695, 2.0: 1.4735740957514316, 4.0: 3.4117969389386267}
LAM3 = {0.5: 0.0346, 1.0: 0.2683, 2.0: 1.0324, 4.0: 2.8691, 8.0: 6.7729}

out = {}
for hier in ["A", "B"]:
    Xtr, Xte, centres, W, bw = cr.setup(hier)
    out[hier] = {}
    for c in [0.25, 0.5, 1.0, 2.0, 4.0]:
        vals = []
        for idx in range(3):
            tseed, _ = cr.seeds(hier, f"c{c}", idx)
            endp = ex.simulate_paths(Xtr, c, ex.H2, ex.K2, np.random.default_rng(tseed))[-1]
            P = ex.sample_prior(c, 4096, np.random.default_rng(7 + idx))
            vals.append(float(cr.mmd2_laplace(endp[:4096], P, bw)))
        out[hier][str(c)] = {"values": vals, "mean": float(np.mean(vals)), "std": float(np.std(vals, ddof=1)), "lambda1T": LAM2[c] * ex.T2}
        print(f"[{hier} c={c}] mismatch x1e3: {np.round(np.array(vals)*1e3, 2)}  mean {np.mean(vals)*1e3:.2f} +- {np.std(vals, ddof=1)*1e3:.2f}", flush=True)
Xtr, Xte, centres, W, sig2 = h3.setup()
out["H3"] = {}
for c in [0.5, 1.0, 2.0, 4.0, 8.0]:
    vals = []
    for idx in range(3):
        tseed = h3.BASE[f"c{c}"] + 1000 * idx
        endp = h3.simulate_paths(Xtr, c, h3.H2, h3.K2, np.random.default_rng(tseed))[-1]
        P = h3.sample_prior(c, 4096, np.random.default_rng(7 + idx))
        vals.append(float(h3.mmd2(endp[:4096], P, sig2)))
    out["H3"][str(c)] = {"values": vals, "mean": float(np.mean(vals)), "std": float(np.std(vals, ddof=1)), "lambda1T": LAM3[c] * h3.T2}
    print(f"[H3 c={c}] mismatch x1e3: {np.round(np.array(vals)*1e3, 2)}  mean {np.mean(vals)*1e3:.2f} +- {np.std(vals, ddof=1)*1e3:.2f}", flush=True)

# hierarchies C and W: three banks of 8,192 training points each (the prior() stage uses the first 8,192 points
# with one seed; here the banks are seeded with the training seeds of the first three networks)
import experiments_tree as Tm, experiments_wordnet as Wm
for key, mod in [("C", Tm), ("W", Wm)]:
    Xtr, Xte, centres, Wt, bw = mod.setup()
    out[key] = {}
    for c in [0.25, 0.5, 1.0, 2.0, 4.0]:
        vals = []
        for idx in range(3):
            tseed = mod.BASE[f"c{c}"] + 1000 * idx
            endp = ex.simulate_paths(Xtr[:8192], c, ex.H2, ex.K2, np.random.default_rng(tseed))[-1]
            P = ex.sample_prior(c, 4096, np.random.default_rng(7 + idx))
            vals.append(float(cr.mmd2_laplace(endp[:4096], P, bw)))
        out[key][str(c)] = {"values": vals, "mean": float(np.mean(vals)), "std": float(np.std(vals, ddof=1)), "lambda1T": LAM2[c] * ex.T2}
        print(f"[{key} c={c}] mismatch x1e3: {np.round(np.array(vals)*1e3, 2)}  mean {np.mean(vals)*1e3:.2f} +- {np.std(vals, ddof=1)*1e3:.2f}", flush=True)

# slope of log(mismatch) against lambda_1 T over the confinements with mismatch > 1e-4 (above noise)
for key in ["A", "B", "H3", "C", "W"]:
    pts = [(v["lambda1T"], v["mean"]) for v in out[key].values() if v["mean"] > 1e-4]
    if len(pts) >= 2:
        x = np.array([p[0] for p in pts]); y = np.log(np.array([p[1] for p in pts]))
        slope = np.polyfit(x, y, 1)[0]
        out[key]["slope_log_mismatch_vs_lambda1T"] = float(slope)
        print(f"[{key}] slope of log mismatch against lambda_1 T over {len(pts)} points: {slope:.3f}  (MMD^2 scale e^(-2 lambda_1 T) predicts -2)")
json.dump(out, open("prior_mismatch_seeds.json", "w"), indent=1)
