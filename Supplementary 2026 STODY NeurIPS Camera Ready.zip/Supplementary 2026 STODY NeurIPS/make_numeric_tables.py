"""Write the numerical check tables of Appendix C from the verification results:

  tab_largec.tex  from largec_table.json     (verify3.py)   Table 7, strong confinement
  tab_lower.tex   from lowerbound_table.json (verify4.py)   Table 8, constants of Theorem 3.7
  tab_sharp.tex   from fem.json              (fem_lambda.py) Table 9, weak confinement on H^2

Gaps below 1e-8 are limited by rounding in the double precision solvers; for those entries the
tables use the 40 digit solve of the same discretisation in extended.json (check_extended.py).

usage: python3 make_numeric_tables.py
"""
import json, math, os

EXT = json.load(open("extended.json")) if os.path.exists("extended.json") else {"table8": {}, "table9": {}}


def sci(x, d=2):
    """x as $a\\times10^{b}$ with d significant digits, or fixed notation when 1e-3 <= |x| < 1e4."""
    if x == 0: return "$0$"
    e = int(math.floor(math.log10(abs(x))))
    if -2 <= e < 4:
        if e >= 2: return f"${x:.1f}$" if e == 2 else f"${x:.0f}$"
        return f"${x:.4f}$" if e <= -1 else f"${x:.3f}$"
    m = x / 10 ** e
    return f"${m:.{d}f}\\times10^{{{e}}}$"


def table_largec():
    d = json.load(open("largec_table.json"))
    L = [r"\begin{tabular}{@{}lcccc@{\hspace{1.4em}}cccc@{}}", r"\toprule",
         r" & \multicolumn{4}{c}{$\HH^2$, $\ -2(n-1)/3=-0.667$} & \multicolumn{4}{c}{$\HH^3$, $\ -2(n-1)/3=-1.333$} \\",
         r"\cmidrule(lr){2-5}\cmidrule(l){6-9}",
         r"$c$ & $c-(n-1)$ & $\lambda_1(c)$ & bound & $\lambda_1(c)-c$ & $c-(n-1)$ & $\lambda_1(c)$ & bound & $\lambda_1(c)-c$ \\", r"\midrule"]
    for r2, r3 in zip(d["2"], d["3"]):
        assert r2["c"] == r3["c"]
        cells = [f"${r2['c']:g}$"]
        for r in (r2, r3):
            cells += [f"${r['BE']:g}$", f"${r['lam1']:.4f}$", f"${r['bound']:.4f}$", f"${r['lam1'] - r['c']:.4f}$"]
        L.append(" & ".join(cells) + r" \\")
    L += [r"\bottomrule", r"\end{tabular}"]
    open("tab_largec.tex", "w").write("\n".join(L) + "\n")


def table_lower():
    rows = json.load(open("lowerbound_table.json"))
    L = [r"\begin{tabular}{@{}lccccccc@{}}", r"\toprule",
         r"$n$ & $c$ & $\kappa_c$ & $D_c$ & $W_B$ & bound of Theorem~\ref{thm:lower} & $\lambda_1(c)$ & ratio \\", r"\midrule"]
    for r in rows:
        if r["lam1"] <= 0: continue                      # n = 3, c = 0.05: below solver precision (benign in verify4.py)
        wb = r["W_B"]
        wbs = sci(wb) if wb >= 1e4 else (f"${wb:.0f}$" if wb >= 1000 else (f"${wb:.1f}$" if wb >= 100 else (f"${wb:.2f}$" if wb >= 10 else f"${wb:.3f}$")))
        lam = EXT["table8"].get(f"{r['n']},{r['c']:g}", r["lam1"]); low = r["low"]   # extended precision below 1e-8
        lams = f"${lam:.4f}$" if lam >= 1e-2 else sci(lam)
        lows = f"${low:.4f}$" if low >= 1e-2 else sci(low)
        L.append(f"${r['n']}$ & ${r['c']}$ & ${r['kappa']:.4f}$ & ${r['D']:.4f}$ & {wbs} & {lows} & {lams} & ${lam / low:.2f}$ \\\\")
    L += [r"\bottomrule", r"\end{tabular}"]
    open("tab_lower.tex", "w").write("\n".join(L) + "\n")


def table_sharp():
    d = json.load(open("fem.json"))["sharpness"]["2"]
    pts = sorted((r["c"], r["lam1"], r["ratio"]) for r in d)
    pts = [p for p in pts if p[0] >= 0.025]            # c = 0.02 is at the precision limit of the solver (Appendix C)
    env = lambda c: math.sqrt(c) * math.exp(-1 / (2 * c))
    pts = [(c, EXT["table9"][str(c)], EXT["table9"][str(c)] / env(c)) if str(c) in EXT["table9"] else (c, lam, ratio)
           for c, lam, ratio in pts]                   # extended precision below 1e-8
    half = (len(pts) + 1) // 2
    L = [r"\begin{tabular}{@{}lcc@{\hspace{2em}}lcc@{}}", r"\toprule",
         r"$c$ & $\lambda_1(c)$ & ratio & $c$ & $\lambda_1(c)$ & ratio \\", r"\midrule"]
    def cell(c, lam, ratio):
        lams = f"${lam:.4f}$" if lam >= 1e-3 else sci(lam)
        return f"${c:g}$ & {lams} & ${ratio:.3f}$"
    for i in range(half):
        left = cell(*pts[i]); right = cell(*pts[i + half]) if i + half < len(pts) else " & & "
        L.append(left + " & " + right + r" \\")
    L += [r"\bottomrule", r"\end{tabular}"]
    open("tab_sharp.tex", "w").write("\n".join(L) + "\n")


if __name__ == "__main__":
    table_largec(); table_lower(); table_sharp()
    print("tab_largec.tex tab_lower.tex tab_sharp.tex")
