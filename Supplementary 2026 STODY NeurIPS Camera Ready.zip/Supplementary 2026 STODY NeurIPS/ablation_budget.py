"""Parameterisation ladder against training budget (frame inputs), with and without the
sampler's step cap. Deterministic given the seeds; writes ablation_budget.json."""
import json, numpy as np, experiments as ex
import ablation_cr as ab
from experiments_cr import setup, evaluate
Xtr, Xte, centres, W, bw = setup("A")
paths = ex.simulate_paths(Xtr, ab.C, ex.H2, ex.K2, np.random.default_rng(21))
res = {}
ab.INPUTS = "frame"
for iters in [0, 500, 2000, 6000]:
    ab.ITERS = iters
    for head in ["ambient_unanchored", "ambient_anchored", "frame_anchored"]:
        net = ab.train(head, paths, ex.H2, ex.T2, seed=21) if iters > 0 else ex.MLP(ab.DIN, 128, 2 if head == "frame_anchored" else 3, np.random.default_rng(21))
        for caps in [True, False]:
            ab.CAPS = caps
            S = ab.sample(head, net, ex.H2, ex.K2, ex.T2, 4096, np.random.default_rng(121))
            r = evaluate(S, Xte, centres, W, bw)
            res[f"frame|{iters}|{head}|{'caps' if caps else 'nocaps'}"] = r
            print(f"iters={iters:5d} {head:19s} {'caps  ' if caps else 'nocaps'}: MMD2 {r['mmd2']:.4f} TV {r['leaf_tv']:.3f} diverged {100*r['frac_r_gt6']:5.1f}%", flush=True)
json.dump(res, open("ablation_budget.json", "w"), indent=1)
print("saved")
