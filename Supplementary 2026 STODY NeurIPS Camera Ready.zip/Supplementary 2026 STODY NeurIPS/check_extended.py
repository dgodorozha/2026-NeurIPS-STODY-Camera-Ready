"""Extended precision check of the smallest spectral gaps (Tables 6 and 9).

The finite element solves of check_intertwine.py and fem_lambda.py run in double precision.  For
gaps below about 1e-9 the shift and invert solve loses accuracy to rounding: on H^5 at c = 0.25 it
returns 6.01e-10, and refining the grid moves the value by up to 2% instead of converging.  This
script assembles the same linear finite element matrices (uniform grid on [0, R], two point Gauss
rule, weight sinh^{n-1}(s) e^{-c s^2/2}) in 40 digit arithmetic with mpmath and solves them by
inverse iteration with an exact tridiagonal solver, so the result depends only on the
discretisation.  It reports

  * the first harmonic gap lambda^(1)(c) (Dirichlet condition at the origin) and the radial gap
    lambda^(0)(c) - c (natural boundary conditions, constants removed), which agree as
    Proposition 3.3 requires;
  * the upper bound Var(r)^{-1} - c of Corollary 3.4 by quadrature, and the ratio;
  * the gaps below 1e-8 of Tables 8 and 9 (H^3 at c = 0.1; H^2 at c = 0.025 and 0.03), which
    make_numeric_tables.py takes from extended.json in place of the double precision values.

usage: python3 check_extended.py          -> extended.json   (about three minutes on one core)
"""
import json
import mpmath as mp

mp.mp.dps = 40


def weight(c, n):
    return lambda s: mp.sinh(s) ** (n - 1) * mp.exp(-c * s * s / 2)


def assemble(c, n, N, R, ell):
    """Tridiagonal stiffness (A) and mass (B) matrices; ell > 0 adds ell/sinh^2 and a Dirichlet node at 0."""
    w = weight(c, n)
    h = R / N
    nodes = [h * k for k in range(N + 1)]
    g1, g2 = mp.mpf(1) / 2 - mp.sqrt(3) / 6, mp.mpf(1) / 2 + mp.sqrt(3) / 6
    dA = [mp.mpf(0)] * (N + 1); dB = [mp.mpf(0)] * (N + 1)
    oA = [mp.mpf(0)] * N; oB = [mp.mpf(0)] * N
    for e in range(N):
        a, b = nodes[e], nodes[e + 1]
        for t in (g1, g2):
            q = a + t * h
            wq = w(q) * h / 2
            V = ell / mp.sinh(q) ** 2 if ell > 0 else 0
            pA, pB = (b - q) / h, (q - a) / h
            s = wq / h ** 2
            dA[e] += s + wq * V * pA * pA; dB[e] += wq * pA * pA
            dA[e + 1] += s + wq * V * pB * pB; dB[e + 1] += wq * pB * pB
            oA[e] += -s + wq * V * pA * pB; oB[e] += wq * pA * pB
    if ell > 0:                       # Dirichlet condition at the origin: drop node 0
        return dA[1:], oA[1:], dB[1:], oB[1:]
    return dA, oA, dB, oB


def tri_solve(d, o, rhs):
    n = len(d); cp = [mp.mpf(0)] * n; dp = [mp.mpf(0)] * n
    cp[0] = o[0] / d[0]; dp[0] = rhs[0] / d[0]
    for i in range(1, n):
        den = d[i] - o[i - 1] * cp[i - 1]
        if i < n - 1: cp[i] = o[i] / den
        dp[i] = (rhs[i] - o[i - 1] * dp[i - 1]) / den
    x = [mp.mpf(0)] * n; x[-1] = dp[-1]
    for i in range(n - 2, -1, -1): x[i] = dp[i] - cp[i] * x[i + 1]
    return x


def matvec(d, o, x):
    n = len(d); y = [d[i] * x[i] for i in range(n)]
    for i in range(n - 1):
        y[i] += o[i] * x[i + 1]; y[i + 1] += o[i] * x[i]
    return y


def dot(x, y): return mp.fsum(a * b for a, b in zip(x, y))


def gap(c, n, N, R, ell, iters=6):
    """Lowest eigenvalue of the first harmonic sector (ell = n-1), or the lowest nonzero radial one (ell = 0)."""
    dA, oA, dB, oB = assemble(c, n, N, R, ell)
    sigma = 0 if ell > 0 else mp.mpf(0.9) * c       # radial: shift near c, away from the constants
    d = [a - sigma * b for a, b in zip(dA, dB)]; o = [a - sigma * b for a, b in zip(oA, oB)]
    m = len(dA); x = [mp.mpf(k + 1) / m for k in range(m)]
    one = [mp.mpf(1)] * m; B1 = matvec(dB, oB, one); n1 = dot(one, B1)
    for _ in range(iters):
        y = tri_solve(d, o, matvec(dB, oB, x))
        if ell == 0:                                  # remove the constant component
            a = dot(B1, y) / n1; y = [yi - a for yi in y]
        nrm = mp.sqrt(dot(y, y)); x = [yi / nrm for yi in y]
    return dot(x, matvec(dA, oA, x)) / dot(x, matvec(dB, oB, x))


def var_bound(c, n):
    w = weight(c, n); peak = (n - 1) / c
    pts = [0, peak / 4, peak / 2, peak, 1.5 * peak, max(mp.mpf(9), peak + 30 / mp.sqrt(c))]
    Z = mp.quad(w, pts); m1 = mp.quad(lambda s: s * w(s), pts) / Z; m2 = mp.quad(lambda s: s * s * w(s), pts) / Z
    return 1 / (m2 - m1 ** 2) - c


if __name__ == "__main__":
    out = {"table6": {}, "table8": {}, "table9": {}}
    print("Table 6 entries below 1e-5 (R = max(9, (n-1)/c + 10/sqrt(c)), 12,000 and 24,000 elements)")
    for n, c in [(5, mp.mpf("0.25")), (4, mp.mpf("0.25"))]:
        R = max(mp.mpf(9), (n - 1) / c + 10 / mp.sqrt(c))
        b = var_bound(c, n)
        for N in (12000, 24000):
            l1 = gap(c, n, N, R, n - 1); l0 = gap(c, n, N, R, 0)
            print(f"  n={n} c={float(c)} N={N}:  lambda^(1) = {mp.nstr(l1, 8)}   lambda^(0) - c = {mp.nstr(l0 - c, 8)}"
                  f"   residual = {mp.nstr(l0 - l1 - c, 3)}   bound Var^-1 - c = {mp.nstr(b, 8)}   ratio = {mp.nstr(l1 / b, 6)}", flush=True)
            if N == 12000:
                out["table6"][f"{n},{float(c)}"] = {"lam1": float(l1), "residual": float(l0 - l1 - c), "bound": float(b), "ratio": float(l1 / b)}
    print("Table 8 entry below 1e-8 (H^3, c = 0.1, R = (n-1)/c + 12/sqrt(c), 16,000 elements)")
    n, c = 3, mp.mpf("0.1"); R = (n - 1) / c + 12 / mp.sqrt(c)
    l1 = gap(c, n, 16000, R, n - 1); out["table8"]["3,0.1"] = float(l1)
    print(f"  lambda_1 = {mp.nstr(l1, 8)}", flush=True)
    print("Table 9 entries below 1e-8 (H^2, R = 1/c + 12/sqrt(c), 24,000 elements)")
    for c in (mp.mpf("0.025"), mp.mpf("0.03")):
        R = 1 / c + 12 / mp.sqrt(c)
        l1 = gap(c, 2, 24000, R, 1); env = mp.sqrt(c) * mp.exp(-1 / (2 * c))
        out["table9"][str(float(c))] = float(l1)
        print(f"  c={float(c)}: lambda_1 = {mp.nstr(l1, 8)}   ratio to sqrt(c) e^(-1/(2c)) = {mp.nstr(l1 / env, 6)}", flush=True)
    json.dump(out, open("extended.json", "w"), indent=1)
    print("extended.json written")
