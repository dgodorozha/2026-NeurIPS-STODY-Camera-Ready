"""Long horizon relaxation runs on H^2 for the slow confinements (Appendix C, "Observable and fits").

Same polar integrator, initial law, step and particle number as experiments.py experiment1
(r_0 = 3, spread 0.2, h = 0.005, N = 20,000), but with horizons of several relaxation times:
c = 0.25 (1/lambda_1 = 26.4) to T = 120, c = 0.5 (1/lambda_1 = 5.7) to T = 40 and c = 0.1
(1/lambda_1 = 785) to T = 2400.  Rates are least squares slopes of log R(t) on the window
0.05 <= R <= 0.7 (t > 0.05) used for Figure 1, and on the late window 0.05 <= R <= 0.3.
Two independent replicates per confinement.

usage: python3 exp1_long.py            -> exp1_long.json
"""
import json, sys, time
import numpy as np

LAM = {0.1: 0.0012738790850875957, 0.25: 0.037881362393303836, 0.5: 0.17618098152649228}  # FEM, fem_lambda.py
RUNS = [(0.25, 120.0), (0.5, 40.0), (0.1, 2400.0)]
N, h, r0, sig0 = 20000, 0.005, 3.0, 0.2


def run_polar(c, T, seed, thin=20):
    rg = np.random.default_rng(seed)
    K = int(round(T / h))
    r = np.abs(np.full(N, r0) + sig0 * rg.standard_normal(N))
    phi = (sig0 / np.sinh(r0)) * rg.standard_normal(N)
    ts, R = [], []
    for k in range(K + 1):
        if k % thin == 0:
            ts.append(k * h); R.append(float(np.abs(np.exp(1j * phi).mean())))
        if k < K:
            drift = np.clip(1.0 / np.tanh(np.maximum(r, 1e-9)) - c * r, -50.0, 50.0)
            r = np.abs(r + drift * h + np.sqrt(2 * h) * rg.standard_normal(N))
            phi = phi + (np.sqrt(2 * h) / np.sinh(np.maximum(r, 1e-9))) * rg.standard_normal(N)
    return np.array(ts), np.array(R)


def fit(ts, R, lo, hi):
    m = (R >= lo) & (R <= hi) & (ts > 0.05)
    if m.sum() < 5: return float("nan"), int(m.sum()), float("nan")
    p = np.polyfit(ts[m], np.log(R[m]), 1)
    return -float(p[0]), int(m.sum()), float(ts[m].max() - ts[m].min())


if __name__ == "__main__":
    out = {"N": N, "h": h, "r0": r0, "sig0": sig0, "runs": []}
    for c, T in RUNS:
        for rep, seed in enumerate([100 + int(c * 1000), 7100 + int(c * 1000)]):
            t0 = time.time()
            ts, R = run_polar(c, T, seed)
            rate, npts, span = fit(ts, R, 0.05, 0.7)
            rate_late, npts_late, span_late = fit(ts, R, 0.05, 0.3)
            row = {"c": c, "T": T, "seed": seed, "lambda1_fem": LAM[c], "R_T": float(R[-1]),
                   "rate_window": rate, "points_window": npts, "span_window": span, "ratio_window": rate / LAM[c],
                   "rate_late": rate_late, "points_late": npts_late, "span_late": span_late, "ratio_late": rate_late / LAM[c],
                   "t_enter_window": float(ts[np.argmax(R <= 0.7)]) if (R <= 0.7).any() else None,
                   "minutes": (time.time() - t0) / 60}
            out["runs"].append(row)
            print(f"[exp1_long] c={c} T={T} rep={rep}: R(T)={row['R_T']:.4f} enters window at t={row['t_enter_window']}; "
                  f"rate {rate:.5f} (ratio {row['ratio_window']:.3f}, {npts} points over {span:.1f} time units); "
                  f"late rate {rate_late:.5f} (ratio {row['ratio_late']:.3f}); {row['minutes']:.1f} min", flush=True)
            json.dump(out, open("exp1_long.json", "w"), indent=1)
