#!/bin/bash
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python3 experiments_tree.py prior
for m in c1.0 c2.0 c0.25 tangent c0.5 c4.0; do for s in 0 1 2; do python3 experiments_tree.py $m $s; done; done
python3 experiments_tree.py assemble; echo TREE1_DONE
