"""Hierarchy C with a dense angular feature basis: cos k phi, sin k phi for every k = 1..KMAX,
instead of the doublings k = 1, 2, 4, ..., 64 of experiments_tree.py.  Everything else (data,
seeds, width, budget, sampler, metrics) is identical, so the comparison isolates the feature
basis.  Diagnostic for the question whether the leaves within a branch can be resolved at all
at this budget.

usage:  python3 experiments_tree_dense.py <model> <trainseed_index>     (model: c<value> or tangent)
        python3 experiments_tree_dense.py assemble
"""
import json, sys, os, glob
import numpy as np
import experiments as ex
import experiments_tree as T

KMAX = 64

def ang_dense(cs, kmax=KMAX):
    c1, s1 = cs[..., 0], cs[..., 1]
    cos = [np.ones_like(c1), c1]; sin = [np.zeros_like(s1), s1]
    for k in range(2, kmax + 1):            # Chebyshev recurrence, exact in floating point to ~1e-13 at k = 64
        cos.append(2 * c1 * cos[-1] - cos[-2]); sin.append(2 * c1 * sin[-1] - sin[-2])
    return np.stack(cos[1:] + sin[1:], -1)

def feats(x, t, Tt):
    er, ephi, r, cs = ex.frame(x)
    return np.concatenate([T.rad_feats(r), ang_dense(cs), ex.timefeat(t, Tt)], -1), er, ephi, r

def tangent_feats(y, t, Tt):
    ny = np.linalg.norm(y, axis=-1, keepdims=True); cs = y / np.maximum(ny, 1e-12)
    return np.concatenate([y, T.rad_feats(ny[..., 0]), ang_dense(cs), ex.timefeat(t, Tt)], -1)

T.feats, T.tangent_feats = feats, tangent_feats
T.DIN_I, T.DIN_T = 9 + 2 * KMAX + 9, 2 + 9 + 2 * KMAX + 9

def run(model, idx):
    if os.path.exists(f"tree_dense_{model}_s{idx}.json"): print("exists"); return
    Xtr, Xte, centres, W, bw = T.setup()
    tseed = T.BASE[model] + 1000 * idx; sseeds = [tseed + o for o in (100, 200, 300)]
    out = {"model": model, "train_seed": tseed, "samp_seeds": sseeds, "bandwidth": bw, "features": f"dense k=1..{KMAX}"}
    if model == "tangent":
        net = T.train_tangent(Xtr, T=ex.T2, seed=tseed)
        sampler = lambda n, s: T.sample_tangent(net, n, np.random.default_rng(s), T=ex.T2, K=ex.K2)
    else:
        c = float(model[1:])
        paths = ex.simulate_paths(Xtr, c, ex.H2, ex.K2, np.random.default_rng(tseed))
        net = T.train_intrinsic(paths, c, ex.H2, ex.T2, seed=tseed); del paths
        sampler = lambda n, s: T.sample_intrinsic(net, c, ex.H2, ex.K2, ex.T2, n, np.random.default_rng(s))
    sets = [sampler(4096, s) for s in sseeds]
    out["rows"] = [T.evaluate(S, Xte, centres, W, bw) for S in sets]
    np.savez_compressed(f"tree_dense_{model}_s{idx}_samples.npz", *sets)
    json.dump(out, open(f"tree_dense_{model}_s{idx}.json", "w"), indent=1)
    a = np.array([[r["mmd2"], r["leaf_tv"], r["frac_div"]] for r in out["rows"]])
    print(f"[tree dense {model} seed{idx}] MMD2 {a[:,0].mean():.5f}+-{a[:,0].std():.5f}  TV {a[:,1].mean():.3f}  div {a[:,2].mean():.4f}", flush=True)

def assemble():
    res = {}
    for f in sorted(glob.glob("tree_dense_c*_s[0-9].json") + glob.glob("tree_dense_tangent_s[0-9].json")):
        d = json.load(open(f)); res.setdefault(d["model"], {})[str(d["train_seed"])] = d
    summary = {}
    for model, runs in res.items():
        A = np.array([[r["mmd2"], r["leaf_tv"], r["frac_div"]] for d in runs.values() for r in d["rows"]])
        P = np.array([np.mean([[r["mmd2"], r["leaf_tv"], r["frac_div"]] for r in d["rows"]], 0) for d in runs.values()])
        summary[model] = {"n_train": len(runs), "mean": A.mean(0).tolist(), "std_all": A.std(0, ddof=1).tolist(),
                          "std_train": P.std(0, ddof=1).tolist() if len(P) > 1 else [0] * 3, "per_train_mean": P.tolist()}
        print(f"[tree dense {model}] runs={len(runs)} MMD2 {A[:,0].mean():.5f}+-{A[:,0].std(ddof=1):.5f} TV {A[:,1].mean():.3f}+-{A[:,1].std(ddof=1):.3f} div {A[:,2].mean():.4f}")
    res["summary"] = summary; json.dump(res, open("tree_dense_all.json", "w"), indent=1)

if __name__ == "__main__":
    ex.self_test()
    stage = sys.argv[1]
    if stage == "assemble": assemble()
    else: run(stage, int(sys.argv[2]))
