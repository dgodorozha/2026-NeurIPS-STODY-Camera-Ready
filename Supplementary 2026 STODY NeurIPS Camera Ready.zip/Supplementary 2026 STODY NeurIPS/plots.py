import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "pdf.fonttype": 42, "ps.fonttype": 42,  # embed TrueType, not Type 3 (NeurIPS font requirement)
    "font.family": "serif", "font.size": 8.5, "axes.labelsize": 9,
    "axes.titlesize": 9, "legend.fontsize": 7.2, "xtick.labelsize": 8,
    "ytick.labelsize": 8, "figure.dpi": 200, "axes.linewidth": 0.7,
})

E1 = json.load(open("r1.json"))
E2 = json.load(open("res2.json"))
SM = {t: json.load(open(f"samples_{t}.json")) for t in ["data", "c2.0", "c0.25", "tangent"]}

t = np.array(E1["t"])
cs = [0.05, 0.1, 0.25, 0.5, 1.0, 2.0, 4.0]
N = E1["N"]
floor = 1.0 / np.sqrt(N)

# uniform rate fits: log-linear on the window 0.05 <= R <= 0.7
fits = {}
for c in cs:
    R = np.array(E1["R"][str(c)])
    m = (R >= 0.05) & (R <= 0.7) & (t > 0.05)
    if m.sum() >= 5:
        p = np.polyfit(t[m], np.log(R[m]), 1)
        fits[c] = (-p[0], True)
    else:  # decay too slow to leave the window within T: transient-limited estimate
        m2 = t >= t[-1] / 2
        p = np.polyfit(t[m2], np.log(np.maximum(np.array(E1["R"][str(c)])[m2], 1e-12)), 1)
        fits[c] = (-p[0], False)
print("window rate fits:", {c: (round(v, 4), ok) for c, (v, ok) in fits.items()})

fig, ax = plt.subplots(1, 2, figsize=(5.5, 2.42),
                       gridspec_kw={"width_ratios": [1.2, 1.0]})
cmap = plt.cm.viridis(np.linspace(0.05, 0.92, len(cs)))

# ---- panel (a): curves, with the legend lifted clear of the data
lab = ["$c=0.05$", "$0.1$", "$0.25$", "$0.5$", "$1$", "$2$", "$4$"]
for c, col, lb in zip(cs, cmap, lab):
    ax[0].semilogy(t, E1["R"][str(c)], color=col, lw=1.0, label=lb)
ax[0].axhline(floor, color="0.55", lw=0.6, ls=":")
ax[0].text(0.12, floor * 1.3, "MC noise floor", fontsize=6, color="0.4")
ax[0].set_xlabel("$t$")
ax[0].set_ylabel(r"$R(t)=|\,\mathbb{E}\,e^{\mathrm{i}\varphi(t)}|$")
ax[0].set_xlim(0, 6)
ax[0].set_ylim(3.5e-3, 1.45)          # clip the pure noise below the floor
ax[0].legend(ncol=7, loc="lower center", bbox_to_anchor=(0.5, 1.0), frameon=False,
             handlelength=0.75, columnspacing=0.42, handletextpad=0.3,
             fontsize=6.2, borderpad=0.1, borderaxespad=0.0)
ax[0].set_title("(a) angular relaxation, $\\mathbb{H}^2$", fontsize=8.5, pad=15)

# ---- panel (b): axis limited to the measured range so the points are readable
cg = np.geomspace(1.02, 5, 100)
ax[1].loglog(cg, cg - 1, "k-", lw=1.0, label=r"$c-(n-1)$ (BE)")
cs_small = np.geomspace(0.05, 1.0, 100)
ax[1].loglog(cs_small, np.sqrt(cs_small) * np.exp(-1 / (2 * cs_small)), "k--", lw=1.0,
             label=r"$\sqrt{c}\,e^{-1/(2c)}$")
for c, col in zip(cs, cmap):
    v, ok = fits[c]
    if ok:
        ax[1].plot([c], [v], "o", color=col, ms=5.5, zorder=5, mec="0.25", mew=0.5)
    else:
        ax[1].plot([c], [v], "v", color=col, ms=6.5, zorder=5, mfc="none", mew=1.1)
ax[1].plot([], [], "v", color="0.35", ms=6.0, mfc="none", mew=1.1,
           label=r"upper estimate")
ax[1].axvline(1.0, color="0.5", lw=0.6, ls=":")
ax[1].text(1.13, 1.15e1, "$c=n-1$", fontsize=6.5, color="0.35",
           va="center", ha="left")
ax[1].set_xlabel("$c$"); ax[1].set_ylabel("measured rate")
ax[1].set_xlim(0.04, 6.5); ax[1].set_ylim(4e-3, 3e1)
ax[1].legend(frameon=False, loc="upper left", handlelength=1.1,
             fontsize=6.2, labelspacing=0.32, borderaxespad=0.25,
             handletextpad=0.45)
ax[1].set_title("(b) rate vs confinement", fontsize=8.5)
fig.tight_layout(pad=0.4)
fig.savefig("fig_mixing.pdf", bbox_inches="tight")
print("fig_mixing.pdf written")

titles = [("data", "data"), ("c2.0", "intrinsic, $c=2.0>n-1$"),
          ("c0.25", "intrinsic, $c=0.25<n-1$"), ("tangent", "tangent (wrapped)")]
fig2, axs = plt.subplots(1, 4, figsize=(5.5, 1.55))
th = np.linspace(0, 2 * np.pi, 200)
for a, (k, ttl) in zip(axs, titles):
    P = np.array(SM[k])
    a.plot(np.cos(th), np.sin(th), "-", color="0.75", lw=0.7)
    a.scatter(P[:, 0], P[:, 1], s=0.5, c="#1f4e79", alpha=0.5, linewidths=0)
    a.set_xlim(-1.02, 1.02); a.set_ylim(-1.02, 1.02)
    a.set_aspect("equal"); a.axis("off")
    a.set_title(ttl, fontsize=7.3)
fig2.tight_layout(pad=0.25)
fig2.savefig("fig_samples.pdf", bbox_inches="tight")
print("fig_samples.pdf written")
