#!/bin/bash
# Follow-up runs: bigger budget, finer sampler, more seeds, full radius WordNet.
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
(
  python3 experiments_tree_big.py c1.0 0
  for s in 3 4; do for m in c1.0 c2.0 c0.25 tangent c0.5 c4.0; do python3 experiments_tree.py $m $s; done; done
  python3 experiments_tree_fine.py c1.0 0
  for m in c1.0 c0.25 c2.0; do python3 experiments_wordnet_full.py $m 0; done
  echo Q1_DONE
) > run_q1.log 2>&1 &
(
  python3 experiments_tree_big.py tangent 0
  python3 experiments_wordnet_full.py prior
  for s in 3 4; do for m in c1.0 c4.0 c0.5 tangent c0.25 c2.0; do python3 experiments_wordnet.py $m $s; done; done
  python3 experiments_tree_fine.py tangent 0
  for m in tangent c0.5 c4.0; do python3 experiments_wordnet_full.py $m 0; done
  echo Q2_DONE
) > run_q2.log 2>&1 &
wait
(
  python3 experiments_tree.py assemble
  python3 experiments_wordnet.py assemble
  python3 experiments_tree_big.py assemble
  python3 experiments_tree_fine.py assemble
  python3 experiments_wordnet_full.py assemble
  echo SCALE_ALL_DONE
) > run_scale_assemble.log 2>&1
