"""Parameterisation ladder: the three score heads of Table 13 at a fixed budget, with the Laplacian kernel.

Three heads at a reduced budget (6k iterations, single span targets, c = 2.0, the data of
hierarchy A, one training and one sampling seed), identical in every other respect:
  ambient_unanchored : s = P_x w,              w in R^3 from the network
  ambient_anchored   : s = -grad W_c + P_x w
  frame_anchored     : s = -grad W_c + a e_r + b e_phi
Inputs for all three: min(r, 12), cos phi, sin phi and the time embedding.
"""
import json, sys
import numpy as np
import experiments as ex
from experiments_cr import setup, evaluate

ITERS, BS, C = 6000, 512, 2.0

INPUTS = "frame"      # "frame": (min(r,12), cos phi, sin phi, time); "ambient": (x_1, x_2, x_3, time)

def feats_plain(x, t, T):
    er, ephi, r, cs = ex.frame(x)
    if INPUTS == "ambient":
        return np.concatenate([x, ex.timefeat(t, T)], -1), er, ephi, r
    return np.concatenate([np.minimum(r, ex.RFEAT)[..., None], cs, ex.timefeat(t, T)], -1), er, ephi, r

DIN = 3 + 9

def score(head, net, F, x, er, ephi, r):
    out = net.forward(F)
    if head == "frame_anchored":
        return -(C * r)[..., None] * er + out[..., :1] * er + out[..., 1:] * ephi
    pw = out + ex.mink(x, out)[..., None] * x                     # Minkowski projection P_x w
    return pw if head == "ambient_unanchored" else -(C * r)[..., None] * er + pw

def train(head, paths, h, T, seed):
    rg = np.random.default_rng(seed)
    K = paths.shape[0] - 1
    net = ex.MLP(DIN, 128, 2 if head == "frame_anchored" else 3, rg)
    for it in range(ITERS):
        i = rg.integers(0, paths.shape[1], BS); k = rg.integers(0, K, BS)
        xp, xc = paths[k, i], paths[k + 1, i]
        tau = np.full((BS, 1), h)
        g, r = ex.grad_r(xp)
        z = ex.normalize(ex.expmap(xp, -(C * r)[..., None] * g * h))
        tgt = ex.logmap(xc, z) / np.sqrt(2 * tau)
        F, er, ephi, rc = feats_plain(xc, (k + 1) * h, T)
        spred = score(head, net, F, xc, er, ephi, rc)
        e = np.sqrt(2 * tau) * spred - tgt
        w = 2 * np.sqrt(2 * tau)[..., 0] / BS
        if head == "frame_anchored":
            gout = np.stack([w * ex.mink(e, er), w * ex.mink(e, ephi)], -1)
        else:
            gout = w[:, None] * (e * ex.ETA)                           # d<e, P_x w>_L / dw = eta * e
        net.adam(net.backward(gout), lr=1e-3)
        if (it + 1) % 2000 == 0:
            print(f"[{head}] iter {it+1}: loss {float(np.mean(ex.mink(e, e))):.4f}", flush=True)
    return net

CAPS = True

def sample(head, net, h, K, T, n, rng_, dmax=50.0, vcap=0.5):
    if not CAPS: dmax, vcap = 1e12, 1e12
    x = ex.sample_prior(C, n, rng_)
    for k in range(K, 0, -1):
        F, er, ephi, r = feats_plain(x, np.full(n, k * h), T)
        s = score(head, net, F, x, er, ephi, r)
        drift = (C * r)[..., None] * er + 2.0 * s
        nd = np.sqrt(np.maximum(ex.mink(drift, drift), 0.0))
        drift *= np.minimum(1.0, dmax / np.maximum(nd, 1e-12))[..., None]
        v = drift * h + np.sqrt(2 * h) * ex.tangent_gauss(x, rng_)
        nv = np.sqrt(np.maximum(ex.mink(v, v), 0.0))
        v *= np.minimum(1.0, vcap / np.maximum(nv, 1e-12))[..., None]
        x = ex.rwall(ex.normalize(ex.expmap(x, v)))
    return x

if __name__ == "__main__":
    ex.self_test()
    INPUTS = sys.argv[1] if len(sys.argv) > 1 else "frame"
    CAPS = (sys.argv[2] != "nocaps") if len(sys.argv) > 2 else True
    TAG = INPUTS + ("" if CAPS else "_nocaps")
    Xtr, Xte, centres, W, bw = setup("A")
    paths = ex.simulate_paths(Xtr, C, ex.H2, ex.K2, np.random.default_rng(21))
    res = {}
    for head in ["ambient_unanchored", "ambient_anchored", "frame_anchored"]:
        net = train(head, paths, ex.H2, ex.T2, seed=21)
        S = sample(head, net, ex.H2, ex.K2, ex.T2, 4096, np.random.default_rng(121))
        res[head] = evaluate(S, Xte, centres, W, bw)
        np.savez_compressed(f"ablation_{TAG}_{head}_samples.npz", S)
        print(f"[ablation {TAG} inputs, {head}] MMD2 {res[head]['mmd2']:.5f}  TV {res[head]['leaf_tv']:.3f}  "
              f"diverged {100*res[head]['frac_r_gt6']:.1f}%", flush=True)
    json.dump(res, open(f"ablation_cr_{TAG}.json", "w"), indent=1)
