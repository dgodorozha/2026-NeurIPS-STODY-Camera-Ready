"""Tables 1 and 13 to 17 of the paper, built from the assembled result files."""
import json, numpy as np
fem = json.load(open("fem.json"))
lam = {n: {r["c"]: r["lam1"] for r in fem["grid"][str(n)]} for n in (2, 3)}
T = 4.0

def pm(m, s, scale=1e3, d=1):
    return f"${m*scale:.{d}f}\\pm{s*scale:.{d}f}$"

try:
    MIS = json.load(open("prior_mismatch_seeds.json"))      # replicated prior mismatch (prior_mismatch_seeds.py)
except FileNotFoundError:
    MIS = {}

def mismatch_cell(key, P, c, d=1):
    """Prior mismatch x1e3: mean +- sd over the replicated forward banks when available, else the single bank."""
    if key in MIS and str(c) in MIS[key]:
        v = MIS[key][str(c)]
        return f"${v['mean']*1e3:.{d}f}\\pm{v['std']*1e3:.{d}f}$"
    return f"${P[f'prior_mismatch_c{c}']*1e3:.{d}f}$"

def block(S, P, cs, n, key):
    """Rows: mean +- sd over the training seed means, with the sd over all sample sets in parentheses for MMD^2."""
    rows = []
    for c in cs:
        k = f"c{c}"; m, s, st = S[k]["mean"], S[k]["std_all"], S[k]["std_train"]
        rows.append((f"intrinsic, $c={c}$", f"${lam[n][c]*T:.2f}$" if lam[n][c] * T < 100 else f"${lam[n][c]*T:.0f}$",
                     pm(m[0], st[0]) + f" ({s[0]*1e3:.1f})", pm(m[1], st[1], 1, 3), mismatch_cell(key, P, c, 1)))
    k = "tangent"; m, s, st = S[k]["mean"], S[k]["std_all"], S[k]["std_train"]
    rows.append(("wrapped baseline", "--", pm(m[0], st[0]) + f" ({s[0]*1e3:.1f})", pm(m[1], st[1], 1, 3), "--"))
    return rows

def table_h2():
    A = json.load(open("cr_A_all.json")); B = json.load(open("cr_B_all.json"))
    cs = [0.25, 0.5, 1.0, 2.0, 4.0]
    ra, rb = block(A["summary"], A["prior"], cs, 2, "A"), block(B["summary"], B["prior"], cs, 2, "B")
    L = [r"\begin{tabular}{@{}ll ccc@{\hspace{1.2em}}ccc@{}}", r"\toprule",
         r" & & \multicolumn{3}{c}{hierarchy A} & \multicolumn{3}{c}{hierarchy B} \\",
         r"\cmidrule(lr){3-5}\cmidrule(l){6-8}",
         r"model & $\lambda_1(c)T$ & MMD$^2$ ($\times10^3$) & leaf TV & mismatch & MMD$^2$ ($\times10^3$) & leaf TV & mismatch \\",
         r"\midrule"]
    for a, b in zip(ra, rb):
        L.append(f"{a[0]} & {a[1]} & {a[2]} & {a[3]} & {a[4]} & {b[2]} & {b[3]} & {b[4]} \\\\")
    L += [r"\bottomrule", r"\end{tabular}"]
    open("tab_gen.tex", "w").write("\n".join(L) + "\n"); print("\n".join(L))

def table_h3():
    H = json.load(open("h3_all.json"))
    cs = [0.5, 1.0, 2.0, 4.0, 8.0]
    rows = block(H["summary"], H["prior"], cs, 3, "H3")
    L = [r"\begin{tabular}{@{}llccc@{}}", r"\toprule",
         r"model & $\lambda_1(c)T$ & MMD$^2$ ($\times10^3$) & leaf TV & mismatch \\", r"\midrule"]
    for r in rows:
        L.append(" & ".join(r) + r" \\")
    L += [r"\bottomrule", r"\end{tabular}"]
    open("tab_gen_h3.tex", "w").write("\n".join(L) + "\n"); print("\n".join(L))

def table_scale():
    C = json.load(open("tree_all.json")); Wn = json.load(open("wn_all.json"))
    cs = [0.25, 0.5, 1.0, 2.0, 4.0]
    L = [r"\begin{tabular}{@{}llcccc@{}}", r"\toprule",
         r"model & $\lambda_1(c)T$ & MMD$^2$ ($\times10^3$) & leaf or node TV & group TV & mismatch \\"]
    for name, D, tvkey, key in [("hierarchy C ($64$ leaves at depth three)", C, "leaf", "C"),
                                ("hierarchy W ($1170$ WordNet synsets, $39$ groups)", Wn, "node", "W")]:
        L += [r"\midrule", f"\\multicolumn{{6}}{{@{{}}l}}{{\\emph{{{name}}}}} \\\\[1pt]"]
        for c in cs:
            k = f"c{c}"; a = D["summary"][k]
            g = pm(a["mean"][2], a["std_train"][2], 1, 3) if tvkey == "node" else "--"
            L.append(f"intrinsic, $c={c}$ & ${lam[2][c]*T:.2f}$ & {pm(a['mean'][0], a['std_train'][0], 1e3, 2)} ({a['std_all'][0]*1e3:.2f}) & {pm(a['mean'][1], a['std_train'][1], 1, 3)} & {g} & {mismatch_cell(key, D['prior'], c, 2)} \\\\")
        a = D["summary"]["tangent"]
        g = pm(a["mean"][2], a["std_train"][2], 1, 3) if tvkey == "node" else "--"
        L.append(f"wrapped baseline & -- & {pm(a['mean'][0], a['std_train'][0], 1e3, 2)} ({a['std_all'][0]*1e3:.2f}) & {pm(a['mean'][1], a['std_train'][1], 1, 3)} & {g} & -- \\\\")
        f = D["prior"]["floor"]
        L.append(f"sampling floor & -- & ${f['mmd2']*1e3:.2f}$ & ${f[tvkey + '_tv']:.3f}$ & " + (f"${f['group_tv']:.3f}$" if tvkey == "node" else "--") + r" & -- \\")
    L += [r"\bottomrule", r"\end{tabular}"]
    open("tab_gen_scale.tex", "w").write("\n".join(L) + "\n"); print("\n".join(L))

def table_main(only_A=True, with_R4=True, fname="tab_gen_main.tex"):
    """Compact main text table: hierarchy A (and B if only_A is False) across the confinement sweep."""
    A = json.load(open("cr_A_all.json")); B = json.load(open("cr_B_all.json"))
    cs = [0.25, 0.5, 1.0, 2.0, 4.0]
    def row(label, vals):
        return label + " & " + " & ".join(vals) + r" \\"
    L = [r"\begin{tabular}{@{}lccccc@{\hspace{1.2em}}c@{}}", r"\toprule",
         r" & \multicolumn{5}{c}{intrinsic, confinement $c$} & tangent \\",
         r"\cmidrule(lr){2-6}",
         r" & $0.25$ & $0.5$ & $1$ & $2$ & $4$ & (wrapped) \\", r"\midrule",
         row(r"$\lambda_1(c)T$", [f"${lam[2][c]*T:.2f}$" for c in cs] + ["--"])]
    for name, D in ([("A", A)] if only_A else [("A", A), ("B", B)]):
        S, P = D["summary"], D["prior"]
        if not only_A: L.append(r"\multicolumn{7}{@{}l}{\emph{hierarchy " + name + r"}} \\[1pt]")
        L.append(row(r"MMD$^2$ ($\times10^3$)", [pm(S[f"c{c}"]["mean"][0], S[f"c{c}"]["std_train"][0]) for c in cs] + [pm(S["tangent"]["mean"][0], S["tangent"]["std_train"][0])]))
        L.append(row(r"leaf TV", [pm(S[f"c{c}"]["mean"][1], S[f"c{c}"]["std_train"][1], 1, 3) for c in cs] + [pm(S["tangent"]["mean"][1], S["tangent"]["std_train"][1], 1, 3)]))
        L.append(row(r"mismatch ($\times10^3$)", [mismatch_cell(name, P, c, 1) for c in cs] + ["n/a"]))
        if name == "A" and with_R4:
            L.append(row(r"$R_4(T)$ (data $0.765$)", [f"${P[f'forward_R4_c{c}']:.3f}$" for c in cs] + ["n/a"]))
    L += [r"\bottomrule", r"\end{tabular}"]
    open(fname, "w").write("\n".join(L) + "\n"); print("\n".join(L))

def table_main_noR4():
    table_main(only_A=True, with_R4=False, fname="tab_gen_main_noR4.tex")

def table_caps():
    """Sampler caps and reverse step size at fixed trained network (Appendix D), from sampler_caps.json."""
    d = json.load(open("sampler_caps.json"))
    L = [r"\begin{tabular}{@{}llccccccc@{}}", r"\toprule",
         r" & & \multicolumn{2}{c}{$h=0.01$, $K=400$} & \multicolumn{2}{c}{$h=0.005$, $K=800$} & \multicolumn{2}{c}{$h=0.0025$, $K=1600$} \\",
         r"\cmidrule(lr){3-4}\cmidrule(lr){5-6}\cmidrule(l){7-8}",
         r"hierarchy & $c$ & capped steps & MMD$^2$ & capped steps & MMD$^2$ & capped steps & MMD$^2$ \\", r"\midrule"]
    for kind, label, cs in [("A", "A ($\\HH^2$)", [0.25, 0.5, 1.0, 2.0, 4.0]), ("H3", "$\\HH^3$", [0.5, 1.0, 2.0, 4.0, 8.0])]:
        for c in cs:
            key = f"{kind}_c{c}"
            if key not in d: continue
            cells = [label if c == cs[0] else "", f"${c:g}$"]
            for h in ["0.01", "0.005", "0.0025"]:
                v = d[key][h]
                pc = 100 * v['frac_step_cap']
                pcs = "$<0.01\\%$" if 0 < pc < 0.005 else f"${pc:.2f}\\%$"     # nonzero but below the printed precision
                cells += [pcs, f"${v['mmd2_mean']*1e3:.1f}\\pm{v['mmd2_std']*1e3:.1f}$"]
            L.append(" & ".join(cells) + r" \\")
        if kind == "A": L.append(r"\midrule")
    L += [r"\bottomrule", r"\end{tabular}"]
    open("tab_caps.tex", "w").write("\n".join(L) + "\n"); print("\n".join(L))

def table_ablation():
    """Parameterisation ladder against the training budget (Table 13), from ablation_budget.json."""
    import math
    d = json.load(open("ablation_budget.json"))
    heads = [("ambient_unanchored", "extrinsic, unanchored"), ("ambient_anchored", "extrinsic, anchored"), ("frame_anchored", "frame, anchored")]
    L = [r"\begin{tabular}{@{}rccccccccc@{}}", r"\toprule",
         " & " + " & ".join(f"\\multicolumn{{3}}{{c}}{{{lab}}}" for _, lab in heads) + r" \\",
         r"\cmidrule(lr){2-4}\cmidrule(lr){5-7}\cmidrule(l){8-10}",
         r"iterations & MMD$^2$ & leaf TV & diverged & MMD$^2$ & leaf TV & diverged & MMD$^2$ & leaf TV & diverged \\", r"\midrule"]
    def num(x, d_):
        return "--" if x is None or (isinstance(x, float) and math.isnan(x)) else f"{x:.{d_}f}"
    for it in [0, 500, 2000, 6000]:
        cells = [f"${it}$"]
        for head, _ in heads:
            a = d[f"frame|{it}|{head}|caps"]; b = d[f"frame|{it}|{head}|nocaps"]
            cells += [f"${num(a['mmd2'] * 1e3, 1)}$", f"${num(a['leaf_tv'], 3)}$",
                      f"${100 * a['frac_r_gt6']:.1f}/{100 * b['frac_r_gt6']:.1f}\\%$"]
        L.append(" & ".join(cells) + r" \\")
    L += [r"\bottomrule", r"\end{tabular}"]
    open("tab_ablation.tex", "w").write("\n".join(L) + "\n"); print("\n".join(L))

def key_numbers():
    out = {}
    for name, f in [("A", "cr_A_all.json"), ("B", "cr_B_all.json"), ("H3", "h3_all.json")]:
        try: d = json.load(open(f))
        except FileNotFoundError: continue
        S = d["summary"]
        out[name] = {k: (round(v["mean"][0] * 1e3, 2), round(v["std_all"][0] * 1e3, 2), round(v["std_train"][0] * 1e3, 2),
                         round(v["mean"][1], 3), round(v["std_all"][1], 3)) for k, v in S.items()}
        out[name]["mismatch"] = {k: round(v * 1e3, 2) for k, v in d["prior"].items() if k.startswith("prior")}
    json.dump(out, open("key_numbers.json", "w"), indent=1)
    for name, v in out.items():
        print(name); [print("  ", k, x) for k, x in v.items()]

if __name__ == "__main__":
    import sys
    for w in sys.argv[1:]:
        {"h2": table_h2, "h3": table_h3, "scale": table_scale, "main": table_main, "main_noR4": table_main_noR4, "caps": table_caps, "ablation": table_ablation, "keys": key_numbers}[w]()
