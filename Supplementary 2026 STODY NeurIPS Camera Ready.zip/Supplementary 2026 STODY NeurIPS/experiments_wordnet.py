"""Hierarchy W: Poincare embeddings of the WordNet mammal subtree.

The 1170 synsets below mammal.n.01 (879 leaves, depth up to 9, 6448 pairs in the
transitive closure of hypernymy) are embedded in the Poincare disk by the method of
Nickel and Kiela (gensim's PoincareModel: dimension 2, 10 negatives, 10 burn-in and 300
training epochs, seed 0; see make_wordnet_embedding.py).  The trained embedding places
most synsets at hyperbolic radius 8 to 12, so its hyperbolic radius is halved before use
(rho = 0.5), which keeps the angular, tree-like arrangement and brings the data to radius
4 to 6.  Data: all 1170 synsets with equal weight and leaf noise 0.1.  Networks as in
experiments_tree.py with angular Fourier features up to k = 512.  Group TV uses 39 groups:
the 32 depth-two families (carnivore, ungulate, rodent, primate, ...) and, each as its own
group, the root and the six depth-one synsets.

usage:  python3 experiments_wordnet.py prior
        python3 experiments_wordnet.py <model> <trainseed_index>
        python3 experiments_wordnet.py assemble
"""
import json, sys, os, glob
import numpy as np
import experiments as ex
import experiments_tree as T
from experiments_cr import mmd2_laplace

RHO, NOISE, GROUP_DEPTH = 0.5, 0.10, 2
NTRAIN, NTEST = 32768, 4096
KDOUBLE = 10            # k up to 512

Z = np.load("wn_embedding.npz"); TREE = json.load(open("wn_tree.json"))
NAMES = [str(n) for n in Z["names"]]
R0 = Z["r"]; TH = np.arctan2(Z["V"][:, 1], Z["V"][:, 0]); RR = RHO * R0
POS = ex.expmap(np.broadcast_to(ex.O_PT, (len(RR), 3)).copy(), np.stack([RR * np.cos(TH), RR * np.sin(TH), np.zeros_like(RR)], -1))
PARENT, DEPTH = TREE["parent"], TREE["depth"]

def ancestor_at_depth(n, d):
    while DEPTH[n] > d: n = PARENT[n]
    return n

GROUPS = sorted(set(ancestor_at_depth(n, GROUP_DEPTH) for n in NAMES))
NODE_GROUP = np.array([GROUPS.index(ancestor_at_depth(n, GROUP_DEPTH)) for n in NAMES], dtype=int)
W_NODE = np.ones(len(NAMES)) / len(NAMES)
GROUP_W = np.bincount(NODE_GROUP, weights=W_NODE, minlength=len(GROUPS))
RMAX = float(RR.max()); DIV_R = RMAX + 2.0

def make_data(n, rng_):
    node = rng_.choice(len(NAMES), size=n, p=W_NODE)
    x = POS[node]
    return ex.expmap(x, NOISE * ex.tangent_gauss(x, rng_)), node

def setup():
    rgd = np.random.default_rng(47)
    Xtr, _ = make_data(NTRAIN, rgd); Xte, _ = make_data(NTEST, rgd)
    sub = Xte[:512]; dd = ex.dist(sub[:, None, :], sub[None, :, :])
    return Xtr, Xte, POS, W_NODE, float(np.median(dd[dd > 0]))

def evaluate(S, Xte, centres, W, bw):
    fin = np.isfinite(S).all(-1)
    div = float(((ex.r_of(np.where(fin[:, None], S, 0.0)) > DIV_R) | ~fin).mean())
    if not fin.all():
        return {"mmd2": float("nan"), "node_tv": float("nan"), "group_tv": float("nan"), "frac_div": div}
    assign = ex.dist(S[:, None, :], centres[None, :, :]).argmin(1)
    frac = np.bincount(assign, minlength=len(W)) / len(S)
    gfrac = np.bincount(NODE_GROUP[assign], minlength=len(GROUPS)) / len(S)
    return {"mmd2": float(mmd2_laplace(S, Xte, bw)), "node_tv": 0.5 * float(np.abs(frac - W).sum()),
            "group_tv": 0.5 * float(np.abs(gfrac - GROUP_W).sum()), "frac_div": div}

def feats(x, t, Tt):
    er, ephi, r, cs = ex.frame(x)
    return np.concatenate([T.rad_feats(r), T.ang_feats(cs, KDOUBLE), ex.timefeat(t, Tt)], -1), er, ephi, r

def tangent_feats(y, t, Tt):
    ny = np.linalg.norm(y, axis=-1, keepdims=True); cs = y / np.maximum(ny, 1e-12)
    return np.concatenate([y, T.rad_feats(ny[..., 0]), T.ang_feats(cs, KDOUBLE), ex.timefeat(t, Tt)], -1)

T.feats, T.tangent_feats = feats, tangent_feats
T.DIN_I, T.DIN_T = 9 + 2 * KDOUBLE + 9, 2 + 9 + 2 * KDOUBLE + 9

BASE = {"c0.25": 102, "c0.5": 103, "c1.0": 104, "c2.0": 101, "c4.0": 105, "tangent": 112}

def run(model, idx):
    if os.path.exists(f"wn_{model}_s{idx}.json"): print("exists"); return
    Xtr, Xte, centres, W, bw = setup()
    tseed = BASE[model] + 1000 * idx; sseeds = [tseed + o for o in (100, 200, 300)]
    out = {"model": model, "train_seed": tseed, "samp_seeds": sseeds, "bandwidth": bw}
    if model == "tangent":
        net = T.train_tangent(Xtr, T=ex.T2, seed=tseed)
        sampler = lambda n, s: T.sample_tangent(net, n, np.random.default_rng(s), T=ex.T2, K=ex.K2)
    else:
        c = float(model[1:])
        paths = ex.simulate_paths(Xtr, c, ex.H2, ex.K2, np.random.default_rng(tseed))
        net = T.train_intrinsic(paths, c, ex.H2, ex.T2, seed=tseed); del paths
        sampler = lambda n, s: T.sample_intrinsic(net, c, ex.H2, ex.K2, ex.T2, n, np.random.default_rng(s))
    sets = [sampler(4096, s) for s in sseeds]
    out["rows"] = [evaluate(S, Xte, centres, W, bw) for S in sets]
    np.savez_compressed(f"wn_{model}_s{idx}_samples.npz", *sets)
    if idx == 0: json.dump(ex.to_disk(sets[0][:3000]).tolist(), open(f"wn_samples_{model}.json", "w"))
    json.dump(out, open(f"wn_{model}_s{idx}.json", "w"), indent=1)
    a = np.array([[r["mmd2"], r["node_tv"], r["group_tv"], r["frac_div"]] for r in out["rows"]])
    print(f"[wn {model} seed{idx}] MMD2 {a[:,0].mean():.5f}+-{a[:,0].std():.5f}  nodeTV {a[:,1].mean():.3f}  groupTV {a[:,2].mean():.3f}  div {a[:,3].mean():.4f}", flush=True)

def prior():
    Xtr, Xte, centres, W, bw = setup()
    D = ex.dist(centres[:, None, :], centres[None, :, :]); np.fill_diagonal(D, np.inf)
    out = {"bandwidth": bw, "n_nodes": len(NAMES), "n_groups": len(GROUPS), "rho": RHO, "noise": NOISE, "rmax": RMAX,
           "radius_quantiles": np.quantile(RR, [0, 0.1, 0.5, 0.9, 1]).tolist(),
           "nearest_quantiles": np.quantile(D.min(1), [0, 0.05, 0.25, 0.5]).tolist(),
           "nodes_disk": ex.to_disk(POS).tolist(), "group_sizes": np.bincount(NODE_GROUP).tolist(), "groups": GROUPS}
    out["floor"] = evaluate(Xte, Xtr[:4096], centres, W, bw)       # the test set's own values: the sampling floor
    json.dump(ex.to_disk(Xte[:3000]).tolist(), open("wn_samples_data.json", "w"))
    for c in [0.25, 0.5, 1.0, 2.0, 4.0]:
        endp = ex.simulate_paths(Xtr[:8192], c, ex.H2, ex.K2, np.random.default_rng(BASE[f"c{c}"]))[-1]
        P = ex.sample_prior(c, 4096, np.random.default_rng(7))
        out[f"prior_mismatch_c{c}"] = float(mmd2_laplace(endp[:4096], P, bw)); out[f"forward_Er_c{c}"] = float(ex.r_of(endp).mean())
        print(f"[wn prior] c={c}: mismatch {out[f'prior_mismatch_c{c}']:.5f}  E r {out[f'forward_Er_c{c}']:.3f}", flush=True)
    json.dump(out, open("wn_prior.json", "w"), indent=1)
    print("floor", out["floor"], "radius q", np.round(out["radius_quantiles"], 2), "nearest q", np.round(out["nearest_quantiles"], 3))

def assemble():
    res = {"prior": json.load(open("wn_prior.json"))}
    for f in sorted(glob.glob("wn_c*_s[0-9].json") + glob.glob("wn_tangent_s[0-9].json")):
        d = json.load(open(f)); res.setdefault(d["model"], {})[str(d["train_seed"])] = d
    summary = {}
    for model, runs in res.items():
        if model == "prior": continue
        A = np.array([[r["mmd2"], r["node_tv"], r["group_tv"], r["frac_div"]] for d in runs.values() for r in d["rows"]])
        P = np.array([np.mean([[r["mmd2"], r["node_tv"], r["group_tv"], r["frac_div"]] for r in d["rows"]], 0) for d in runs.values()])
        summary[model] = {"n_train": len(runs), "mean": A.mean(0).tolist(), "std_all": A.std(0, ddof=1).tolist(),
                          "std_train": P.std(0, ddof=1).tolist() if len(P) > 1 else [0] * 4, "per_train_mean": P.tolist()}
        print(f"[wn {model}] runs={len(runs)} MMD2 {A[:,0].mean():.5f}+-{A[:,0].std(ddof=1):.5f} nodeTV {A[:,1].mean():.3f} groupTV {A[:,2].mean():.3f}+-{A[:,2].std(ddof=1):.3f} div {A[:,3].mean():.4f}")
    res["summary"] = summary; json.dump(res, open("wn_all.json", "w"), indent=1)

if __name__ == "__main__":
    ex.self_test()
    stage = sys.argv[1]
    if stage == "prior": prior()
    elif stage == "assemble": assemble()
    else: run(stage, int(sys.argv[2]))
