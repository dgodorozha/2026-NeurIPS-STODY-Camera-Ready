"""Finite element solution of the radial eigenvalue problem for L_c on H^n.

For a function f = eta(r) psi(theta) with -Delta_S psi = ell (ell = k(k+n-2)) the
Rayleigh quotient separates, and lambda_1(c) is the minimum over ell of the lowest
eigenvalue of
    int (eta'^2 + ell eta^2 / sinh^2 r) w dr / int eta^2 w dr,  w = e^{-c r^2/2} sinh^{n-1} r,
with the constant mode removed for ell = 0.  Linear elements, two point Gauss rule.
Outputs fem.json with lambda_1(c) for n = 2, 3 on a c grid, the small-c sharpness
ratios and the fitted exponents beta(n) for n = 2..5.
"""
import json, numpy as np
from scipy import sparse
from scipy.sparse.linalg import eigsh

def lowest(c, n, ell, N=16000):
    R = float(max((n - 1) / c + 12.0 / np.sqrt(c), 2.0))
    r_ = np.linspace(0.0, R, N + 1)[1:]
    lw = lambda z: -c * z**2 / 2 + (n - 1) * np.log(np.sinh(np.clip(z, 1e-300, None)))
    sh = np.max(lw(r_)); W = lambda z: np.exp(lw(np.clip(z, 1e-14, None)) - sh)
    if ell > 0:                      # eta(0) = 0 for angular modes
        a_ = np.concatenate([[0.0], r_[:-1]]); b_ = r_.copy()
        iA, iB = np.arange(-1, N - 1), np.arange(0, N)
    else:
        a_, b_ = r_[:-1], r_[1:]; iA, iB = np.arange(N - 1), np.arange(1, N)
    L = b_ - a_
    dA, dB, oA, oB = np.zeros(N), np.zeros(N), np.zeros(N - 1), np.zeros(N - 1)
    for t in (0.5 - np.sqrt(3) / 6, 0.5 + np.sqrt(3) / 6):
        q = a_ + t * L; wgt = 0.5 * L * W(q)
        V = ell / np.sinh(np.clip(q, 1e-14, None))**2 if ell > 0 else 0.0
        pA, pB = (b_ - q) / L, (q - a_) / L; s = wgt / L**2
        m = iA >= 0
        np.add.at(dA, iA[m], (s + wgt * V * pA * pA)[m]); np.add.at(dB, iA[m], (wgt * pA * pA)[m])
        np.add.at(dA, iB, s + wgt * V * pB * pB);        np.add.at(dB, iB, wgt * pB * pB)
        np.add.at(oA, iA[m], (-s + wgt * V * pA * pB)[m]); np.add.at(oB, iA[m], (wgt * pA * pB)[m])
    A = sparse.diags([oA, dA, oA], [-1, 0, 1], format="csc")
    B = sparse.diags([oB, dB, oB], [-1, 0, 1], format="csc")
    nev = 2 if ell == 0 else 1
    v = eigsh(A, k=nev, M=B, sigma=0.0 if ell > 0 else -1e-9, which="LM", return_eigenvectors=False)
    return float(np.sort(v)[-1])

def lam1(c, n):
    ells = [0, n - 1, 2 * n]          # k = 0, 1, 2
    vals = {k: lowest(c, n, ell) for k, ell in zip([0, 1, 2], ells)}
    return min(vals.values()), vals

if __name__ == "__main__":
    out = {"grid": {}, "sharpness": {}, "exponents": {}}
    for n in [2, 3]:
        cs = sorted(set(np.round(np.geomspace(0.03, 8.0, 40), 5).tolist() + [0.05, 0.1, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0]))
        rows = []
        for c in cs:
            l, modes = lam1(c, n)
            rows.append({"c": c, "lam1": l, "k0": modes[0], "k1": modes[1], "k2": modes[2]})
            print(f"n={n} c={c:8.4f}  lam1={l:.6e}  (k0 {modes[0]:.4e}, k1 {modes[1]:.4e}, k2 {modes[2]:.4e})", flush=True)
        out["grid"][str(n)] = rows

    # small-c sharpness on H^2: ratio to sqrt(c) e^{-1/(2c)}
    sh = []
    for c in [0.02, 0.025, 0.03, 0.04, 0.05, 0.06, 0.08, 0.10, 0.15, 0.20, 0.25]:
        l = lowest(c, 2, 1, N=24000); env = np.sqrt(c) * np.exp(-1 / (2 * c))
        sh.append({"c": c, "lam1": l, "env": env, "ratio": l / env})
        print(f"sharpness n=2 c={c}: lam1={l:.4e} ratio={l/env:.4f}", flush=True)
    out["sharpness"]["2"] = sh

    # exponent fits, log lam1 = A - beta/c (n=2 carries the sqrt(c) prefactor)
    for n, cs in [(2, [0.05, 0.06, 0.08, 0.10, 0.125]), (3, [0.10, 0.12, 0.15, 0.18, 0.22]),
                  (4, [0.18, 0.22, 0.26, 0.30, 0.35]), (5, [0.26, 0.30, 0.35, 0.40, 0.45])]:
        ls = np.array([lowest(c, n, n - 1, N=24000) for c in cs]); inv = 1.0 / np.array(cs)
        y = np.log(ls) - (0.5 * np.log(cs) if n == 2 else 0.0)
        sl, ic = np.polyfit(inv, y, 1)
        claim = 0.5 if n == 2 else min((n - 1)**2 / 2, 2 * (n - 2))
        out["exponents"][str(n)] = {"fitted": -sl, "claimed": claim, "cs": cs, "lam1": ls.tolist()}
        print(f"exponent n={n}: fitted {-sl:.4f} claimed {claim}", flush=True)

    json.dump(out, open("fem.json", "w"), indent=1)
    print("fem.json written")
