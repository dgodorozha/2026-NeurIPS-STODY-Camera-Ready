"""Poincare embedding of the WordNet mammal subtree (Nickel and Kiela 2017), via gensim.

Produces wn_embedding.npz (disk coordinates V, synset names, hyperbolic radii r) and
wn_tree.json (parent map and depth of every synset).  Requires nltk with the WordNet
corpus (nltk.download('wordnet')) and gensim.  Runtime about four minutes on one core.
"""
import json, time, numpy as np
from nltk.corpus import wordnet as wn
from gensim.models.poincare import PoincareModel

m = wn.synset("mammal.n.01")
closure = set(m.closure(lambda s: s.hyponyms())); closure.add(m)
pairs = set()
for s in closure:
    for h in s.closure(lambda t: t.hypernyms() + t.instance_hypernyms()):
        if h in closure: pairs.add((s.name(), h.name()))
pairs = sorted(pairs)
print("synsets", len(closure), "closure pairs", len(pairs))

t0 = time.time()
model = PoincareModel(pairs, size=2, negative=10, seed=0, burn_in=10, epsilon=1e-5)
model.train(epochs=300, print_every=100000)
print(f"trained in {time.time()-t0:.0f}s")

names = list(model.kv.index_to_key)
V = np.array([model.kv[n] for n in names]); nrm = np.linalg.norm(V, axis=1)
r = 2 * np.arctanh(np.clip(nrm, 0, 1 - 1e-15))
print("hyperbolic radius quantiles:", np.round(np.quantile(r, [0, .1, .25, .5, .75, .9, 1]), 2))

direct = {}
for s in closure:
    hs = [h for h in s.hypernyms() + s.instance_hypernyms() if h in closure]
    if hs: direct[s.name()] = hs[0].name()
depth = {m.name(): 0}
def dep(n):
    if n in depth: return depth[n]
    depth[n] = 1 + dep(direct[n]); return depth[n]
for n in direct: dep(n)

# reconstruction quality: rank of the direct hypernym among all synsets by Poincare distance
def pdist(u, v):
    du = 1 - np.sum(u * u, -1); dv = 1 - np.sum(v * v, -1); d2 = np.sum((u - v) ** 2, -1)
    return np.arccosh(1 + 2 * d2 / (du * dv))
idx = {n: i for i, n in enumerate(names)}
ranks = []
for s, h in direct.items():
    i = idx[s]; d = pdist(V[i][None], V); d[i] = np.inf
    ranks.append(int((d < d[idx[h]]).sum()) + 1)
print("direct hypernym: mean rank", round(float(np.mean(ranks)), 2), " median", float(np.median(ranks)))

np.savez("wn_embedding.npz", V=V, names=np.array(names), r=r)
json.dump({"names": names, "parent": direct, "depth": {k: int(v) for k, v in depth.items()}}, open("wn_tree.json", "w"))
print("saved wn_embedding.npz, wn_tree.json")
