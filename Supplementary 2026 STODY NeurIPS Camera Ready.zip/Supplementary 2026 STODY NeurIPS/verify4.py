"""Numerical verification of the below-threshold lower bound (new theorem) and of the
radial-mode bound.

Radial weight w(r) = sinh^{n-1}(r) e^{-c r^2/2}; first harmonic potential V = (n-1)/sinh^2 r.
A = [0,1], B = [1, inf).  Constants:
  kappa_c = inf { int_A (eta'^2 + V eta^2) w : eta(1) = 1 }     (capacity of the unit ball)
  D_c     = W_B^{-2} int_1^inf T(s)^2 / w(s) ds,  T(s) = int_s^inf w   (Hardy constant on B)
  W_B     = int_1^inf w
Claim:  lambda_1(c) >= min{ c/2, V_1/2, min(kappa_c, 1/D_c) / (8 W_B) },  V_1 = (n-1)/sinh^2(1),
and lambda^(0)(c) >= c for the radial mode.
"""
import json, numpy as np
from scipy.integrate import solve_ivp, quad
from scipy import sparse
from scipy.sparse.linalg import eigsh
from fem_lambda import lowest
ok = lambda b: "PASS" if b else "**FAIL**"

def w_of(r, c, n): return np.sinh(r) ** (n - 1) * np.exp(-c * r * r / 2)

def kappa_ode(c, n):
    """Solve (w eta')' = V w eta on (0,1], regular at 0 (eta ~ r), then kappa = w(1) eta'(1)/eta(1)."""
    def rhs(r, y):
        eta, deta = y
        b = (n - 1) / np.tanh(r) - c * r
        return [deta, -b * deta + (n - 1) / np.sinh(r) ** 2 * eta]
    eps = 1e-6
    sol = solve_ivp(rhs, [eps, 1.0], [eps, 1.0], rtol=1e-11, atol=1e-14, dense_output=True)
    eta1, deta1 = sol.y[0, -1], sol.y[1, -1]
    return w_of(1.0, c, n) * deta1 / eta1, sol

def kappa_fem(c, n, N=4000):
    """Independent check: minimise the quadratic form over piecewise linear eta with eta(1)=1."""
    r = np.linspace(0, 1, N + 1); h = 1.0 / N
    # assemble stiffness K and potential P on nodes 0..N (node 0 at r=0 free, node N fixed = 1)
    gq = [(0.5 - np.sqrt(3) / 6), (0.5 + np.sqrt(3) / 6)]
    Kd, Ko = np.zeros(N + 1), np.zeros(N)
    for t in gq:
        q = r[:-1] + t * h; wq = w_of(q, c, n) * 0.5 * h; V = (n - 1) / np.sinh(q) ** 2
        pA, pB = 1 - t, t
        Kd[:-1] += wq / h**2 + wq * V * pA * pA; Kd[1:] += wq / h**2 + wq * V * pB * pB
        Ko += -wq / h**2 + wq * V * pA * pB
    K = sparse.diags([Ko, Kd, Ko], [-1, 0, 1]).tocsr()
    # eta_N = 1: solve K_II eta_I = -K_IN
    KII = K[:N, :N]; KIN = K[:N, N].toarray().ravel()
    etaI = sparse.linalg.spsolve(KII.tocsc(), -KIN)
    eta = np.concatenate([etaI, [1.0]])
    return float(eta @ (K @ eta))

def WB_D(c, n):
    """W_B and the Hardy constant D = W_B^{-2} int_1^R T(s)^2/w(s) ds, with the tail T(s) = int_s^R w
    accumulated from the far end so that small values keep their relative accuracy."""
    R = (n - 1) / c + 16 / np.sqrt(c) + 4
    s = np.linspace(1, R, 200001); ws = w_of(s, c, n)
    pieces = (ws[1:] + ws[:-1]) / 2 * np.diff(s)
    tail = np.concatenate([np.cumsum(pieces[::-1])[::-1], [0.0]])      # T(s_i) = sum of pieces to the right
    W_B = tail[0]
    integrand = np.where(ws > 0, tail**2 / np.maximum(ws, 1e-300), 0.0)
    D = np.trapezoid(integrand, s) / W_B**2
    return W_B, D

def hardy_check(c, n, rng):
    """Random eta on B: verify (m - a)^2 <= D * int_B eta'^2 w."""
    W_B, D = WB_D(c, n)
    R = (n - 1) / c + 14 / np.sqrt(c) + 4
    s = np.linspace(1, R, 20001); ws = w_of(s, c, n)
    worst = 0.0
    for _ in range(40):
        # smooth random function: sum of a few random bumps and a linear part
        k = rng.integers(2, 6); eta = rng.normal() * (s - 1)
        for _ in range(k):
            mu, sg, amp = rng.uniform(1, R), rng.uniform(0.2, 3.0), rng.normal()
            eta = eta + amp * np.exp(-(s - mu)**2 / (2 * sg**2))
        a = eta[0]; m = np.trapezoid(eta * ws, s) / np.trapezoid(ws, s)
        G = np.trapezoid(np.gradient(eta, s)**2 * ws, s)
        worst = max(worst, (m - a)**2 / (D * G))
    return worst

print("=" * 78)
print("L1  radial mode: lambda^(0)(c) >= c   (finite elements, k = 0)")
allok = True
for n in [2, 3]:
    for c in [0.05, 0.1, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0]:
        l0 = lowest(c, n, 0); allok &= l0 >= c * (1 - 1e-6)
        print(f"    n={n} c={c:5.2f}: lambda^(0) = {l0:.5f}  (c = {c})  ratio {l0/c:.3f}")
print(f"    all >= c: {ok(allok)}")

print("\nL2  capacity kappa_c of the unit ball: ODE against finite element minimisation")
kap = {}
for n in [2, 3]:
    for c in [0.0, 0.05, 0.1, 0.25, 0.5, 1.0]:
        k1, _ = kappa_ode(max(c, 1e-12), n); k2 = kappa_fem(c, n)
        kap[(n, c)] = k1
        print(f"    n={n} c={c:5.2f}: kappa ODE {k1:.6f}   FEM {k2:.6f}   {ok(abs(k1-k2) < 2e-4)}")
print(f"    n=2, c=0: exact value 1 (eta = tanh(r/2)):  {kap[(2,0.0)]:.6f}  {ok(abs(kap[(2,0.0)]-1) < 1e-4)}")
print(f"    kappa_c >= e^(-c/2) kappa_0:  " + ", ".join(f"n={n} c={c}: {kap[(n,c)]:.4f} >= {np.exp(-c/2)*kap[(n,0.0)]:.4f} {ok(kap[(n,c)] >= np.exp(-c/2)*kap[(n,0.0)] - 1e-9)}" for n in [2,3] for c in [0.25, 1.0]))

print("\nL3  Hardy constant D_c on B and random-function check of (m-a)^2 <= D G")
rng = np.random.default_rng(0)
Dc = {}
for n in [2, 3]:
    for c in [0.05, 0.1, 0.25, 0.5, 1.0]:
        W_B, D = WB_D(c, n); Dc[(n, c)] = (W_B, D)
        worst = hardy_check(c, n, rng)
        print(f"    n={n} c={c:5.2f}: W_B {W_B:.4e}  D {D:.4f}  worst (m-a)^2/(D G) over 40 random eta: {worst:.3f}  {ok(worst <= 1.0)}")

print("\nL4  the lower bound against the finite element gap")
rows = []
for n in [2, 3]:
    V1 = (n - 1) / np.sinh(1.0) ** 2
    for c in [0.05, 0.1, 0.25, 0.5, 1.0]:
        W_B, D = Dc[(n, c)]; k = kap[(n, c)]
        low = min(c / 2, V1 / 2, min(k, 1 / D) / (8 * W_B))
        l1 = lowest(c, n, n - 1)       # k = 1 mode, which attains lambda_1
        asym = min(k, 1 / D) / 8 * 2**(n - 1) * np.sqrt(c / (2 * np.pi)) * np.exp(-(n - 1)**2 / (2 * c))
        rows.append({"n": n, "c": c, "lam1": l1, "low": low, "asym": asym, "kappa": k, "D": D, "W_B": W_B})
        print(f"    n={n} c={c:5.2f}: lambda_1 {l1:.4e}   bound {low:.4e}   ratio lambda_1/bound {l1/low:8.2f}   "
              f"closed-form bound {asym:.4e}   {ok(low <= l1 and asym <= l1)}")
json.dump(rows, open("lowerbound_table.json", "w"), indent=1)

print("\nL5  prefactor on H^3: lambda_1 e^{2/c} and lambda_1 e^{2/c}/sqrt(c)")
for c in [0.10, 0.12, 0.15, 0.18, 0.22, 0.25, 0.3]:
    l1 = lowest(c, 3, 2, N=24000)
    print(f"    c={c:.2f}: lam1 e^(2/c) = {l1*np.exp(2/c):.4f}    lam1 e^(2/c)/sqrt(c) = {l1*np.exp(2/c)/np.sqrt(c):.4f}")
print("=" * 78)
