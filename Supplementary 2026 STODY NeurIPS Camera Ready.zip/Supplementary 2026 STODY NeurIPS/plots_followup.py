"""Figure 8, the follow-up runs on hierarchy C: the zoomed sector of Figure 6 for the standard
configuration, the four times larger budget (width 512, 160k iterations) and the finer sampler
(1000 steps of 0.004), for the intrinsic model at c = 1 (top) and the wrapped baseline (bottom).
First training seed, 12,288 points per panel.  Runs after experiments_tree_big.py and
experiments_tree_fine.py: python3 plots_followup.py
"""
import os, json, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
import experiments as ex, experiments_tree as T
from plots_scale import polar, BLUE

matplotlib.rcParams.update({"pdf.fonttype": 42, "ps.fonttype": 42, "font.family": "serif", "mathtext.fontset": "cm", "font.size": 7, "axes.titlesize": 7.3, "axes.labelsize": 7, "xtick.labelsize": 6, "ytick.labelsize": 6})

def load(tag):
    f = f"{tag}_samples.npz"
    if not os.path.exists(f): return None
    z = np.load(f); return np.concatenate([z[k] for k in z.files])

X, _ = T.make_tree_data(12288, np.random.default_rng(999))
th_root = np.arctan2(T.NODES[1:5, 1], T.NODES[1:5, 0]); t0 = float(th_root[np.argmin(np.abs(th_root))])
win = (t0 - 0.55, t0 + 0.55); rlim = (2.8, 4.3)
rows = [("intrinsic, $c=1$", ["tree_c1.0_s0", "tree_big_c1.0_s0", "tree_fine_c1.0_s0"]),
        ("tangent (wrapped)", ["tree_tangent_s0", "tree_big_tangent_s0", "tree_fine_tangent_s0"])]
cols = ["data", "standard\n(width 256, 40k iterations)", "width 512,\n160k iterations", "1000 steps\nof $h=0.004$"]
need = [f"{t}_samples.npz" for _, tags in rows for t in tags]
missing = [f for f in need if not os.path.exists(f)]
if missing:
    raise SystemExit("figure not written, missing sample sets: " + ", ".join(missing))
fig, axs = plt.subplots(2, 4, figsize=(5.5, 2.75))
for i, (name, tags) in enumerate(rows):
    sets = [X] + [load(t) for t in tags]
    for j, (P, ttl) in enumerate(zip(sets, cols)):
        a = axs[i, j]
        if P is None: a.text(0.5, 0.5, "not run", ha="center", va="center", transform=a.transAxes); a.set_xticks([]); a.set_yticks([]); continue
        th, r = polar(P); m = (th > win[0]) & (th < win[1])
        a.scatter(th[m], r[m], s=1.2, c=BLUE, alpha=0.6, linewidths=0)
        a.set_xlim(*win); a.set_ylim(*rlim); a.tick_params(length=2, pad=1.5)
        if i == 0: a.set_title(ttl)
        if j == 0: a.set_ylabel(name + "\nradius $r$")
        else: a.set_yticklabels([])
        if i == 1: a.set_xlabel(r"angle $\varphi$")
        else: a.set_xticklabels([])
fig.tight_layout(pad=0.3, h_pad=0.5, w_pad=0.4); fig.savefig("fig_followup.pdf", bbox_inches="tight"); print("fig_followup.pdf")

for tag in ["tree_c1.0_s0", "tree_big_c1.0_s0", "tree_fine_c1.0_s0", "tree_tangent_s0", "tree_big_tangent_s0", "tree_fine_tangent_s0"]:
    if os.path.exists(tag + ".json"):
        d = json.load(open(tag + ".json")); a = np.array([[r["mmd2"], r["leaf_tv"]] for r in d["rows"]])
        print(f"{tag:22s} MMD2 {a[:,0].mean()*1e3:.2f}  leaf TV {a[:,1].mean():.3f}")
