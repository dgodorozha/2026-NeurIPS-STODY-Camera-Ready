# Resolving the H^2 radial rate discrepancy of Table 10.
# Three changes isolate the cause:
#  (1) Observables that are exact eigenfunctions of the generator, taken from the FEM eigenvectors:
#      E[g0(r_t)] decays at exactly lambda^(0) and E[g1(r_t) theta_1] at exactly lambda^(1), for ANY initial law,
#      so the fitted slope has no transient and measures only the discretisation bias (plus noise).
#  (2) A step size scan h in {0.002, 0.001, 0.0005} for the polar scheme (reflected Euler-Maruyama in r).
#  (3) A second integrator on the hyperboloid (geodesic Euler step x <- exp_x(drift h + sqrt(2h) xi)), which has
#      no singular drift at the origin; if its rates sit at the FEM values while the polar scheme's converge to them
#      as h -> 0, the discrepancy is the polar scheme's treatment of the origin.
# For n = 3, 4 the polar scheme is run at the Table 10 step sizes with the eigen-observables (no hyperboloid code for n > 2).
# Usage: python exp1_h2_resolve.py [--N 60000] [--reps 3] [--n 2 3 4]
import numpy as np, json, time, argparse
from scipy import sparse
from scipy.sparse.linalg import eigsh

def fem(c, n, kmode, N=12000):
    """Sector FEM as in check_intertwine.py; returns (eigenvalue, grid r, eigenvector on grid)."""
    R = max(9.0, (n - 1) / c + 10.0 / np.sqrt(c)); r = np.linspace(0.0, R, N + 1)[1:]
    lw = lambda z: -c * z**2 / 2 + (n - 1) * np.log(np.sinh(np.clip(z, 1e-300, None)))
    sh = np.max(lw(r)); W = lambda z: np.exp(lw(np.clip(z, 1e-14, None)) - sh)
    if kmode:
        a_ = np.concatenate([[0.0], r[:-1]]); b_ = r.copy(); iA, iB = np.arange(-1, N - 1), np.arange(0, N)
    else:
        a_, b_ = r[:-1], r[1:]; iA, iB = np.arange(N - 1), np.arange(1, N)
    L = b_ - a_
    dA, dB, oA, oB = np.zeros(N), np.zeros(N), np.zeros(N - 1), np.zeros(N - 1)
    for t in (0.5 - np.sqrt(3)/6, 0.5 + np.sqrt(3)/6):
        q = a_ + t * L; wgt = 0.5 * L * W(q)
        V = (n - 1) / np.sinh(np.clip(q, 1e-14, None))**2 if kmode else 0.0
        pA, pB = (b_ - q) / L, (q - a_) / L; s = wgt / L**2; m = iA >= 0
        np.add.at(dA, iA[m], (s + wgt*V*pA*pA)[m]); np.add.at(dB, iA[m], (wgt*pA*pA)[m])
        np.add.at(dA, iB, s + wgt*V*pB*pB);        np.add.at(dB, iB, wgt*pB*pB)
        np.add.at(oA, iA[m], (-s + wgt*V*pA*pB)[m]); np.add.at(oB, iA[m], (wgt*pA*pB)[m])
    A = sparse.diags([oA, dA, oA], [-1, 0, 1], format="csc"); B = sparse.diags([oB, dB, oB], [-1, 0, 1], format="csc")
    nev = 2 if kmode == 0 else 1
    vals, vecs = eigsh(A, k=nev, M=B, sigma=0.0 if kmode else -1e-9, which="LM")
    i = np.argsort(vals)[-1]; g = vecs[:, i]; g = g / np.max(np.abs(g))
    return float(vals[i]), r, g

def radial_law(c, n):
    R = max(9.0, (n-1)/c + 10/np.sqrt(c)); r = np.linspace(1e-9, R, 400001)
    lw = -c*r**2/2 + (n-1)*np.log(np.sinh(r)); w = np.exp(lw - lw.max()); cdf = np.cumsum(w); cdf /= cdf[-1]
    return r, cdf, float(np.trapezoid(r*w, r)/np.trapezoid(w, r))

def polar_run(c, n, r0, th0, h, T, rg, r_grid, g0, g1):
    """Polar scheme. Records E g0(r), E r, E g1(r) theta_1, E theta_1 at every step."""
    K = int(round(T/h)); r = r0.copy(); th = th0.copy(); N = len(r)
    S = np.empty((K+1, 4))
    for k in range(K+1):
        S[k] = (np.interp(r, r_grid, g0).mean(), r.mean(), (np.interp(r, r_grid, g1)*th[:, 0]).mean(), th[:, 0].mean())
        if k == K: break
        drift = np.clip((n-1)/np.tanh(np.maximum(r, 1e-9)) - c*r, -80.0, 80.0)
        sig = np.sqrt(2*h)/np.maximum(np.sinh(r), 1e-9)
        r = np.abs(r + drift*h + np.sqrt(2*h)*rg.standard_normal(N))
        xi = rg.standard_normal((N, n)); xi -= (xi*th).sum(1, keepdims=True)*th
        nx = np.linalg.norm(xi, axis=1); a = sig*nx; u = xi/np.maximum(nx, 1e-300)[:, None]
        th = np.cos(a)[:, None]*th + np.sin(a)[:, None]*u; th /= np.linalg.norm(th, axis=1, keepdims=True)
    return np.arange(K+1)*h, S

# ---- hyperboloid scheme on H^2 (from experiments.py, n = 2 only) ----
ETA = np.array([1.0, 1.0, -1.0]); O_PT = np.array([0.0, 0.0, 1.0])
mink = lambda u, v: (u*v*ETA).sum(-1)
def normalize(x): x = x.copy(); x[..., 2] = np.sqrt(1.0 + x[..., 0]**2 + x[..., 1]**2); return x
def r_of(x): return np.arcsinh(np.hypot(x[..., 0], x[..., 1]))
def _sinch(d):
    small = d < 1e-6
    return np.where(small, 1.0 + d*d/6.0, np.sinh(np.where(small, 1.0, d))/np.where(small, 1.0, d))
def expmap(x, v):
    nv = np.sqrt(np.maximum(mink(v, v), 0.0)); return normalize(np.cosh(nv)[..., None]*x + _sinch(nv)[..., None]*v)
def grad_r(x):
    r = r_of(x); v = np.cosh(r)[..., None]*x - O_PT; s = np.maximum(np.sinh(r), 1e-12)[..., None]; g = v/s; g[r < 1e-8] = 0.0
    return g, r
def tangent_gauss(x, rg):
    xi = rg.standard_normal(x.shape[:-1] + (2,)); v = np.zeros_like(x); v[..., 0] = xi[..., 0]; v[..., 1] = xi[..., 1]
    a = mink(x, v)[..., None]/(1.0 - mink(np.broadcast_to(O_PT, x.shape), x))[..., None]
    return v + a*(O_PT + x)
def hyperboloid_run(c, x0, h, T, rg, r_grid, g0, g1):
    K = int(round(T/h)); x = x0.copy(); S = np.empty((K+1, 4))
    for k in range(K+1):
        r = r_of(x); th1 = x[:, 0]/np.maximum(np.sinh(r), 1e-300)
        S[k] = (np.interp(r, r_grid, g0).mean(), r.mean(), (np.interp(r, r_grid, g1)*th1).mean(), th1.mean())
        if k == K: break
        g, r = grad_r(x); v = -(c*r)[..., None]*g*h + np.sqrt(2.0*h)*tangent_gauss(x, rg)
        nv = np.sqrt(np.maximum(mink(v, v), 0.0)); v = v*np.minimum(1.0, 5.0/np.maximum(nv, 1e-12))[..., None]
        x = expmap(x, v)
    return np.arange(K+1)*h, S

def slope_abs(ts, sig, lo, hi):
    a = np.abs(sig); m = (a <= hi) & (a >= lo)
    if m.sum() < 10: return float('nan')
    A = np.vstack([ts[m], np.ones(m.sum())]).T
    return -float(np.linalg.lstsq(A, np.log(a[m]), rcond=None)[0][0])

def fit(ts, sig, lo_frac=0.05, hi_frac=0.6):
    """Slope of log|sig| where |sig| is between hi_frac and lo_frac of its initial value."""
    a = np.abs(sig); s0 = a[0]; m = (a <= hi_frac*s0) & (a >= lo_frac*s0)
    if m.sum() < 10: return float('nan')
    A = np.vstack([ts[m], np.ones(m.sum())]).T
    return -float(np.linalg.lstsq(A, np.log(a[m]), rcond=None)[0][0])

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--N", type=int, default=60000); ap.add_argument("--reps", type=int, default=3)
    ap.add_argument("--n", type=int, nargs="+", default=[2, 3, 4]); ap.add_argument("--out", default="exp1_h2_resolve.json")
    ap.add_argument("--resume", action="store_true", help="skip rows already present in --out")
    args = ap.parse_args(); t0 = time.time()
    import os
    out = json.load(open(args.out)) if (args.resume and os.path.exists(args.out)) else {}
    print("  n scheme        c      h    rad(eigen)/l0  rad(E r)/l0  ang(eigen)/l1  ang(E th1)/l1    [mean of ratios over reps; sd of the two eigen ratios]")
    def rstar(c, n):
        lo, hi = 1e-3, 200.0
        for _ in range(200):
            mid = 0.5*(lo+hi)
            if c*mid < (n-1)/np.tanh(mid): lo = mid
            else: hi = mid
        return 0.5*(lo+hi)
    grid = {2: [0.5, 1, 2, 4], 3: [1, 2, 4, 8], 4: [1, 2, 4, 8]}
    for n in args.n:
      for c in grid[n]:
        l0, rg0, g0 = fem(c, n, 0); l1, rg1, g1 = fem(c, n, 1); rr, cdf, rbar = radial_law(c, n)
        T = 4.5/l0 + 0.3; Ta = min(6.0, 3.6/l1 + 0.3)
        if n == 2:
            runs = [("polar", 0.002), ("polar", 0.001), ("hyperboloid", 0.002), ("hyperboloid", 0.001)] + ([("polar", 0.0005)] if c >= 2 else [])
        else:
            runs = [("polar", 0.001 if c >= 4 else 0.002)]
        for scheme, h in runs:
            if f"{n},{scheme},{c},{h}" in out:
                print(f"{n:3d} {scheme:12s} {c:5.2f} {h:7.4f}   (already done, skipped)"); continue
            rows = []
            for rep in range(args.reps):
                rg = np.random.default_rng(31000 + int(1000*c) + rep)
                # radial run: all particles at one radius where |g0| is large (no transient for the eigen-observable)
                r0 = np.full(args.N, rbar + 1.5); th0 = np.zeros((args.N, n)); th0[:, 0] = 1.0
                # angular run: radius at the mode r*, direction concentrated near e_1
                ra = np.abs(rstar(c, n) + 0.2*rg.standard_normal(args.N)); tha = np.zeros((args.N, n)); tha[:, 0] = 1.0
                tha[:, 1] = 0.2*rg.standard_normal(args.N); tha /= np.linalg.norm(tha, axis=1, keepdims=True)
                if scheme == "polar":
                    ts, S = polar_run(c, n, r0, th0, h, T, rg, rg0, g0, g1)
                    tsa, Sa = polar_run(c, n, ra, tha, h, Ta, rg, rg0, g0, g1)
                else:
                    x0 = np.stack([np.sinh(r0)*th0[:, 0], np.sinh(r0)*th0[:, 1], np.cosh(r0)], -1)
                    ts, S = hyperboloid_run(c, x0, h, T, rg, rg0, g0, g1)
                    xa = np.stack([np.sinh(ra)*tha[:, 0], np.sinh(ra)*tha[:, 1], np.cosh(ra)], -1)
                    tsa, Sa = hyperboloid_run(c, xa, h, Ta, rg, rg0, g0, g1)
                rows.append([fit(ts, S[:, 0]) / l0,                              # radial eigen-observable, relative window
                             slope_abs(ts, S[:, 1] - rbar, 0.03, 0.3) / l0,      # raw E r, delta start (Table 10 first protocol)
                             fit(tsa, Sa[:, 2]) / l1,                            # angular eigen-observable
                             slope_abs(tsa, Sa[:, 3], 0.05, 0.2) / l1])          # raw E theta_1
            rows = np.array(rows); mu = np.nanmean(rows, 0); sd = np.nanstd(rows[:, [0, 2]], 0, ddof=1) if args.reps > 1 else np.zeros(2)
            out[f"{n},{scheme},{c},{h}"] = dict(l0=l0, l1=l1, ratios=rows.tolist())
            json.dump(out, open(args.out, "w"), indent=1)
            print(f"{n:3d} {scheme:12s} {c:5.2f} {h:7.4f}   {mu[0]:8.3f}      {mu[1]:8.3f}     {mu[2]:8.3f}      {mu[3]:8.3f}      [sd {sd[0]:.3f} / {sd[1]:.3f}]   {time.time()-t0:.0f}s", flush=True)
