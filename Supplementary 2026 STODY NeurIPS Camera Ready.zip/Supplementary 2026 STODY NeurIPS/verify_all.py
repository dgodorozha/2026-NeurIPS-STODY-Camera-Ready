"""Run every numerical check of the paper's theorems and print one summary.

Theorem numbers refer to the paper.

  verify.py   Lemma B.1 (frame amplification), Theorem 3.2 (variance bound, v_n),
              elementary inequalities of Appendix B, the lower bound on Z_c, beta(n),
              and a finite element check of Theorems 3.2, 3.6 and Corollary 3.4
  verify2.py  precision of the Lemma B.1 identity, grid convergence, small-c sharpness
              ratio and the exponent fits for n = 2..5 (Theorem 3.6)
  verify3.py  Theorem 3.5: Laplacian identity, r coth r <= 1 + r^2/3, the closed form
              1 + n/E[sinh^2 r], its limit, and lambda_1 <= bound at 18 points
  verify4.py  Theorem 3.7: radial gap >= c (Proposition 3.3 with Bakry--Emery), the
              capacity kappa_c (ODE against finite elements, kappa_0(2) = 1), the Hardy
              constant D_c on random functions, and the bound against lambda_1 on H^2 and H^3

Each script prints PASS/FAIL lines; this runner collects them.  Known benign failures
are listed in BENIGN with the reason.  Total runtime is a few minutes on one core.
"""
import subprocess, sys, re, time

SCRIPTS = ["verify.py", "verify2.py", "verify3.py", "verify4.py"]
BENIGN = {
    "verify.py": ["identity max error",            # float64 cancellation at r=8; exact at 60 digits (verify2 W1)
                  "branch switches at n=4"],       # beta(2)=0 is vacuous; n=2 is stated separately
    "verify4.py": ["n=3 c= 0.05"],                 # finite element eigenvalue below solver precision
}
summary = []
for s in SCRIPTS:
    t0 = time.time()
    out = subprocess.run([sys.executable, s], capture_output=True, text=True, env={"OPENBLAS_NUM_THREADS": "1", "PATH": "/usr/bin:/bin:/usr/local/bin"}).stdout
    lines = out.splitlines()
    passes = sum("PASS" in ln for ln in lines)
    fails = [ln for ln in lines if "FAIL" in ln]
    benign = [ln for ln in fails if any(b in ln for b in BENIGN.get(s, []))]
    real = [ln for ln in fails if ln not in benign]
    summary.append((s, passes, len(benign), real, time.time() - t0))
    print(out)
print("=" * 78)
print(f"{'script':12s} {'PASS':>5s} {'benign':>7s} {'FAIL':>5s}   time")
for s, p, b, real, dt in summary:
    print(f"{s:12s} {p:5d} {b:7d} {len(real):5d}   {dt/60:.1f} min")
    for ln in real: print("    " + ln.strip())
print("=" * 78)
print("ALL CHECKS PASSED" if all(not real for _, _, _, real, _ in summary) else "SOME CHECKS FAILED")
