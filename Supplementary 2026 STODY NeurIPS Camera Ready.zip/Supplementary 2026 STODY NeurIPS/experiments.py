"""Experiments for "Diffusion on hyperbolic space with a curvature-determined
confinement" (NeurIPS 2026 workshop submission, AI for Stochastic Dynamics).

All experiments run on a single CPU. Seeded and self-testing.

  Experiment 1  Forward mixing on H^2 as a function of the confinement c
                (validates the spectral-gap collapse below c = n-1).
  Experiment 2  Small score-based generative models on hierarchical data:
                (A) intrinsic confined diffusion, c = 2 (above threshold)
                (B) intrinsic confined diffusion, c = 0.25 (below threshold)
                (C) tangent-space wrapped baseline (Euclidean VP in T_o H^2)

Model: hyperboloid H^2 = {x in R^3 : <x,x>_L = -1, x_3 > 0},
<u,v>_L = u1 v1 + u2 v2 - u3 v3.
"""

import json
import numpy as np

rng = np.random.default_rng(0)
ETA = np.array([1.0, 1.0, -1.0])  # Minkowski signature
O_PT = np.array([0.0, 0.0, 1.0])  # base point o

# ----------------------------------------------------------------------------
# Hyperboloid utilities (vectorised over leading axes; last axis = 3)
# ----------------------------------------------------------------------------

def mink(u, v):
    return (u * v * ETA).sum(-1)

def normalize(x):
    """Project back onto H^2. The time coordinate is reconstructed from the
    space part, x3 = sqrt(1 + x1^2 + x2^2), which avoids the catastrophic
    cancellation in <x,x>_L at large radius."""
    x = x.copy()
    x[..., 2] = np.sqrt(1.0 + x[..., 0] ** 2 + x[..., 1] ** 2)
    return x

def dist(x, y):
    """d(x,y) = arccosh(1 + q), q = <x-y, x-y>_L / 2.  The difference form
    avoids cancellation between large coordinates of nearby far-out points."""
    d = x - y
    q = np.maximum(0.5 * mink(d, d), 0.0)
    small = q < 1e-8
    return np.where(small, np.sqrt(2.0 * q), np.arccosh(1.0 + np.where(small, 0.0, q)))

def r_of(x):
    """d(o, x) = arcsinh(|space part|); exact and stable at any radius."""
    return np.arcsinh(np.hypot(x[..., 0], x[..., 1]))

def _sinch(d):
    """sinh(d)/d, stable near 0."""
    small = d < 1e-6
    out = np.where(small, 1.0 + d * d / 6.0, np.sinh(np.where(small, 1.0, d)) / np.where(small, 1.0, d))
    return out

def expmap(x, v):
    """Riemannian exponential map at x applied to tangent v."""
    nv = np.sqrt(np.maximum(mink(v, v), 0.0))
    c1 = np.cosh(nv)[..., None]
    c2 = _sinch(nv)[..., None]
    return normalize(c1 * x + c2 * v)

def logmap(x, y):
    """Riemannian log map: tangent vector at x pointing to y with |v| = d(x,y).

    log_x(y) = d * u / |u| with u = y + <x,y>_L x and |u| = sinh(d),
    i.e. log_x(y) = u / sinch(d)."""
    d = dist(x, y)
    u = y + mink(x, y)[..., None] * x
    return u / _sinch(d)[..., None]

def grad_r(x):
    """Riemannian gradient of r(x) = d(o, x); zero at o."""
    r = r_of(x)
    v = np.cosh(r)[..., None] * x - O_PT
    s = np.maximum(np.sinh(r), 1e-12)[..., None]
    g = v / s
    g[r < 1e-8] = 0.0
    return g, r

def tangent_gauss(x, rng_):
    """Isotropic standard Gaussian in T_x H^2 via parallel transport from o."""
    xi = rng_.standard_normal(x.shape[:-1] + (2,))
    e1 = np.broadcast_to(np.array([1.0, 0.0, 0.0]), x.shape).copy()
    e2 = np.broadcast_to(np.array([0.0, 1.0, 0.0]), x.shape).copy()
    v = xi[..., :1] * e1 + xi[..., 1:2] * e2   # tangent at o
    # parallel transport o -> x:  v + <x, v>_L (o + x) / (1 - <o, x>_L)
    a = mink(x, v)[..., None] / (1.0 - mink(np.broadcast_to(O_PT, x.shape), x))[..., None]
    return v + a * (O_PT + x)

def to_disk(x):
    """Hyperboloid -> Poincare disk."""
    return x[..., :2] / (1.0 + x[..., 2:3])

def forward_step(x, c, h, rng_, clip=None):
    g, r = grad_r(x)
    drift = -(c * r)[..., None] * g
    v = drift * h + np.sqrt(2.0 * h) * tangent_gauss(x, rng_)
    if clip is not None:
        nv = np.sqrt(np.maximum(mink(v, v), 0.0))
        fac = np.minimum(1.0, clip / np.maximum(nv, 1e-12))
        v = v * fac[..., None]
    return expmap(x, v)

def sample_prior(c, n, rng_, rmax=14.0, grid=8000):
    """Numerically sample mu_c on H^2 by gridded inverse CDF of the radial density."""
    r = np.linspace(1e-6, rmax, grid)
    pdf = np.sinh(r) * np.exp(-0.5 * c * r * r)
    cdf = np.cumsum(pdf); cdf /= cdf[-1]
    u = rng_.uniform(size=n)
    rr = np.interp(u, cdf, r)
    th = rng_.uniform(0, 2 * np.pi, size=n)
    v = np.stack([rr * np.cos(th), rr * np.sin(th), np.zeros(n)], -1)
    return expmap(np.broadcast_to(O_PT, (n, 3)).copy(), v)

# ----------------------------------------------------------------------------
# Self-tests
# ----------------------------------------------------------------------------

def self_test():
    x = sample_prior(1.0, 500, np.random.default_rng(1))
    assert np.max(np.abs(mink(x, x) + 1)) < 1e-9
    v = tangent_gauss(x, np.random.default_rng(2))
    assert np.max(np.abs(mink(v, x))) < 1e-8, "transport not tangent"
    y = expmap(x, v)
    w = logmap(y, x)  # log back
    x2 = expmap(y, w)
    assert np.max(dist(x2, x)) < 1e-6, "exp/log inverse failed"
    nv = np.sqrt(mink(v, v)); d = dist(x, y)
    assert np.max(np.abs(nv - d)) < 1e-6, "|v| != d(x, exp_x v)"
    print("[self-test] geometry OK")

# ----------------------------------------------------------------------------
# Experiment 1: forward mixing vs confinement c
# ----------------------------------------------------------------------------

def experiment1():
    N, h, T = 20000, 0.005, 6.0
    K = int(T / h)
    cs = [0.05, 0.1, 0.25, 0.5, 1.0, 2.0, 4.0]
    r0, sig0 = 3.0, 0.2
    out = {"t": [], "R": {}, "Er": {}, "rate": {}, "c": cs, "T": T, "h": h, "N": N}
    ts = np.arange(K + 1) * h
    out["t"] = ts.tolist()

    def rstar(c):
        lo, hi = 1e-3, 80.0
        for _ in range(200):
            mid = 0.5 * (lo + hi)
            if c * mid < 1.0 / np.tanh(mid): lo = mid
            else: hi = mid
        return 0.5 * (lo + hi)

    def run_polar(c, r_init, tag, rg):
        """Exact polar SDE on H^2: dr = (coth r - c r) dt + sqrt(2) dW_r,
        dphi = (sqrt(2)/sinh r) dW_phi; reflect r at 0 (Bessel-type)."""
        r = np.full(N, r_init) + sig0 * rg.standard_normal(N)
        r = np.abs(r)
        phi = (sig0 / max(np.sinh(r_init), 1e-9)) * rg.standard_normal(N)
        R, Er = [], []
        for k in range(K + 1):
            R.append(float(np.abs(np.exp(1j * phi).mean())))
            Er.append(float(r.mean()))
            if k < K:
                drift = 1.0 / np.tanh(np.maximum(r, 1e-9)) - c * r
                drift = np.clip(drift, -50.0, 50.0)
                r = np.abs(r + drift * h + np.sqrt(2 * h) * rg.standard_normal(N))
                phi = phi + (np.sqrt(2 * h) / np.sinh(np.maximum(r, 1e-9))) * rg.standard_normal(N)
        R = np.array(R); Er = np.array(Er)
        floor = 5.0 / np.sqrt(N)
        mask = (ts >= 1.0) & (R > max(0.03, floor))
        if mask.sum() >= 10 and (R[ts >= 1.0][0] - R[-1]) > 0.02:
            A = np.vstack([ts[mask], np.ones(mask.sum())]).T
            slope = np.linalg.lstsq(A, np.log(R[mask]), rcond=None)[0][0]
            rate = -float(slope)
        else:
            rate = float("nan")
        print(f"[exp1:{tag}] c={c}: R(T)={R[-1]:.4f}  E r(T)={Er[-1]:.3f}  rate={rate:.5f}")
        return R, Er, rate

    for c in cs:
        R, Er, _ = run_polar(c, r0, "r0=3", np.random.default_rng(100 + int(c * 1000)))
        out["R"][str(c)] = R.tolist()
        out["Er"][str(c)] = Er.tolist()
        _, _, rate = run_polar(c, rstar(c), "r*", np.random.default_rng(500 + int(c * 1000)))
        out["rate"][str(c)] = rate
        out.setdefault("rstar", {})[str(c)] = rstar(c)

    # cross-check: hyperboloid integrator agrees where it is well conditioned
    rg = np.random.default_rng(9)
    v0 = np.stack([np.full(4000, 3.0), np.zeros(4000), np.zeros(4000)], -1)
    x = expmap(np.broadcast_to(O_PT, (4000, 3)).copy(), v0)
    x = expmap(x, sig0 * tangent_gauss(x, rg))
    for k in range(K):
        x = forward_step(x, 1.0, h, rg, clip=5.0)
    phi = np.arctan2(x[:, 1], x[:, 0])
    out["xcheck_hyperboloid_R_c1"] = float(np.abs(np.exp(1j * phi).mean()))
    print(f"[exp1] hyperboloid cross-check c=1: R(T)={out['xcheck_hyperboloid_R_c1']:.4f} "
          f"(polar gave {out['R'][str(1.0)][-1]:.4f})")

    # floating-point conditioning of the extrinsic representation
    cond = {}
    for prec, dt in [("fp32", np.float32), ("fp64", np.float64)]:
        errs = []
        for rr in [2, 5, 8, 12, 16, 20, 24]:
            th = np.linspace(0, 2 * np.pi, 512, endpoint=False)
            xx = np.stack([np.sinh(rr) * np.cos(th), np.sinh(rr) * np.sin(th),
                           np.cosh(rr) * np.ones_like(th)], -1).astype(dt)
            errs.append(float(np.max(np.abs(mink(xx, xx) + 1))))
        cond[prec] = errs
        print(f"[exp1] |<x,x>_L+1| at r=2,5,8,12,16,20,24 ({prec}): " +
              " ".join(f"{e:.1e}" for e in errs))
    out["constraint_error_radii"] = [2, 5, 8, 12, 16, 20, 24]
    out["constraint_error"] = cond

    # drift of the constraint without re-projection (moderate radius)
    for prec, dt in [("fp32", np.float32), ("fp64", np.float64)]:
        rg = np.random.default_rng(7)
        x = sample_prior(2.0, 2000, rg).astype(dt)
        drift_max = 0.0
        for k in range(400):
            g, r = grad_r(x)
            v = (-(2.0 * r)[..., None] * g * 0.01 + np.sqrt(0.02) * tangent_gauss(x, rg)).astype(dt)
            nv = np.sqrt(np.maximum(mink(v, v), 0.0))
            x = (np.cosh(nv)[..., None] * x + _sinch(nv)[..., None] * v).astype(dt)
            drift_max = max(drift_max, float(np.max(np.abs(mink(x, x) + 1))))
        out[f"constraint_drift_{prec}"] = drift_max
        print(f"[exp1] max |<x,x>+1| over 400 unprojected steps ({prec}): {drift_max:.2e}")
    return out

# ----------------------------------------------------------------------------
# MLP with manual backprop (numpy), Adam
# ----------------------------------------------------------------------------

class MLP:
    def __init__(self, din, dh, dout, rng_):
        s = rng_
        self.p = {
            "W1": s.standard_normal((din, dh)) * np.sqrt(2 / din),
            "b1": np.zeros(dh),
            "W2": s.standard_normal((dh, dh)) * np.sqrt(2 / dh),
            "b2": np.zeros(dh),
            "W3": s.standard_normal((dh, dout)) * np.sqrt(1 / dh),
            "b3": np.zeros(dout),
        }
        self.m = {k: np.zeros_like(v) for k, v in self.p.items()}
        self.v = {k: np.zeros_like(v) for k, v in self.p.items()}
        self.tstep = 0

    def save(self, path):
        np.savez(path, **self.p)

    @classmethod
    def load(cls, path, din, dh, dout):
        net = cls(din, dh, dout, np.random.default_rng(0))
        z = np.load(path)
        net.p = {k: z[k] for k in net.p}
        return net

    def forward(self, X):
        p = self.p
        self.z1 = X @ p["W1"] + p["b1"]; self.a1 = np.tanh(self.z1)
        self.z2 = self.a1 @ p["W2"] + p["b2"]; self.a2 = np.tanh(self.z2)
        self.X = X
        return self.a2 @ p["W3"] + p["b3"]

    def backward(self, gout):
        p, g = self.p, {}
        g["W3"] = self.a2.T @ gout; g["b3"] = gout.sum(0)
        da2 = gout @ p["W3"].T; dz2 = da2 * (1 - self.a2 ** 2)
        g["W2"] = self.a1.T @ dz2; g["b2"] = dz2.sum(0)
        da1 = dz2 @ p["W2"].T; dz1 = da1 * (1 - self.a1 ** 2)
        g["W1"] = self.X.T @ dz1; g["b1"] = dz1.sum(0)
        return g

    def adam(self, g, lr=1e-3, b1=0.9, b2=0.999, eps=1e-8):
        self.tstep += 1
        for k in self.p:
            self.m[k] = b1 * self.m[k] + (1 - b1) * g[k]
            self.v[k] = b2 * self.v[k] + (1 - b2) * g[k] ** 2
            mh = self.m[k] / (1 - b1 ** self.tstep)
            vh = self.v[k] / (1 - b2 ** self.tstep)
            self.p[k] -= lr * mh / (np.sqrt(vh) + eps)

def timefeat(t, T):
    w = 2 * np.pi * np.arange(1, 5)
    tt = (t / T)[..., None]
    return np.concatenate([tt, np.sin(tt * w), np.cos(tt * w)], -1)

def net_gradcheck():
    rg = np.random.default_rng(3)
    net = MLP(5, 16, 3, rg)
    X = rg.standard_normal((4, 5)); Y = rg.standard_normal((4, 3))
    out = net.forward(X)
    g = net.backward(2 * (out - Y) / out.size)
    k, idx = "W2", (1, 2)
    epsv = 1e-6; old = net.p[k][idx]
    net.p[k][idx] = old + epsv; Lp = ((net.forward(X) - Y) ** 2).mean()
    net.p[k][idx] = old - epsv; Lm = ((net.forward(X) - Y) ** 2).mean()
    net.p[k][idx] = old
    num = (Lp - Lm) / (2 * epsv)
    ana = g[k][idx]
    assert abs(num - ana) / (abs(num) + 1e-9) < 1e-4, (num, ana)
    print("[self-test] MLP gradients OK")

# ----------------------------------------------------------------------------
# Experiment 2: generative models on hierarchical data
# ----------------------------------------------------------------------------

GROUP_W = np.array([0.4, 0.3, 0.2, 0.1])
LEAF_W = np.repeat(GROUP_W / 2.0, 2)

def make_tree_data(n, rng_):
    """Two-level hierarchy: 4 groups (weights 0.4/0.3/0.2/0.1) x 2 leaves,
    leaves near radius 3.5."""
    group = rng_.choice(4, size=n, p=GROUP_W)
    leaf = rng_.integers(0, 2, n)
    base = group * (np.pi / 2)
    th = base + (leaf - 0.5) * 0.35
    rr = 3.5 + 0.0 * th
    v = np.stack([rr * np.cos(th), rr * np.sin(th), np.zeros(n)], -1)
    x = expmap(np.broadcast_to(O_PT, (n, 3)).copy(), v)
    return expmap(x, 0.15 * tangent_gauss(x, rng_)), (group * 2 + leaf)

def leaf_centres():
    g = np.repeat(np.arange(4), 2); l = np.tile(np.arange(2), 4)
    th = g * (np.pi / 2) + (l - 0.5) * 0.35
    v = np.stack([3.5 * np.cos(th), 3.5 * np.sin(th), np.zeros(8)], -1)
    return expmap(np.broadcast_to(O_PT, (8, 3)).copy(), v)

def simulate_paths(x0, c, h, K, rng_):
    N = x0.shape[0]
    paths = np.empty((K + 1, N, 3), np.float64)
    paths[0] = x0
    x = x0.copy()
    for k in range(K):
        x = forward_step(x, c, h, rng_)
        paths[k + 1] = x
    return paths

RFEAT = 12.0   # input clip for the radial feature (net opinion is irrelevant beyond)

def frame(x):
    """Global orthonormal frame on H^2 minus the origin: e_r = grad r (unit),
    e_phi = (-sin phi, cos phi, 0). Returns e_r, e_phi, r, cos phi, sin phi."""
    er, r = grad_r(x)
    sp = x[..., :2]
    nrm = np.maximum(np.linalg.norm(sp, axis=-1, keepdims=True), 1e-12)
    cs = sp / nrm                       # (cos phi, sin phi)
    ephi = np.stack([-cs[..., 1], cs[..., 0], np.zeros_like(cs[..., 0])], -1)
    return er, ephi, r, cs

def ang_feats(cs):
    """Fourier features cos(k phi), sin(k phi) for k=1,2,4,8 via angle doubling."""
    c1, s1 = cs[..., 0], cs[..., 1]
    out = [c1, s1]
    c, s = c1, s1
    for _ in range(3):
        c, s = c * c - s * s, 2 * c * s
        out += [c, s]
    return np.stack(out, -1)

def feats(x, t, T):
    er, ephi, r, cs = frame(x)
    F = np.concatenate([np.minimum(r, RFEAT)[..., None], ang_feats(cs),
                        timefeat(t, T)], -1)
    return F, er, ephi, r

DIN_I = 1 + 8 + 9      # intrinsic net input width
DIN_T = 3 + 8 + 9      # tangent-baseline net input width

def tangent_feats(y, t, T):
    ny = np.linalg.norm(y, axis=-1, keepdims=True)
    cs = y / np.maximum(ny, 1e-12)
    return np.concatenate([y, ny, ang_feats(cs), timefeat(t, T)], -1)

SPANS = np.array([1, 2, 4, 8])

def train_intrinsic(paths, c, h, T, iters=30000, bs=512, lr=1e-3, seed=11):
    rg = np.random.default_rng(seed)
    K = paths.shape[0] - 1
    net = MLP(DIN_I, 128, 2, rg)
    losses = []
    for it in range(iters):
        i = rg.integers(0, paths.shape[1], bs)
        m = SPANS[rg.integers(0, len(SPANS), bs)]
        k = rg.integers(0, K + 1 - m, bs)                    # start index
        xp = paths[k, i]                                     # x_k
        xc = paths[k + m, i]                                 # x_{k+m}
        tau = (m * h)[:, None]
        # conditional-mean approximation: m drift-only steps from x_k
        z = xp.copy()
        remaining = m.copy()
        for step in range(int(SPANS.max())):
            act = remaining > 0
            if not act.any():
                break
            g, r = grad_r(z[act])
            z[act] = normalize(expmap(z[act], -(c * r)[..., None] * g * h))
            remaining = remaining - 1
        tgt = logmap(xc, z) / np.sqrt(2 * tau)               # O(1) noise target
        # anchored + frame parameterisation: s_theta = -grad W_c + (a e_r + b e_phi)
        F, er, ephi, rc = feats(xc, (k + m) * h, T)
        ab = net.forward(F)
        sres = ab[..., :1] * er + ab[..., 1:] * ephi
        spred = -(c * rc)[..., None] * er + sres
        e = np.sqrt(2 * tau) * spred - tgt
        L = float(np.mean(mink(e, e)))
        # chain rule: dL/da = 2 sqrt(2 tau) <e,e_r>, similarly for b
        w = 2 * np.sqrt(2 * tau)[..., 0] / bs
        gout = np.stack([w * mink(e, er), w * mink(e, ephi)], -1)
        g_par = net.backward(gout)
        net.adam(g_par, lr=lr * (0.3 if it >= 20000 else 1.0))
        losses.append(L)
        if (it + 1) % 5000 == 0:
            print(f"[train c={c}] iter {it+1}: loss {np.mean(losses[-500:]):.4f}")
    return net

RWALL = 30.0   # numerical wall, far beyond data (r~3.5) and the divergence threshold (r>6)

def rwall(x):
    """Rescale spatial part so r <= RWALL. Purely numerical: keeps floats finite;
    diverged mass still registers honestly in frac_r_gt6 / MMD."""
    r = r_of(x)
    bad = r > RWALL
    if bad.any():
        sp = np.sinh(RWALL) / np.sinh(r[bad])
        x[bad, :2] *= sp[..., None]
        x[bad] = normalize(x[bad])
    return x

def sample_intrinsic(net, c, h, K, T, n, rng_, dmax=50.0, vcap=0.5):
    x = sample_prior(c, n, rng_)
    for k in range(K, 0, -1):
        F, er, ephi, r = feats(x, np.full(n, k * h), T)
        ab = net.forward(F)
        sres = ab[..., :1] * er + ab[..., 1:] * ephi
        s = -(c * r)[..., None] * er + sres
        drift = (c * r)[..., None] * er + 2.0 * s
        nd = np.sqrt(np.maximum(mink(drift, drift), 0.0))
        drift *= np.minimum(1.0, dmax / np.maximum(nd, 1e-12))[..., None]
        v = drift * h + np.sqrt(2 * h) * tangent_gauss(x, rng_)
        nv = np.sqrt(np.maximum(mink(v, v), 0.0))
        v *= np.minimum(1.0, vcap / np.maximum(nv, 1e-12))[..., None]
        x = rwall(normalize(expmap(x, v)))
    return x

def train_tangent_baseline(X, iters=30000, bs=512, lr=1e-3, seed=12, T=4.0):
    """Euclidean VP (OU) in T_o H^2 on y = log_o(x); exact DSM, same features/budget."""
    rg = np.random.default_rng(seed)
    Y = logmap(np.broadcast_to(O_PT, X.shape).copy(), X)[:, :2]
    net = MLP(DIN_T, 128, 2, rg)
    for it in range(iters):
        i = rg.integers(0, Y.shape[0], bs)
        t = rg.uniform(0.01, T, bs)
        al = np.exp(-t)[:, None]; sg = np.sqrt(1 - np.exp(-2 * t))[:, None]
        ep = rg.standard_normal((bs, 2))
        yt = al * Y[i] + sg * ep
        F = tangent_feats(yt, t, T)
        eh = net.forward(F)
        e = eh - ep
        L = float(np.mean(e ** 2))
        gout = 2 * e / e.size
        net.adam(net.backward(gout), lr=lr * (0.3 if it >= 20000 else 1.0))
        if (it + 1) % 5000 == 0:
            print(f"[train tangent] iter {it+1}: loss {L:.4f}")
    return net, Y

def sample_tangent(net, n, rng_, T=4.0, K=400):
    h = T / K
    y = rng_.standard_normal((n, 2))
    for k in range(K, 0, -1):
        t = np.full(n, k * h)
        sg = np.sqrt(1 - np.exp(-2 * t))[:, None]
        F = tangent_feats(y, t, T)
        score = -net.forward(F) / sg
        y = y + (y + 2 * score) * h + np.sqrt(2 * h) * rng_.standard_normal((n, 2))
    ny = np.linalg.norm(y, axis=-1, keepdims=True)
    y = y * np.minimum(1.0, RWALL / np.maximum(ny, 1e-12))
    v = np.concatenate([y, np.zeros((n, 1))], -1)
    return expmap(np.broadcast_to(O_PT, (n, 3)).copy(), v)

def mmd2(Xa, Xb, sig2, chunk=1024):
    def K(A, B):
        tot = 0.0
        for i in range(0, A.shape[0], chunk):
            d = dist(A[i:i + chunk, None, :], B[None, :, :])
            tot += np.exp(-d ** 2 / (2 * sig2)).sum()
        return tot
    na, nb = len(Xa), len(Xb)
    kaa = (K(Xa, Xa) - na) / (na * (na - 1))
    kbb = (K(Xb, Xb) - nb) / (nb * (nb - 1))
    kab = K(Xa, Xb) / (na * nb)
    return kaa + kbb - 2 * kab

def circ_R4(x):
    phi = np.arctan2(x[:, 1], x[:, 0])
    return float(np.abs(np.exp(4j * phi).mean()))

def eval_samples(name, S, Xtest, centres, sig2, res):
    d = dist(S[:, None, :], centres[None, :, :])
    assign = d.argmin(1)
    frac = np.bincount(assign, minlength=8) / len(S)
    dev = 0.5 * float(np.abs(frac - LEAF_W).sum())   # TV distance to true leaf weights
    m = float(mmd2(S, Xtest, sig2))
    far = float((r_of(S) > 6.0).mean())
    res[name] = {"mmd2": m, "leaf_tv": dev, "frac_r_gt6": far,
                 "leaf_frac": frac.tolist()}
    print(f"[eval {name}] MMD^2={m:.5f}  leaf TV={dev:.3f}  frac r>6={far:.4f}")
    return res

T2, H2 = 4.0, 0.01
K2 = int(T2 / H2)
SEEDS = {2.0: 21, 0.25: 22}

def exp2_setup():
    rgd = np.random.default_rng(42)
    Xtr, _ = make_tree_data(8192, rgd)
    Xte, _ = make_tree_data(4096, rgd)
    centres = leaf_centres()
    sub = Xte[:512]
    dd = dist(sub[:, None, :], sub[None, :, :])
    sig2 = float(np.median(dd[dd > 0]) ** 2)
    return Xtr, Xte, centres, sig2

def res2_load():
    try:
        return json.load(open("res2.json"))
    except FileNotFoundError:
        return {}

def res2_save(res):
    json.dump(res, open("res2.json", "w"), indent=1)

def exp2_train(c):
    Xtr, Xte, centres, sig2 = exp2_setup()
    res = res2_load()
    res.update({"sig2": sig2, "T": T2, "h": H2, "R4_data": circ_R4(Xtr)})
    seed = SEEDS[c]
    rg = np.random.default_rng(seed)
    paths = simulate_paths(Xtr, c, H2, K2, rg)
    res[f"forward_R4_c{c}"] = circ_R4(paths[-1])
    res[f"forward_Er_c{c}"] = float(r_of(paths[-1]).mean())
    print(f"[exp2] forward endpoint at T={T2}, c={c}: R4={res[f'forward_R4_c{c}']:.4f} "
          f"(data {res['R4_data']:.3f}), E r={res[f'forward_Er_c{c}']:.3f}")
    net = train_intrinsic(paths, c, H2, T2, seed=seed)
    net.save(f"net_c{c}.npz")
    res2_save(res)
    print(f"[exp2] trained and saved net_c{c}.npz")

def exp2_sample(c):
    Xtr, Xte, centres, sig2 = exp2_setup()
    res = res2_load()
    seed = SEEDS[c]
    net = MLP.load(f"net_c{c}.npz", DIN_I, 128, 2)
    S = sample_intrinsic(net, c, H2, K2, T2, 4096, np.random.default_rng(seed + 100))
    eval_samples(f"intrinsic_c{c}", S, Xte, centres, sig2, res)
    json.dump(to_disk(S[:1500]).tolist(), open(f"samples_c{c}.json", "w"))
    res2_save(res)

def exp2_tangent():
    Xtr, Xte, centres, sig2 = exp2_setup()
    res = res2_load()
    netT, _ = train_tangent_baseline(Xtr, T=T2)
    netT.save("net_tangent.npz")
    ST = sample_tangent(netT, 4096, np.random.default_rng(31), T=T2, K=K2)
    eval_samples("tangent_baseline", ST, Xte, centres, sig2, res)
    json.dump(to_disk(ST[:1500]).tolist(), open("samples_tangent.json", "w"))
    json.dump(to_disk(Xte[:1500]).tolist(), open("samples_data.json", "w"))
    res2_save(res)

def exp2_repeats():
    Xtr, Xte, centres, sig2 = exp2_setup()
    res = res2_load()
    # direct prior-mismatch: MMD^2( forward endpoint at T , mu_c sample ), net-free
    for c in [2.0, 0.25]:
        rg = np.random.default_rng(SEEDS[c])
        endp = simulate_paths(Xtr, c, H2, K2, rg)[-1]
        P = sample_prior(c, 4096, np.random.default_rng(7))
        res[f"prior_mismatch_c{c}"] = float(mmd2(endp[:4096], P, sig2))
        print(f"[exp2] prior mismatch MMD^2 at T={T2}, c={c}: {res[f'prior_mismatch_c{c}']:.5f}")
    # seed-repeated sampling for error bars
    for c in [2.0, 0.25]:
        net = MLP.load(f"net_c{c}.npz", DIN_I, 128, 2)
        rows = []
        for sd in [100, 200, 300]:
            S = sample_intrinsic(net, c, H2, K2, T2, 4096, np.random.default_rng(SEEDS[c] + sd))
            r = {}
            eval_samples(f"tmp", S, Xte, centres, sig2, r)
            rows.append([r["tmp"]["mmd2"], r["tmp"]["leaf_tv"], r["tmp"]["frac_r_gt6"]])
        res[f"repeat_intrinsic_c{c}"] = rows
    netT = MLP.load("net_tangent.npz", DIN_T, 128, 2)
    rows = []
    for sd in [31, 131, 231]:
        ST = sample_tangent(netT, 4096, np.random.default_rng(sd), T=T2, K=K2)
        r = {}
        eval_samples("tmp", ST, Xte, centres, sig2, r)
        rows.append([r["tmp"]["mmd2"], r["tmp"]["leaf_tv"], r["tmp"]["frac_r_gt6"]])
    res["repeat_tangent"] = rows
    res2_save(res)
    import numpy as _np
    for key in ["repeat_intrinsic_c2.0", "repeat_intrinsic_c0.25", "repeat_tangent"]:
        a = _np.array(res[key])
        print(f"[repeats {key}] MMD^2 {a[:,0].mean():.5f}+-{a[:,0].std():.5f}  "
              f"TV {a[:,1].mean():.3f}+-{a[:,1].std():.3f}  div {a[:,2].mean():.4f}")

def exp2_assemble():
    r1 = json.load(open("r1.json"))
    res = res2_load()
    for tag in ["c2.0", "c0.25", "tangent", "data"]:
        res[f"samples_{tag}"] = json.load(open(f"samples_{tag}.json"))
    json.dump({"exp1": {k: v for k, v in r1.items() if k != "samples"},
               "exp2": {k: v for k, v in res.items() if not k.startswith("samples")}},
              open("results.json", "w"), indent=1)
    np.savez_compressed("plotdata.npz",
                        exp1=json.dumps(r1), exp2=json.dumps(res))
    print("assembled results.json + plotdata.npz")

# ----------------------------------------------------------------------------

def main():
    import sys, faulthandler
    faulthandler.enable()
    stage = sys.argv[1] if len(sys.argv) > 1 else "all"
    self_test()
    net_gradcheck()
    if stage == "1":
        r1 = experiment1()
        json.dump(r1, open("r1.json", "w")); print("stage1 done"); return
    if stage == "2a":   exp2_train(2.0)
    elif stage == "2b": exp2_sample(2.0)
    elif stage == "2c": exp2_train(0.25)
    elif stage == "2d": exp2_sample(0.25)
    elif stage == "2e": exp2_tangent()
    elif stage == "2g": exp2_repeats()
    elif stage == "2f": exp2_assemble()
    print(f"stage {stage} done")

if __name__ == "__main__":
    main()
