#!/bin/bash
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
for hier in A B; do
  python3 experiments_cr.py $hier prior
  for m in c2.0 c0.25 tangent c0.5 c1.0 c4.0; do
    for s in 0 1 2; do python3 experiments_cr.py $hier $m $s; done
  done
  python3 experiments_cr.py $hier assemble
  echo ALL_${hier}_DONE
done
