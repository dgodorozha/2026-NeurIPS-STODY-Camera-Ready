"""Experiments on H^3.

Geometry for the hyperboloid H^n in R^{n,1} (last axis n+1), the forward mixing
experiment on H^3 (threshold c = n-1 = 2), and a generative experiment on a
hierarchy of eight leaves on H^3 with the radial-plus-tangential head described in
Section 4.2: the residual is u = a e_r + (P_perp w, 0), where P_perp = I - theta theta^T
projects the network output w in R^n onto the tangent space of the unit sphere at
theta = x_spatial/|x_spatial|.  The map xi -> (xi, 0) is an isometry from T_theta S^{n-1}
onto the tangential part of T_x H^n, so |u|_g^2 = a^2 + |P_perp w|^2 is bounded by the
network output at every radius; no Minkowski projection of an ambient vector occurs.

usage:  python3 experiments_h3.py mix
        python3 experiments_h3.py prior
        python3 experiments_h3.py <model> <trainseed_index>   model in {c0.5, c1.0, c2.0, c4.0, c8.0, tangent}
        python3 experiments_h3.py assemble
"""
import json, sys, glob
import numpy as np
from experiments import MLP, timefeat, net_gradcheck

NDIM = 3
ETA = np.array([1.0] * NDIM + [-1.0])
O_PT = np.array([0.0] * NDIM + [1.0])

# ----------------------------------------------------------------------------- geometry
def mink(u, v): return (u * v * ETA).sum(-1)

def normalize(x):
    x = x.copy()
    x[..., NDIM] = np.sqrt(1.0 + (x[..., :NDIM] ** 2).sum(-1))
    return x

def dist(x, y):
    d = x - y
    q = np.maximum(0.5 * mink(d, d), 0.0)
    small = q < 1e-8
    return np.where(small, np.sqrt(2.0 * q), np.arccosh(1.0 + np.where(small, 0.0, q)))

def r_of(x): return np.arcsinh(np.linalg.norm(x[..., :NDIM], axis=-1))

def _sinch(d):
    small = d < 1e-6
    return np.where(small, 1.0 + d * d / 6.0, np.sinh(np.where(small, 1.0, d)) / np.where(small, 1.0, d))

def expmap(x, v):
    nv = np.sqrt(np.maximum(mink(v, v), 0.0))
    return normalize(np.cosh(nv)[..., None] * x + _sinch(nv)[..., None] * v)

def logmap(x, y):
    d = dist(x, y)
    u = y + mink(x, y)[..., None] * x
    return u / _sinch(d)[..., None]

def grad_r(x):
    r = r_of(x)
    v = np.cosh(r)[..., None] * x - O_PT
    g = v / np.maximum(np.sinh(r), 1e-12)[..., None]
    g[r < 1e-8] = 0.0
    return g, r

def tangent_gauss(x, rng_):
    xi = rng_.standard_normal(x.shape[:-1] + (NDIM,))
    v = np.concatenate([xi, np.zeros(x.shape[:-1] + (1,))], -1)      # tangent at o
    a = mink(x, v)[..., None] / (1.0 - mink(np.broadcast_to(O_PT, x.shape), x))[..., None]
    return v + a * (O_PT + x)                                           # transported to x

def forward_step(x, c, h, rng_):
    g, r = grad_r(x)
    v = -(c * r)[..., None] * g * h + np.sqrt(2.0 * h) * tangent_gauss(x, rng_)
    return expmap(x, v)

def sample_prior(c, n, rng_, rmax=16.0, grid=16000):
    r = np.linspace(1e-6, rmax, grid)
    pdf = np.sinh(r) ** (NDIM - 1) * np.exp(-0.5 * c * r * r)
    cdf = np.cumsum(pdf); cdf /= cdf[-1]
    rr = np.interp(rng_.uniform(size=n), cdf, r)
    th = rng_.standard_normal((n, NDIM)); th /= np.linalg.norm(th, axis=-1, keepdims=True)
    v = np.concatenate([rr[:, None] * th, np.zeros((n, 1))], -1)
    return expmap(np.broadcast_to(O_PT, (n, NDIM + 1)).copy(), v)

def self_test():
    x = sample_prior(1.0, 500, np.random.default_rng(1))
    assert np.max(np.abs(mink(x, x) + 1)) < 1e-9
    v = tangent_gauss(x, np.random.default_rng(2))
    assert np.max(np.abs(mink(v, x))) < 1e-8
    y = expmap(x, v); w = logmap(y, x); x2 = expmap(y, w)
    assert np.max(dist(x2, x)) < 1e-6
    assert np.max(np.abs(np.sqrt(mink(v, v)) - dist(x, y))) < 1e-6
    # the tangential head is an isometry: |(P w,0)|_g = |P w|
    th = x[:, :NDIM] / np.linalg.norm(x[:, :NDIM], axis=-1, keepdims=True)
    w = np.random.default_rng(3).standard_normal((500, NDIM))
    pw = w - (w * th).sum(-1, keepdims=True) * th
    u = np.concatenate([pw, np.zeros((500, 1))], -1)
    assert np.max(np.abs(mink(u, x))) < 1e-8 and np.max(np.abs(mink(u, u) - (pw ** 2).sum(-1))) < 1e-10
    print("[self-test] H^3 geometry and tangential head OK")

# ----------------------------------------------------------------------------- mixing
def experiment_mix():
    """Polar SDE on H^3: dr = (2 coth r - c r) dt + sqrt(2) dW, spherical Brownian motion
    on S^2 at speed sinh^{-2} r; observable R(t) = |E theta(t)| (first harmonic)."""
    N, h, T = 20000, 0.005, 6.0
    K = int(T / h); ts = np.arange(K + 1) * h
    cs = [0.1, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0]
    r0, sig0 = 3.0, 0.2
    out = {"t": ts.tolist(), "R": {}, "Er": {}, "rate": {}, "c": cs, "T": T, "h": h, "N": N, "n": NDIM}
    for c in cs:
        rg = np.random.default_rng(300 + int(c * 1000))
        r = np.abs(r0 + sig0 * rg.standard_normal(N))
        th = np.zeros((N, NDIM)); th[:, 0] = 1.0
        tv = rg.standard_normal((N, NDIM)); tv[:, 0] = 0.0
        th = th + (sig0 / np.sinh(r0)) * tv; th /= np.linalg.norm(th, axis=-1, keepdims=True)
        R, Er = [], []
        for k in range(K + 1):
            R.append(float(np.linalg.norm(th.mean(0)))); Er.append(float(r.mean()))
            if k < K:
                drift = np.clip((NDIM - 1) / np.tanh(np.maximum(r, 1e-9)) - c * r, -50.0, 50.0)
                r = np.abs(r + drift * h + np.sqrt(2 * h) * rg.standard_normal(N))
                xi = rg.standard_normal((N, NDIM)); xi -= (xi * th).sum(-1, keepdims=True) * th
                xi *= (np.sqrt(2 * h) / np.sinh(np.maximum(r, 1e-9)))[:, None]
                nv = np.linalg.norm(xi, axis=-1, keepdims=True)
                th = np.cos(nv) * th + np.sinc(nv / np.pi) * xi          # geodesic step on S^2
                th /= np.linalg.norm(th, axis=-1, keepdims=True)
        R = np.array(R)
        m = (R >= 0.05) & (R <= 0.7) & (ts > 0.05)
        if m.sum() >= 5:
            rate, ok = -float(np.polyfit(ts[m], np.log(R[m]), 1)[0]), True
        else:
            m2 = ts >= T / 2
            rate, ok = -float(np.polyfit(ts[m2], np.log(np.maximum(R[m2], 1e-12)), 1)[0]), False
        out["R"][str(c)] = R.tolist(); out["Er"][str(c)] = Er
        out["rate"][str(c)] = [rate, ok]
        print(f"[mix H^3] c={c}: R(T)={R[-1]:.4f}  E r(T)={Er[-1]:.3f}  rate={rate:.5f} window_ok={ok}", flush=True)
    json.dump(out, open("h3_mix.json", "w"))

# ----------------------------------------------------------------------------- data
GROUP_W = np.array([0.4, 0.3, 0.2, 0.1])
LEAF_W = np.repeat(GROUP_W / 2.0, 2)
TET = np.array([[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]], float) / np.sqrt(3)
TANG = np.array([[1, -1, 0], [1, 1, 0], [1, 1, 0], [1, -1, 0]], float) / np.sqrt(2)   # tangent at each vertex
assert np.max(np.abs((TET * TANG).sum(-1))) < 1e-12
RAD, OFF, NOISE = 3.5, 0.175, 0.15

def leaf_dirs():
    out = []
    for g in range(4):
        for l in range(2):
            d = (l - 0.5) * 2 * OFF
            out.append(np.cos(d) * TET[g] + np.sin(d) * TANG[g])
    return np.array(out)

def leaf_centres():
    v = np.concatenate([RAD * leaf_dirs(), np.zeros((8, 1))], -1)
    return expmap(np.broadcast_to(O_PT, (8, NDIM + 1)).copy(), v)

def make_tree_data(n, rng_):
    leaf = rng_.choice(8, size=n, p=LEAF_W)
    v = np.concatenate([RAD * leaf_dirs()[leaf], np.zeros((n, 1))], -1)
    x = expmap(np.broadcast_to(O_PT, (n, NDIM + 1)).copy(), v)
    return expmap(x, NOISE * tangent_gauss(x, rng_)), leaf

def setup():
    rgd = np.random.default_rng(44)
    Xtr, _ = make_tree_data(8192, rgd); Xte, _ = make_tree_data(4096, rgd)
    sub = Xte[:512]; dd = dist(sub[:, None, :], sub[None, :, :])
    return Xtr, Xte, leaf_centres(), LEAF_W, float(np.median(dd[dd > 0]))   # Laplacian bandwidth

# ----------------------------------------------------------------------------- model
RFEAT = 12.0
SPANS = np.array([1, 2, 4, 8])

def sph_feats(th):
    """theta and its degree two products: bounded features on S^2 (9 numbers)."""
    iu = np.triu_indices(NDIM)
    return np.concatenate([th, (th[..., :, None] * th[..., None, :])[..., iu[0], iu[1]]], -1)

def feats(x, t, T):
    er, r = grad_r(x)
    th = x[..., :NDIM] / np.maximum(np.linalg.norm(x[..., :NDIM], axis=-1, keepdims=True), 1e-12)
    F = np.concatenate([np.minimum(r, RFEAT)[..., None], sph_feats(th), timefeat(t, T)], -1)
    return F, er, th, r

DIN_I = 1 + NDIM + NDIM * (NDIM + 1) // 2 + 9      # 19
DOUT_I = 1 + NDIM                                  # a, w
DIN_T = NDIM + 1 + NDIM + NDIM * (NDIM + 1) // 2 + 9   # 22

def residual(ab, er, th):
    a, w = ab[..., :1], ab[..., 1:]
    pw = w - (w * th).sum(-1, keepdims=True) * th
    return a * er + np.concatenate([pw, np.zeros(pw.shape[:-1] + (1,))], -1)

def simulate_paths(x0, c, h, K, rng_):
    paths = np.empty((K + 1,) + x0.shape); paths[0] = x0; x = x0.copy()
    for k in range(K):
        x = forward_step(x, c, h, rng_); paths[k + 1] = x
    return paths

def train_intrinsic(paths, c, h, T, iters=30000, bs=512, lr=1e-3, seed=11):
    rg = np.random.default_rng(seed)
    K = paths.shape[0] - 1
    net = MLP(DIN_I, 128, DOUT_I, rg)
    losses = []
    for it in range(iters):
        i = rg.integers(0, paths.shape[1], bs)
        m = SPANS[rg.integers(0, len(SPANS), bs)]
        k = rg.integers(0, K + 1 - m, bs)
        xp, xc = paths[k, i], paths[k + m, i]
        tau = (m * h)[:, None]
        z = xp.copy(); remaining = m.copy()
        for _ in range(int(SPANS.max())):
            act = remaining > 0
            if not act.any(): break
            g, r = grad_r(z[act])
            z[act] = normalize(expmap(z[act], -(c * r)[..., None] * g * h))
            remaining = remaining - 1
        tgt = logmap(xc, z) / np.sqrt(2 * tau)
        F, er, th, rc = feats(xc, (k + m) * h, T)
        ab = net.forward(F)
        spred = -(c * rc)[..., None] * er + residual(ab, er, th)
        e = np.sqrt(2 * tau) * spred - tgt
        L = float(np.mean(mink(e, e)))
        w = 2 * np.sqrt(2 * tau)[..., 0] / bs
        esp = e[..., :NDIM]
        pesp = esp - (esp * th).sum(-1, keepdims=True) * th              # d<e,(P w,0)>_L / dw = P e_sp
        gout = np.concatenate([(w * mink(e, er))[:, None], w[:, None] * pesp], -1)
        net.adam(net.backward(gout), lr=lr * (0.3 if it >= 20000 else 1.0))
        losses.append(L)
        if (it + 1) % 5000 == 0:
            print(f"[train H^3 c={c}] iter {it+1}: loss {np.mean(losses[-500:]):.4f}", flush=True)
    return net, float(np.mean(losses[-500:]))

RWALL = 30.0
def rwall(x):
    r = r_of(x); bad = r > RWALL
    if bad.any():
        x[bad, :NDIM] *= (np.sinh(RWALL) / np.sinh(r[bad]))[:, None]; x[bad] = normalize(x[bad])
    return x

def sample_intrinsic(net, c, h, K, T, n, rng_, dmax=50.0, vcap=0.5):
    x = sample_prior(c, n, rng_)
    for k in range(K, 0, -1):
        F, er, th, r = feats(x, np.full(n, k * h), T)
        s = -(c * r)[..., None] * er + residual(net.forward(F), er, th)
        drift = (c * r)[..., None] * er + 2.0 * s
        nd = np.sqrt(np.maximum(mink(drift, drift), 0.0))
        drift *= np.minimum(1.0, dmax / np.maximum(nd, 1e-12))[..., None]
        v = drift * h + np.sqrt(2 * h) * tangent_gauss(x, rng_)
        nv = np.sqrt(np.maximum(mink(v, v), 0.0))
        v *= np.minimum(1.0, vcap / np.maximum(nv, 1e-12))[..., None]
        x = rwall(normalize(expmap(x, v)))
    return x

def tangent_feats(y, t, T):
    ny = np.linalg.norm(y, axis=-1, keepdims=True)
    return np.concatenate([y, ny, sph_feats(y / np.maximum(ny, 1e-12)), timefeat(t, T)], -1)

def train_tangent_baseline(X, iters=30000, bs=512, lr=1e-3, seed=12, T=4.0):
    rg = np.random.default_rng(seed)
    Y = logmap(np.broadcast_to(O_PT, X.shape).copy(), X)[:, :NDIM]
    net = MLP(DIN_T, 128, NDIM, rg)
    for it in range(iters):
        i = rg.integers(0, Y.shape[0], bs)
        t = rg.uniform(0.01, T, bs)
        al = np.exp(-t)[:, None]; sg = np.sqrt(1 - np.exp(-2 * t))[:, None]
        ep = rg.standard_normal((bs, NDIM))
        e = net.forward(tangent_feats(al * Y[i] + sg * ep, t, T)) - ep
        L = float(np.mean(e ** 2))
        net.adam(net.backward(2 * e / e.size), lr=lr * (0.3 if it >= 20000 else 1.0))
        if (it + 1) % 5000 == 0:
            print(f"[train H^3 tangent] iter {it+1}: loss {L:.4f}", flush=True)
    return net, L

def sample_tangent(net, n, rng_, T=4.0, K=400):
    h = T / K
    y = rng_.standard_normal((n, NDIM))
    for k in range(K, 0, -1):
        t = np.full(n, k * h); sg = np.sqrt(1 - np.exp(-2 * t))[:, None]
        score = -net.forward(tangent_feats(y, t, T)) / sg
        y = y + (y + 2 * score) * h + np.sqrt(2 * h) * rng_.standard_normal((n, NDIM))
    ny = np.linalg.norm(y, axis=-1, keepdims=True)
    y = y * np.minimum(1.0, RWALL / np.maximum(ny, 1e-12))
    return expmap(np.broadcast_to(O_PT, (n, NDIM + 1)).copy(), np.concatenate([y, np.zeros((n, 1))], -1))

def mmd2(Xa, Xb, bw, chunk=1024):
    """MMD^2 by the U-statistic formula with the geodesic Laplacian kernel exp(-d/bw) (positive
    definite on H^n); unbiased for a fixed bw only, and bw is chosen from the test data (Appendix C, "Metrics")."""
    def Ksum(A, B):
        tot = 0.0
        for i in range(0, A.shape[0], chunk):
            d = dist(A[i:i + chunk, None, :], B[None, :, :]); tot += np.exp(-d / bw).sum()
        return tot
    na, nb = len(Xa), len(Xb)
    return (Ksum(Xa, Xa) - na) / (na * (na - 1)) + (Ksum(Xb, Xb) - nb) / (nb * (nb - 1)) - 2 * Ksum(Xa, Xb) / (na * nb)

def evaluate(S, Xte, centres, W, sig2):
    frac = np.bincount(dist(S[:, None, :], centres[None, :, :]).argmin(1), minlength=len(W)) / len(S)
    return {"mmd2": float(mmd2(S, Xte, sig2)), "leaf_tv": 0.5 * float(np.abs(frac - W).sum()),
            "frac_r_gt6": float((r_of(S) > 6.0).mean()), "leaf_frac": frac.tolist()}

def order_param(x):
    th = x[:, :NDIM] / np.linalg.norm(x[:, :NDIM], axis=-1, keepdims=True)
    return float(np.linalg.norm(th.mean(0)))

T2, H2 = 4.0, 0.01
K2 = int(T2 / H2)
BASE = {"c0.5": 63, "c1.0": 64, "c2.0": 61, "c4.0": 65, "c8.0": 66, "tangent": 72}

def run(model, idx):
    Xtr, Xte, centres, W, sig2 = setup()
    tseed = BASE[model] + 1000 * idx; sseeds = [tseed + o for o in (100, 200, 300)]
    out = {"model": model, "train_seed": tseed, "samp_seeds": sseeds, "bandwidth": sig2}
    if model == "tangent":
        net, out["final_loss"] = train_tangent_baseline(Xtr, T=T2, seed=tseed)
        sampler = lambda n, s: sample_tangent(net, n, np.random.default_rng(s), T=T2, K=K2)
    else:
        c = float(model[1:])
        paths = simulate_paths(Xtr, c, H2, K2, np.random.default_rng(tseed))
        out["forward_Er"] = float(r_of(paths[-1]).mean())
        net, out["final_loss"] = train_intrinsic(paths, c, H2, T2, seed=tseed)
        sampler = lambda n, s: sample_intrinsic(net, c, H2, K2, T2, n, np.random.default_rng(s))
    sets = [sampler(4096, s) for s in sseeds]
    out["rows"] = [evaluate(S, Xte, centres, W, sig2) for S in sets]
    np.savez_compressed(f"h3_{model}_s{idx}_samples.npz", *sets)
    if idx == 0:
        S = sampler(1500, sseeds[0])
        json.dump({"r": r_of(S).tolist(), "dir": (S[:, :NDIM] / np.linalg.norm(S[:, :NDIM], axis=-1, keepdims=True)).tolist()},
                  open(f"h3_samples_{model}.json", "w"))
    json.dump(out, open(f"h3_{model}_s{idx}.json", "w"), indent=1)
    a = np.array([[r["mmd2"], r["leaf_tv"], r["frac_r_gt6"]] for r in out["rows"]])
    print(f"[H^3 {model} seed{idx}] MMD2 {a[:,0].mean():.5f}+-{a[:,0].std():.5f}  TV {a[:,1].mean():.3f}  div {a[:,2].mean():.4f}", flush=True)

def prior():
    Xtr, Xte, centres, W, sig2 = setup()
    out = {"sig2": sig2, "R1_data": order_param(Xtr)}
    json.dump({"r": r_of(Xte[:1500]).tolist(), "dir": (Xte[:1500, :NDIM] / np.linalg.norm(Xte[:1500, :NDIM], axis=-1, keepdims=True)).tolist()},
              open("h3_samples_data.json", "w"))
    for c in [0.5, 1.0, 2.0, 4.0, 8.0]:
        endp = simulate_paths(Xtr, c, H2, K2, np.random.default_rng(BASE[f"c{c}"]))[-1]
        P = sample_prior(c, 4096, np.random.default_rng(7))
        out[f"prior_mismatch_c{c}"] = float(mmd2(endp[:4096], P, sig2))
        np.savez_compressed(f"h3_endpoint_c{c}.npz", endp[:4096])
        out[f"forward_Er_c{c}"] = float(r_of(endp).mean()); out[f"forward_R1_c{c}"] = order_param(endp)
        print(f"[H^3 prior] c={c}: mismatch {out[f'prior_mismatch_c{c}']:.5f}  E r {out[f'forward_Er_c{c}']:.3f}  "
              f"R1 {out[f'forward_R1_c{c}']:.3f} (data {out['R1_data']:.3f})", flush=True)
    json.dump(out, open("h3_prior.json", "w"), indent=1)

def assemble():
    res = {"prior": json.load(open("h3_prior.json"))}
    for f in sorted(glob.glob("h3_c*_s[0-9].json") + glob.glob("h3_tangent_s[0-9].json")):
        d = json.load(open(f)); res.setdefault(d["model"], {})[str(d["train_seed"])] = d
    summary = {}
    for model, runs in res.items():
        if model == "prior": continue
        A = np.array([[r["mmd2"], r["leaf_tv"], r["frac_r_gt6"]] for d in runs.values() for r in d["rows"]])
        P = np.array([np.mean([[r["mmd2"], r["leaf_tv"], r["frac_r_gt6"]] for r in d["rows"]], 0) for d in runs.values()])
        summary[model] = {"n_train": len(runs), "n_total": len(A), "mean": A.mean(0).tolist(),
                          "std_all": A.std(0, ddof=1).tolist(),
                          "std_train": P.std(0, ddof=1).tolist() if len(P) > 1 else [0, 0, 0],
                          "per_train_mean": P.tolist()}
        print(f"[H^3 {model}] runs={len(runs)}  MMD2 {A[:,0].mean():.5f}+-{A[:,0].std(ddof=1):.5f}  "
              f"TV {A[:,1].mean():.3f}+-{A[:,1].std(ddof=1):.3f}  div {A[:,2].mean():.4f}")
    res["summary"] = summary
    json.dump(res, open("h3_all.json", "w"), indent=1)

if __name__ == "__main__":
    self_test(); net_gradcheck()
    stage = sys.argv[1]
    if stage == "mix": experiment_mix()
    elif stage == "prior": prior()
    elif stage == "assemble": assemble()
    else: run(stage, int(sys.argv[2]))
