# Supplementary material for "Diffusion on Hyperbolic Space with a Curvature Determined Confinement"

Prithika Narayanan, Daria Godorozha, Mateusz Mikołajczak, Aditya Shethwala. NeurIPS 2026 workshop AI for Stochastic Dynamics.

Repository: https://github.com/dgodorozha/2026-NeurIPS-STODY-Camera-Ready

Code and result files for the paper. Table, figure, section and theorem numbers refer to the paper.

## Environment

Python 3, `pip install -r requirements.txt` (NumPy 2 is required; the scripts use `numpy.trapezoid`). The WordNet pipeline additionally needs `gensim` and `nltk` with the WordNet corpus (`python -c "import nltk; nltk.download('wordnet')"`). All scripts run on a single CPU. Reported runs used NumPy 2.5.2, SciPy 1.18.1, SymPy 1.14.0, mpmath 1.3.0.

## Checking the theorems

    python verify_all.py
    python check_intertwine.py
    python check_largec.py
    python check_rs.py
    python check_extended.py

Expected: `verify_all.py` ends with `ALL CHECKS PASSED` (one benign failure at n = 3, c = 0.05, where the finite element eigenvalue is below floating point resolution; its output is in `verify_all.log`); every row of `check_intertwine.py` prints `ok=True`; the Richardson values at the end of each block of `check_largec.py` are 0.3556, 0.8889, 1.6000, 2.4890; `check_rs.py` ends with `equal: True`; `check_extended.py` gives lambda^(1) = 6.0350447e-10 and lambda^(0) - c = 6.0350447e-10 on H^5 at c = 0.25 and writes `extended.json`.

| Script | Checks or produces | Runtime |
|---|---|---|
| `verify.py` | Claim checks V1 to V6; the V6 table is Table 5 (numerical gaps on H^2, sharpened bound, simulated rates) | about a minute |
| `verify2.py` | Lemma B.1 in high precision, grid convergence, small c envelope, exponent fits quoted after Theorem 3.6 | about two minutes |
| `verify3.py` | Theorem 3.5; writes `largec_table.json` (Table 7) | 1 min |
| `verify4.py` | Theorem 3.7; writes `lowerbound_table.json` (Table 8) | 1 min |
| `verify_all.py` | runs the four scripts above and prints one summary | 3 min |
| `check_intertwine.py` | Proposition 3.3: lambda^(0) - lambda^(1) = c and the bound of Corollary 3.4 on H^n, n = 2..5 (Table 6) | about two minutes |
| `check_extended.py` | the same finite element discretisation solved in 40 digit arithmetic (mpmath) for the gaps where rounding in double precision dominates: the two entries of Table 6 below 1e-5 and the entries of Tables 8 and 9 below 1e-8; writes `extended.json`, which `make_numeric_tables.py` uses | about a minute |
| `check_largec.py` | Remark B.2 (Appendix B.9): lambda_1(c) - c against -2(n-1)/3 and the 1/c coefficient 4(n-1)(n+2)/45, c up to 256 | a few minutes |
| `check_rs.py` | Appendix B.9: symbolic derivation of both expansion coefficients by the ground state transform | seconds |
| `fem_lambda.py` | `fem.json`: finite element lambda_1(c) for n = 2, 3 and the exponent fits for n = 2..5 (Table 9) | 15 min |

## Relaxation experiments (Section 5.1, Appendix C)

| Script | Produces | Runtime |
|---|---|---|
| `experiments.py` | relaxation rates on H^2 and the constraint errors of Table 12 (`r1.json`, Figure 1), and the original models on hierarchy A (`res2.json`, `samples_*.json`, Figure 2) | under an hour |
| `exp1_highdim.py` | Table 10: simulated angular and radial relaxation rates on H^2, H^3, H^4 against the sector gaps | about 40 minutes at N = 200,000 |
| `exp1_h2_resolve.py` | Table 11: eigenfunction observables, step size scan and a second integrator on H^2 | about 50 minutes at N = 60,000 |
| `exp1_long.py` | `exp1_long.json`: runs on H^2 to several relaxation times at c = 0.25, 0.5 and 0.1 (Appendix C, "Observable and fits") | 25 min |
| `experiments_h3.py mix` | `h3_mix.json`: relaxation rates on H^3 with the hyperboloid integrator, an independent check of the H^3 rates (not in the paper; plotted in `diag_rates.pdf` and `diag_relax.pdf`) | 8 min |

`res2.json` also holds two entries, `ablation_ambient_unanchored_c2.0` and `ablation_ambient_anchored_c2.0`, from an earlier implementation of the extrinsic score heads; the released code does not reproduce them, and Table 13 reports the reproducible ablation instead (Appendix D).

## Generative experiments (Section 5.2, Appendix D)

| Script | Produces | Runtime (one core) |
|---|---|---|
| `experiments_cr.py {A,B} prior`, then `<model> <seed>` for model in `c0.25 c0.5 c1.0 c2.0 c4.0 tangent` and seed in `0 1 2`, then `assemble` | `cr_A_all.json`, `cr_B_all.json` (Tables 1 and 14, Figures 3a and 4) | 3 min per run, 18 runs per hierarchy |
| `experiments_h3.py prior`, `<model> <seed>` for model in `c0.5 c1.0 c2.0 c4.0 c8.0 tangent`, `assemble` | `h3_all.json` (Table 15, Figures 3b and 5) | 3 min per run |
| `experiments_tree.py prior`, `<model> <seed>` (seeds 0 to 4), `assemble` | `tree_all.json` (hierarchy C, Table 16, Figure 6) | 9 min per run |
| `make_wordnet_embedding.py` | `wn_embedding.npz`, `wn_tree.json` (gensim Poincaré embedding of the WordNet mammal subtree) | 4 min |
| `experiments_wordnet.py prior`, `<model> <seed>` (seeds 0 to 4), `assemble` | `wn_all.json` (hierarchy W, Table 16, Figure 7) | 9 min per run |
| `prior_mismatch_seeds.py` | `prior_mismatch_seeds.json`: the prior mismatch over three forward banks per confinement (the mismatch columns of Tables 1, 14, 15, 16) | 10 min |
| `sampler_caps.py {A,H3} <model>`, then `assemble` | `caps_*.json`, `sampler_caps.json`: fraction of capped reverse steps and MMD^2 at three reverse step sizes for the first training seed of every intrinsic model (Table 17) | 12 min per model |
| `experiments_tree_dense.py`, `experiments_tree_big.py`, `experiments_tree_fine.py` (`<model> <seed>`, `assemble`) | `tree_dense_all.json`, `tree_big_all.json`, `tree_fine_all.json`: the three diagnostics on hierarchy C (Appendix D, Figure 8) | 12, 70 and 15 min per run |
| `experiments_wordnet_full.py prior`, `<model> <seed>`, `assemble` | `wn_full_all.json`: hierarchy W at full radius with the caps raised (Appendix D) | 11 min per run |
| `ablation_cr.py {frame,ambient} [nocaps]`, `ablation_budget.py` | `ablation_cr_*.json`, `ablation_budget.json`: the three score heads at c = 2 on hierarchy A with everything else fixed, and the same heads against the training budget with and without the sampler's caps (Table 13) | 10 min each |
| `run_*.sh` | the drivers used for the reported runs (one or two workers; they `cd` to their own directory) | |

For each hierarchy run `prior` first, then the model runs in any order (they are independent and skip themselves if their output exists, so several workers can share the list), then `assemble`; for hierarchies C and W, `prior` also records the sampling floor (the test set scored against the training set) that Table 16 reports. The tables report, for every metric, the mean and standard deviation over training seeds of the per seed means, with the standard deviation over all sample sets in parentheses, and the prior mismatch as mean and standard deviation over the three forward banks of `prior_mismatch_seeds.json`.

## Tables and figures

| Script | Produces | Runtime |
|---|---|---|
| `make_tables.py h2 h3 scale main_noR4 caps ablation` | `tab_gen_main_noR4.tex` (Table 1), `tab_ablation.tex` (Table 13), `tab_gen.tex` (Table 14), `tab_gen_h3.tex` (Table 15), `tab_gen_scale.tex` (Table 16), `tab_caps.tex` (Table 17) | seconds |
| `make_numeric_tables.py` | `tab_largec.tex`, `tab_lower.tex`, `tab_sharp.tex` (Tables 7 to 9; entries below 1e-8 from `extended.json`) | seconds |
| `plots.py` | `fig_mixing.pdf`, `fig_samples.pdf` (Figures 1 and 2) | seconds |
| `plots_cr.py` | `fig_sweep.pdf`, `fig_samples_B.pdf`, `fig_h3.pdf` (Figures 3 to 5), and three diagnostic figures that are not in the paper: `diag_rates.pdf`, `diag_relax.pdf`, `diag_samples_A.pdf` | seconds |
| `plots_scale.py` | `fig_samples_C.pdf`, `fig_samples_W.pdf` (Figures 6 and 7) | 1 min |
| `plots_followup.py` | `fig_followup.pdf` (Figure 8) | 1 min |

Tables 1, 7 to 9 and 13 to 17 and all eight figures are regenerated from the files in this folder by the scripts in this table. Tables 5, 6 and 10 to 12 are typed from the output of `verify.py`, `check_intertwine.py`, `check_extended.py`, `exp1_highdim.py`, `exp1_h2_resolve.py` and `experiments.py`, and Tables 2 to 4 are part of the text.

## Files

- `tab_*.tex`, `fig_*.pdf`: generated tables and figures used in the paper.
- `r1.json`, `samples_*.json`: the results behind Figures 1 and 2 and Table 12; `res2.json`: the original hierarchy A models (see the note above).
- `<run>_s<seed>.json` and `*_all.json`: one file per training run (the raw results) and the aggregate that `assemble` builds from them; `*_prior.json`: the forward diagnostics.
- `fem.json`, `largec_table.json`, `lowerbound_table.json`, `extended.json`, `exp1_long.json`, `h3_mix.json`, `prior_mismatch_seeds.json`, `caps_*.json`, `sampler_caps.json`, `ablation_cr_*.json`, `ablation_budget.json`: the other results named in the tables above.
- `cr_samples_*.json`: Poincaré disk subsets of the hierarchy A and B samples (B in Figure 4, A in `diag_samples_A.pdf`); `h3_samples_*.json`: the H^3 samples of Figure 5; `tree_samples_*.json`, `wn_samples_*.json`: Poincaré disk subsets of the first sample set on hierarchies C and W, written by `assemble` for quick inspection.
- `tree_{c1.0,c0.25,tangent}_s0_samples.npz`, `wn_{c1.0,c0.25,tangent}_s0_samples.npz`, `tree_{big,fine}_{c1.0,tangent}_s0_samples.npz`: the ten sample sets behind Figures 6 to 8.
- `wn_embedding.npz`, `wn_tree.json`: the WordNet mammal embedding and tree behind hierarchy W.
- `verify_all.log`: output of `verify_all.py`.
- `requirements.txt`: Python dependencies.

The other 128 generated sample sets (`*_samples.npz`, about 36 MB) are not in this archive for size reasons; every metric in the tables is recomputable from them by rerunning the model runs above, and they are available from the authors.

## Scaling up on your own machine or in Colab

The model runs are embarrassingly parallel: start one worker per core, each looping over the
`<model> <seed>` list in a different order. In Colab, upload this folder, install
`gensim nltk` and run `nltk.download('wordnet')` once; the free tier's two cores give the
same throughput as the runs reported here.

Things to change, each a single constant at the top of the script:

- **More training seeds.** Seed indices give new training seeds (`BASE + 1000*idx`); `assemble`
  picks up every file it finds. Hierarchies C and W use indices 0 to 4 in the paper, the others 0 to 2.
- **Bigger networks or budgets.** `WIDTH` and `ITERS` in `experiments_tree.py` (hierarchy C) and,
  through it, `experiments_wordnet.py`; for hierarchies A and B the width is the `128` in
  `MLP(DIN_I, 128, 2, rg)` of `experiments.py` and the budget the `iters=30000` default. The
  learning rate is multiplied by 0.3 after 20k of 30k iterations (26.8k of 40k on C and W).
- **More data.** `NTRAIN` in `experiments_tree.py` and `experiments_wordnet.py`. The bank of
  forward trajectories is `(K+1) x NTRAIN x 3` doubles, so 131,072 points need 1.3 GB.
- **Finer angular resolution.** `KDOUBLE` (angular Fourier features at the doublings k = 1, 2, ..., 2^(KDOUBLE-1)),
  or the dense basis of `experiments_tree_dense.py` (`KMAX`), which is the first thing to try when
  the leaves within a branch are not resolved (Appendix D).
- **Other confinements or horizons.** The `BASE` seed table lists the confinements; `T2`, `H2`
  in `experiments.py` set the horizon and the step.
- **A different taxonomy.** `make_wordnet_embedding.py` takes any synset as the root
  (`wn.synset("mammal.n.01")`); the noun hierarchy below `entity.n.01` has 82,115 synsets and
  needs a few hours of embedding on one core. `RHO` and `NOISE` in `experiments_wordnet.py`
  set the radial rescaling and the cluster width.

## What each check in `verify_all.py` establishes

- Lemma B.1: the identity |P_x w|² = <w,w>_L + <x,w>_L² symbolically, and both bounds on
  200 × 400 random vectors at six radii.
- Theorem 3.1(ii): λ₁ ≥ c − (n−1) above the threshold against finite element values on H².
- Theorem 3.2: v_n against Monte Carlo variances of |z|, v_n ∈ (0, 1] for n ≤ 50, and
  λ₁ ≤ 1/Var(r) against finite element values.
- Theorem 3.5: Δx₁ = n x₁ symbolically for n = 2..5, r coth r ≤ 1 + r²/3, the closed form
  1 + n/E[sinh² r] against the Rayleigh quotient to 10⁻¹⁵, its limit c − 2(n−1)/3, and
  λ₁ ≤ bound at 18 points with λ₁ − c converging to the constant.
- Theorem 3.6: the exponent fits 0.48, 1.97, 3.94, 5.98 for n = 2..5 and the ratio to the
  envelope on H².
- Theorem 3.7: the radial gap ≥ c at 16 points (Proposition 3.3 with the one dimensional Bakry–Émery bound), κ_c by ODE against finite element
  minimisation and κ₀(2) = 1 exactly, the Hardy inequality on 40 random functions per setting,
  and the bound below λ₁ at every point, with a flat ratio on H².
