"""Hierarchy W at the full radius of its Poincare embedding (rho = 1, synsets mostly at radius
8 to 12) with the sampler's caps raised (drift cap 200, step cap 1.5 instead of 50 and 0.5) and the
radial features extended to r = 14.  Everything else as in experiments_wordnet.py.  Exploratory:
the paper uses the embedding at half radius for the reason given in its Appendix E.

usage:  python3 experiments_wordnet_full.py prior
        python3 experiments_wordnet_full.py <model> <trainseed_index>
        python3 experiments_wordnet_full.py assemble
"""
import json, sys, os, glob
import numpy as np
import experiments as ex
import experiments_tree as T
import experiments_wordnet as W
from experiments_cr import mmd2_laplace

RHO, DMAX, VCAP, RCLIP = 1.0, 200.0, 1.5, 14.0

# --- full radius positions, written into the experiments_wordnet namespace (read at call time)
W.RR = RHO * W.R0
W.POS = ex.expmap(np.broadcast_to(ex.O_PT, (len(W.RR), 3)).copy(), np.stack([W.RR * np.cos(W.TH), W.RR * np.sin(W.TH), np.zeros_like(W.RR)], -1))
W.RMAX = float(W.RR.max()); W.DIV_R = W.RMAX + 2.0

def rad_feats_full(r):
    rr = np.minimum(r, RCLIP)[..., None]
    w = np.pi * np.arange(1, 5) / (RCLIP / 2.0)
    return np.concatenate([rr, np.sin(rr * w), np.cos(rr * w)], -1)
T.rad_feats = rad_feats_full                     # used by W.feats and W.tangent_feats through T

def run(model, idx):
    tag = f"wn_full_{model}_s{idx}"
    if os.path.exists(tag + ".json"): print("exists"); return
    Xtr, Xte, centres, Wn, bw = W.setup()
    tseed = W.BASE[model] + 1000 * idx; sseeds = [tseed + o for o in (100, 200, 300)]
    out = {"model": model, "train_seed": tseed, "samp_seeds": sseeds, "bandwidth": bw, "rho": RHO, "dmax": DMAX, "vcap": VCAP, "rclip": RCLIP}
    if model == "tangent":
        net = T.train_tangent(Xtr, T=ex.T2, seed=tseed)
        sampler = lambda n, s: T.sample_tangent(net, n, np.random.default_rng(s), T=ex.T2, K=ex.K2)
    else:
        c = float(model[1:])
        paths = ex.simulate_paths(Xtr, c, ex.H2, ex.K2, np.random.default_rng(tseed))
        net = T.train_intrinsic(paths, c, ex.H2, ex.T2, seed=tseed); del paths
        sampler = lambda n, s: T.sample_intrinsic(net, c, ex.H2, ex.K2, ex.T2, n, np.random.default_rng(s), dmax=DMAX, vcap=VCAP)
    sets = [sampler(4096, s) for s in sseeds]
    out["rows"] = [W.evaluate(S, Xte, centres, Wn, bw) for S in sets]
    np.savez_compressed(tag + "_samples.npz", *sets)
    json.dump(out, open(tag + ".json", "w"), indent=1)
    a = np.array([[r["mmd2"], r["node_tv"], r["group_tv"], r["frac_div"]] for r in out["rows"]])
    print(f"[wn full {model} seed{idx}] MMD2 {a[:,0].mean():.5f}+-{a[:,0].std():.5f}  nodeTV {a[:,1].mean():.3f}  groupTV {a[:,2].mean():.3f}  div {a[:,3].mean():.4f}", flush=True)

def prior():
    Xtr, Xte, centres, Wn, bw = W.setup()
    D = ex.dist(centres[:, None, :], centres[None, :, :]); np.fill_diagonal(D, np.inf)
    out = {"bandwidth": bw, "rho": RHO, "rmax": W.RMAX, "radius_quantiles": np.quantile(W.RR, [0, 0.1, 0.5, 0.9, 1]).tolist(),
           "nearest_quantiles": np.quantile(D.min(1), [0, 0.05, 0.25, 0.5]).tolist()}
    out["floor"] = W.evaluate(Xte, Xtr[:4096], centres, Wn, bw)
    for c in [0.25, 0.5, 1.0, 2.0, 4.0]:
        endp = ex.simulate_paths(Xtr[:8192], c, ex.H2, ex.K2, np.random.default_rng(W.BASE[f"c{c}"]))[-1]
        P = ex.sample_prior(c, 4096, np.random.default_rng(7))
        out[f"prior_mismatch_c{c}"] = float(mmd2_laplace(endp[:4096], P, bw)); out[f"forward_Er_c{c}"] = float(ex.r_of(endp).mean())
        print(f"[wn full prior] c={c}: mismatch {out[f'prior_mismatch_c{c}']:.5f}  E r {out[f'forward_Er_c{c}']:.3f}", flush=True)
    json.dump(out, open("wn_full_prior.json", "w"), indent=1)
    print("floor", out["floor"], "radius q", np.round(out["radius_quantiles"], 2), "nearest q", np.round(out["nearest_quantiles"], 3), "bw", round(bw, 3))

def assemble():
    res = {"prior": json.load(open("wn_full_prior.json"))}
    for f in sorted(glob.glob("wn_full_c*_s[0-9].json") + glob.glob("wn_full_tangent_s[0-9].json")):
        d = json.load(open(f)); res.setdefault(d["model"], {})[str(d["train_seed"])] = d
    summary = {}
    for model, runs in res.items():
        if model == "prior": continue
        A = np.array([[r["mmd2"], r["node_tv"], r["group_tv"], r["frac_div"]] for d in runs.values() for r in d["rows"]])
        summary[model] = {"n_train": len(runs), "mean": A.mean(0).tolist(), "std_all": A.std(0, ddof=1).tolist()}
        print(f"[wn full {model}] runs={len(runs)} MMD2 {A[:,0].mean():.5f}+-{A[:,0].std(ddof=1):.5f} nodeTV {A[:,1].mean():.3f} groupTV {A[:,2].mean():.3f} div {A[:,3].mean():.4f}")
    res["summary"] = summary; json.dump(res, open("wn_full_all.json", "w"), indent=1)

if __name__ == "__main__":
    ex.self_test()
    stage = sys.argv[1]
    if stage == "prior": prior()
    elif stage == "assemble": assemble()
    else: run(stage, int(sys.argv[2]))
