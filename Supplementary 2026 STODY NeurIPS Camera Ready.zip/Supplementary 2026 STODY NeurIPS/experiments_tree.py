"""Hierarchy C: a tree with 64 leaves at depth three, embedded in H^2 by a recursive
placement (each node's children at geodesic distance tau, spread evenly within a cone
about the direction away from the parent, after Sarkar 2011), with Dirichlet
leaf weights and the usual leaf noise.  32,768 training points.  Networks are 256
wide with angular Fourier features up to k = 64 and radial Fourier features; the
training, sampling and evaluation code is otherwise that of experiments.py.

usage:  python3 experiments_tree.py prior
        python3 experiments_tree.py <model> <trainseed_index>   model in {c0.25, c0.5, c1.0, c2.0, c4.0, tangent}
        python3 experiments_tree.py assemble
"""
import json, sys, os, glob
import numpy as np
import experiments as ex
from experiments_cr import mmd2_laplace

TAU, BRANCH, DEPTH, NOISE, CONE = 1.3, (4, 4, 4), 3, 0.15, np.pi / 3
NTRAIN, NTEST = 32768, 4096
WIDTH, ITERS, KDOUBLE = 256, 40000, 7            # k = 1,2,...,64

# ----------------------------------------------------------------------------- tree
def build_tree(seed=0):
    """Returns leaf positions on the hyperboloid and the tree edges (for the figure)."""
    nodes = [np.array([0.0, 0.0, 1.0])]; parent = [-1]; depth = [0]
    frontier = [0]
    for d in range(DEPTH):
        new = []
        for p in frontier:
            x = nodes[p]; k = BRANCH[d]
            if parent[p] < 0:
                u_in = np.array([1.0, 0.0, 0.0]); full = True
            else:
                v = ex.logmap(x[None], nodes[parent[p]][None])[0]
                u_in = v / np.sqrt(max(ex.mink(v, v), 1e-12)); full = False
            # second frame vector in T_x H^2: rotate u_in by 90 degrees (spatial rotation keeps tangency)
            er, _ = ex.grad_r(x[None]); er = er[0]
            if ex.r_of(x[None])[0] < 1e-9:
                u_perp = np.array([0.0, 1.0, 0.0])
            else:
                _, ephi, _, _ = ex.frame(x[None]); ephi = ephi[0]
                a, b = ex.mink(u_in, er), ex.mink(u_in, ephi)
                u_perp = -b * er + a * ephi
            if full:
                angs = [2 * np.pi * i / k for i in range(k)]
            else:   # children in a cone of half angle CONE about the outward direction
                angs = [np.pi + (2 * i - k + 1) / k * CONE for i in range(k)]
            for th in angs:
                v = TAU * (np.cos(th) * u_in + np.sin(th) * u_perp)
                nodes.append(ex.expmap(x[None], v[None])[0]); parent.append(p); depth.append(d + 1)
                new.append(len(nodes) - 1)
        frontier = new
    nodes = np.array(nodes); depth = np.array(depth)
    leaves = np.where(depth == DEPTH)[0]
    return nodes, parent, depth, leaves

NODES, PARENT, DEPTHS, LEAVES = build_tree()
LEAF_W = np.random.default_rng(5).dirichlet(2.0 * np.ones(len(LEAVES)))

def make_tree_data(n, rng_):
    leaf = rng_.choice(len(LEAVES), size=n, p=LEAF_W)
    x = NODES[LEAVES[leaf]]
    return ex.expmap(x, NOISE * ex.tangent_gauss(x, rng_)), leaf

def setup():
    rgd = np.random.default_rng(46)
    Xtr, _ = make_tree_data(NTRAIN, rgd); Xte, _ = make_tree_data(NTEST, rgd)
    sub = Xte[:512]; dd = ex.dist(sub[:, None, :], sub[None, :, :])
    return Xtr, Xte, NODES[LEAVES], LEAF_W, float(np.median(dd[dd > 0]))

def evaluate(S, Xte, centres, W, bw):
    fin = np.isfinite(S).all(-1)
    div = float(((ex.r_of(np.where(fin[:, None], S, 0.0)) > 7.0) | ~fin).mean())
    if not fin.all():
        return {"mmd2": float("nan"), "leaf_tv": float("nan"), "frac_div": div}
    frac = np.bincount(ex.dist(S[:, None, :], centres[None, :, :]).argmin(1), minlength=len(W)) / len(S)
    return {"mmd2": float(mmd2_laplace(S, Xte, bw)), "leaf_tv": 0.5 * float(np.abs(frac - W).sum()), "frac_div": div}

# ----------------------------------------------------------------------------- features
def ang_feats(cs, kd=KDOUBLE):
    c1, s1 = cs[..., 0], cs[..., 1]; out = [c1, s1]; c, s = c1, s1
    for _ in range(kd - 1):
        c, s = c * c - s * s, 2 * c * s; out += [c, s]
    return np.stack(out, -1)

def rad_feats(r):
    rr = np.minimum(r, 12.0)[..., None]
    w = np.pi * np.arange(1, 5) / 6.0
    return np.concatenate([rr, np.sin(rr * w), np.cos(rr * w)], -1)

def feats(x, t, T):
    er, ephi, r, cs = ex.frame(x)
    return np.concatenate([rad_feats(r), ang_feats(cs), ex.timefeat(t, T)], -1), er, ephi, r

def tangent_feats(y, t, T):
    ny = np.linalg.norm(y, axis=-1, keepdims=True)
    cs = y / np.maximum(ny, 1e-12)
    return np.concatenate([y, rad_feats(ny[..., 0]), ang_feats(cs), ex.timefeat(t, T)], -1)

DIN_I = 9 + 2 * KDOUBLE + 9
DIN_T = 2 + 9 + 2 * KDOUBLE + 9

# ----------------------------------------------------------------------------- training (as experiments.py, wider)
def train_intrinsic(paths, c, h, T, iters=ITERS, bs=512, lr=1e-3, seed=11):
    rg = np.random.default_rng(seed); K = paths.shape[0] - 1
    net = ex.MLP(DIN_I, WIDTH, 2, rg); losses = []
    for it in range(iters):
        i = rg.integers(0, paths.shape[1], bs); m = ex.SPANS[rg.integers(0, len(ex.SPANS), bs)]
        k = rg.integers(0, K + 1 - m, bs); xp, xc = paths[k, i], paths[k + m, i]; tau = (m * h)[:, None]
        z = xp.copy(); remaining = m.copy()
        for _ in range(int(ex.SPANS.max())):
            act = remaining > 0
            if not act.any(): break
            g, r = ex.grad_r(z[act]); z[act] = ex.normalize(ex.expmap(z[act], -(c * r)[..., None] * g * h)); remaining -= 1
        tgt = ex.logmap(xc, z) / np.sqrt(2 * tau)
        F, er, ephi, rc = feats(xc, (k + m) * h, T)
        ab = net.forward(F)
        spred = -(c * rc)[..., None] * er + ab[..., :1] * er + ab[..., 1:] * ephi
        e = np.sqrt(2 * tau) * spred - tgt
        losses.append(float(np.mean(ex.mink(e, e))))
        w = 2 * np.sqrt(2 * tau)[..., 0] / bs
        net.adam(net.backward(np.stack([w * ex.mink(e, er), w * ex.mink(e, ephi)], -1)),
                 lr=lr * (0.3 if it >= int(0.67 * iters) else 1.0))
        if (it + 1) % 5000 == 0: print(f"[tree c={c}] iter {it+1}: loss {np.mean(losses[-500:]):.4f}", flush=True)
    return net

def sample_intrinsic(net, c, h, K, T, n, rng_, dmax=50.0, vcap=0.5):
    x = ex.sample_prior(c, n, rng_)
    for k in range(K, 0, -1):
        F, er, ephi, r = feats(x, np.full(n, k * h), T)
        ab = net.forward(F)
        s = -(c * r)[..., None] * er + ab[..., :1] * er + ab[..., 1:] * ephi
        drift = (c * r)[..., None] * er + 2.0 * s
        nd = np.sqrt(np.maximum(ex.mink(drift, drift), 0.0)); drift *= np.minimum(1.0, dmax / np.maximum(nd, 1e-12))[..., None]
        v = drift * h + np.sqrt(2 * h) * ex.tangent_gauss(x, rng_)
        nv = np.sqrt(np.maximum(ex.mink(v, v), 0.0)); v *= np.minimum(1.0, vcap / np.maximum(nv, 1e-12))[..., None]
        x = ex.rwall(ex.normalize(ex.expmap(x, v)))
    return x

def train_tangent(X, iters=ITERS, bs=512, lr=1e-3, seed=12, T=4.0):
    rg = np.random.default_rng(seed)
    Y = ex.logmap(np.broadcast_to(ex.O_PT, X.shape).copy(), X)[:, :2]
    net = ex.MLP(DIN_T, WIDTH, 2, rg)
    for it in range(iters):
        i = rg.integers(0, Y.shape[0], bs); t = rg.uniform(0.01, T, bs)
        al = np.exp(-t)[:, None]; sg = np.sqrt(1 - np.exp(-2 * t))[:, None]; ep = rg.standard_normal((bs, 2))
        e = net.forward(tangent_feats(al * Y[i] + sg * ep, t, T)) - ep
        net.adam(net.backward(2 * e / e.size), lr=lr * (0.3 if it >= int(0.67 * iters) else 1.0))
        if (it + 1) % 5000 == 0: print(f"[tree tangent] iter {it+1}: loss {float(np.mean(e**2)):.4f}", flush=True)
    return net

def sample_tangent(net, n, rng_, T=4.0, K=400):
    h = T / K; y = rng_.standard_normal((n, 2))
    for k in range(K, 0, -1):
        t = np.full(n, k * h); sg = np.sqrt(1 - np.exp(-2 * t))[:, None]
        y = y + (y + 2 * (-net.forward(tangent_feats(y, t, T)) / sg)) * h + np.sqrt(2 * h) * rng_.standard_normal((n, 2))
    ny = np.linalg.norm(y, axis=-1, keepdims=True); y = y * np.minimum(1.0, ex.RWALL / np.maximum(ny, 1e-12))
    return ex.expmap(np.broadcast_to(ex.O_PT, (n, 3)).copy(), np.concatenate([y, np.zeros((n, 1))], -1))

BASE = {"c0.25": 82, "c0.5": 83, "c1.0": 84, "c2.0": 81, "c4.0": 85, "tangent": 92}

def run(model, idx):
    if os.path.exists(f"tree_{model}_s{idx}.json"): print("exists"); return
    Xtr, Xte, centres, W, bw = setup()
    tseed = BASE[model] + 1000 * idx; sseeds = [tseed + o for o in (100, 200, 300)]
    out = {"model": model, "train_seed": tseed, "samp_seeds": sseeds, "bandwidth": bw}
    if model == "tangent":
        net = train_tangent(Xtr, T=ex.T2, seed=tseed)
        sampler = lambda n, s: sample_tangent(net, n, np.random.default_rng(s), T=ex.T2, K=ex.K2)
    else:
        c = float(model[1:])
        paths = ex.simulate_paths(Xtr, c, ex.H2, ex.K2, np.random.default_rng(tseed))
        net = train_intrinsic(paths, c, ex.H2, ex.T2, seed=tseed); del paths
        sampler = lambda n, s: sample_intrinsic(net, c, ex.H2, ex.K2, ex.T2, n, np.random.default_rng(s))
    sets = [sampler(4096, s) for s in sseeds]
    out["rows"] = [evaluate(S, Xte, centres, W, bw) for S in sets]
    np.savez_compressed(f"tree_{model}_s{idx}_samples.npz", *sets)
    if idx == 0: json.dump(ex.to_disk(sets[0][:2000]).tolist(), open(f"tree_samples_{model}.json", "w"))
    json.dump(out, open(f"tree_{model}_s{idx}.json", "w"), indent=1)
    a = np.array([[r["mmd2"], r["leaf_tv"], r["frac_div"]] for r in out["rows"]])
    print(f"[tree {model} seed{idx}] MMD2 {a[:,0].mean():.5f}+-{a[:,0].std():.5f}  TV {a[:,1].mean():.3f}  div {a[:,2].mean():.4f}", flush=True)

def prior():
    Xtr, Xte, centres, W, bw = setup()
    out = {"bandwidth": bw, "n_leaves": int(len(LEAVES)), "leaf_radii": ex.r_of(centres).tolist(),
           "leaf_weights": LEAF_W.tolist(), "nodes_disk": ex.to_disk(NODES).tolist(), "parent": PARENT}
    json.dump(ex.to_disk(Xte[:2000]).tolist(), open("tree_samples_data.json", "w"))
    out["floor"] = evaluate(Xte, Xtr[:4096], centres, W, bw)       # the test set's own values: the sampling floor
    for c in [0.25, 0.5, 1.0, 2.0, 4.0]:
        endp = ex.simulate_paths(Xtr[:8192], c, ex.H2, ex.K2, np.random.default_rng(BASE[f"c{c}"]))[-1]
        P = ex.sample_prior(c, 4096, np.random.default_rng(7))
        out[f"prior_mismatch_c{c}"] = float(mmd2_laplace(endp[:4096], P, bw)); out[f"forward_Er_c{c}"] = float(ex.r_of(endp).mean())
        print(f"[tree prior] c={c}: mismatch {out[f'prior_mismatch_c{c}']:.5f}  E r {out[f'forward_Er_c{c}']:.3f}", flush=True)
    json.dump(out, open("tree_prior.json", "w"), indent=1)

def assemble():
    res = {"prior": json.load(open("tree_prior.json"))}
    for f in sorted(glob.glob("tree_c*_s[0-9].json") + glob.glob("tree_tangent_s[0-9].json")):
        d = json.load(open(f)); res.setdefault(d["model"], {})[str(d["train_seed"])] = d
    summary = {}
    for model, runs in res.items():
        if model == "prior": continue
        A = np.array([[r["mmd2"], r["leaf_tv"], r["frac_div"]] for d in runs.values() for r in d["rows"]])
        P = np.array([np.mean([[r["mmd2"], r["leaf_tv"], r["frac_div"]] for r in d["rows"]], 0) for d in runs.values()])
        summary[model] = {"n_train": len(runs), "mean": A.mean(0).tolist(), "std_all": A.std(0, ddof=1).tolist(),
                          "std_train": P.std(0, ddof=1).tolist() if len(P) > 1 else [0, 0, 0], "per_train_mean": P.tolist()}
        print(f"[tree {model}] runs={len(runs)} MMD2 {A[:,0].mean():.5f}+-{A[:,0].std(ddof=1):.5f} TV {A[:,1].mean():.3f}+-{A[:,1].std(ddof=1):.3f} div {A[:,2].mean():.4f}")
    res["summary"] = summary; json.dump(res, open("tree_all.json", "w"), indent=1)

if __name__ == "__main__":
    ex.self_test()
    stage = sys.argv[1]
    if stage == "prior": prior()
    elif stage == "assemble": assemble()
    else: run(stage, int(sys.argv[2]))
