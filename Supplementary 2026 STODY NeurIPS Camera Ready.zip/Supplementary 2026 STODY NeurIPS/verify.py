"""Independent verification of the analytic claims in the paper.

Not a formal proof check. This (a) verifies the closed-form computations
symbolically or to high precision, and (b) solves the weighted eigenvalue
problem numerically to test whether the theorem STATEMENTS hold, which is
the check that would catch a wrong constant or exponent.
"""
import numpy as np, sympy as sp, mpmath as mp
from scipy import sparse
from scipy.sparse.linalg import eigsh

mp.mp.dps = 40
ok = lambda b: "PASS" if b else "**FAIL**"
print("=" * 74)

# --- V1  Lemma B.1: |P_x w|_g^2 = <w,w>_L + <x,w>_L^2, sinh r <= sup <= sqrt2 cosh r
print("V1  Lemma B.1 (frame amplification)")
rg = np.random.default_rng(0)
# The identity |P_x w|_g^2 = <w,w>_L + <x,w>_L^2 is exact; we verify it symbolically.
# A float64 check inflates at large r through the same e^{4r} cancellation in the
# extrinsic coordinates that Section 4.3 documents -- the coordinates, not the identity.
d = 3
xs = sp.symbols(f'x0:{d}'); ws = sp.symbols(f'w0:{d}')
def mink_s(a, b): return sum(a[i]*b[i] for i in range(d-1)) - a[-1]*b[-1]
xw_s = mink_s(xs, ws)
Ps = [ws[i] + xw_s*xs[i] for i in range(d)]
resid = sp.expand(mink_s(Ps, Ps) - (mink_s(ws, ws) + xw_s**2))
off_shell = sp.simplify(resid - xw_s**2*(mink_s(xs, xs) + 1))   # 0: resid == <x,w>_L^2 (<x,x>_L + 1)
print(f"    identity exact: residual = <x,w>_L^2 (<x,x>_L+1) -> 0 on <x,x>_L=-1   {ok(off_shell == 0)}")
# bounds sinh r <= sup_{|w|=1} |P_x w|_g <= sqrt(2) cosh r via a well-conditioned eigensolve
sup_lo = sup_hi = 0.0
G = np.eye(3); G[2, 2] = -1
for r in [0.5, 1.0, 2.0, 3.0, 5.0, 8.0]:
    th = rg.uniform(0, 2 * np.pi, 200)
    x = np.stack([np.sinh(r) * np.cos(th), np.sinh(r) * np.sin(th), np.cosh(r) * np.ones_like(th)], -1)
    s = np.array([np.sqrt(max(np.linalg.eigvalsh(G + np.outer(G @ xi, G @ xi)))) for xi in x])
    sup_lo = max(sup_lo, float(np.max(np.sinh(r) - s)))          # want <= 0
    sup_hi = max(sup_hi, float(np.max(s - np.sqrt(2) * np.cosh(r))))  # want <= 0
print(f"    lower bound sinh r <= sup  (max violation {sup_lo:+.2e})   {ok(sup_lo <= 1e-12)}")
print(f"    upper bound sup <= sqrt2 cosh r (max viol {sup_hi:+.2e})   {ok(sup_hi <= 1e-12)}")

# --- V2  v_n = n - 2(Gamma((n+1)/2)/Gamma(n/2))^2, in (0,1], and c*Var -> v_n
print("\nV2  variance constant v_n")
n_s = sp.symbols("n", positive=True)
vn = lambda n: float(n - 2 * (mp.gamma((n + 1) / 2) / mp.gamma(n / 2)) ** 2)
print(f"    v_2 = {vn(2):.6f}   (2 - pi/2 = {2 - np.pi/2:.6f})            {ok(abs(vn(2)-(2-np.pi/2))<1e-12)}")
vals = [vn(n) for n in range(2, 51)]
print(f"    v_n in (0,1] for n=2..50: min {min(vals):.4f} max {max(vals):.4f}  {ok(min(vals) > 0 and max(vals) <= 1)}")
# Monte-Carlo check that v_n = Var(|z|), z ~ N(0,I_n)
for n in [2, 5, 20]:
    z = np.random.default_rng(1).standard_normal((400000, n))
    mc = float(np.var(np.linalg.norm(z, axis=1)))
    print(f"    n={n:2d}: v_n {vn(n):.4f} vs MC Var|z| {mc:.4f}            {ok(abs(mc-vn(n))<0.01)}")

# --- V3  elementary inequalities behind the chi_n domination
print("\nV3  elementary inequalities")
k = sp.symbols("k", integer=True, nonnegative=True)
ratio = sp.simplify(sp.factorial(2*k+3)/sp.factorial(2*k+1) - 6*(k+1))   # >= 0 gives induction
print(f"    (2k+3)!/(2k+1)! - 6(k+1) = {sp.factor(ratio)}   >=0 for k>=0   {ok(all(float(ratio.subs(k,j))>=0 for j in range(200)))}")
worst = min(float(mp.factorial(2*j+1) / (6**j * mp.factorial(j))) for j in range(0, 60))
print(f"    (2k+1)! >= 6^k k! for k=0..59, min ratio {worst:.4f}       {ok(worst >= 1)}")
xs = np.linspace(1e-6, 30, 200000)
print(f"    sinh x <= x exp(x^2/6) on (0,30], max viol "
      f"{np.max(np.sinh(xs)-xs*np.exp(xs**2/6)):+.2e}   {ok(np.all(np.sinh(xs) <= xs*np.exp(xs**2/6)))}")

# --- V4  Z_c lower bound (eq:Zlower), valid in the regime c <= n-1
print("\nV4  partition-function bound  Z_c >= (1/2) gam^(n-1) sqrt(2pi/c) exp((n-1)^2/(2c)),  gam=(1-e^-2)/2")
gam = (1 - mp.e**-2) / 2
bad = []
for n in [2, 3, 4, 6, 10]:
    for c in [0.05, 0.1, 0.25, 0.5, 0.9 * (n - 1), n - 1.0]:
        if c > n - 1 + 1e-12: continue
        Z = mp.quad(lambda r: mp.e**(-c*r**2/2) * mp.sinh(r)**(n-1), [0, mp.inf])
        lb = mp.mpf(0.5) * gam**(n-1) * mp.sqrt(2*mp.pi/c) * mp.e**((n-1)**2/(2*c))
        bad.append((n, c, float(Z/lb)))
print(f"    ratio Z_c/bound over {len(bad)} (n,c) pairs: min {min(b[2] for b in bad):.3f}   {ok(min(b[2] for b in bad) >= 1)}")
print(f"    sinh r >= gam e^r for r>=1: gam={float(gam):.6f}, check at r=1 "
      f"{float(mp.sinh(1)/mp.e):.6f}                {ok(float(mp.sinh(1)/mp.e) >= float(gam) - 1e-15)}")

# --- V5  beta(n) = min{(n-1)^2/2, 2(n-2)}, branch switch, exponent difference
print("\nV5  collapse exponent beta(n)")
diff = sp.simplify((n_s-1)**2 - (n_s-3)**2)
print(f"    (n-1)^2-(n-3)^2 = {sp.expand(diff)}                            {ok(sp.expand(diff)==4*n_s-8)}")
for n in [3, 4, 5, 8]:
    a, b = (n-1)**2/2, 2*(n-2)
    lab = 'tie' if a == b else ('radial' if a < b else 'angular')
    print(f"    n={n}: (n-1)^2/2={a:5.2f}  2(n-2)={b:5.2f}  beta={min(a,b):5.2f}  min-branch={lab}")
# For n>=3, (n-1)^2/2 - 2(n-2) = (n-3)^2/2 >= 0, so the angular cost 2(n-2) is
# ALWAYS the minimum, coinciding with the radial cost only at n=3: there is no switch.
coincide_n3  = 2*(3-2) == (3-1)**2/2
angular_min  = all(2*(n-2) <= (n-1)**2/2 for n in range(3, 60))
strict_n4    = all(2*(n-2) <  (n-1)**2/2 for n in range(4, 60))
print(f"    beta(n)=2(n-2) is the min for all n>=3 (coincide n=3, strict n>=4)  "
      f"{ok(coincide_n3 and angular_min and strict_n4)}")

# --- V6  direct eigenvalue solve for lambda_1 on H^2 with mu_c
print("\nV6  numerical spectral gap of L_c on H^2  (linear FEM, separated angular modes)")
def spectrum(c, kmode, N=8000):
    """Lowest nonzero eigenvalue of the Rayleigh quotient
       int (eta'^2 + k^2 eta^2/sinh^2 r) w dr / int eta^2 w dr,  w = e^{-c r^2/2} sinh r.
       Linear FEM, 2-point Gauss per element; Dirichlet at r=0 for k>=1."""
    R = max(9.0, 1.0 / c + 9.0 / np.sqrt(c))
    r = np.linspace(0.0, R, N + 1)[1:]                     # unknowns at r_1..r_N
    lw = lambda z: -c * z ** 2 / 2 + np.log(np.sinh(np.clip(z, 1e-300, None)))
    shift = np.max(lw(r))
    W = lambda z: np.exp(lw(np.clip(z, 1e-14, None)) - shift)
    if kmode == 0:                                          # natural BC at the left end
        a_, b_ = r[:-1], r[1:]
        iA, iB = np.arange(N - 1), np.arange(1, N)
    else:                                                   # extra element [0, r_1], eta(0)=0
        a_ = np.concatenate([[0.0], r[:-1]]); b_ = r.copy()
        iA, iB = np.arange(-1, N - 1), np.arange(0, N)
    L = b_ - a_
    dA, dB = np.zeros(N), np.zeros(N)
    oA, oB = np.zeros(N - 1), np.zeros(N - 1)
    for t in (0.5 - np.sqrt(3) / 6, 0.5 + np.sqrt(3) / 6):
        q = a_ + t * L
        wgt = 0.5 * L * W(q)
        V = kmode ** 2 / np.sinh(np.clip(q, 1e-14, None)) ** 2
        pA, pB = (b_ - q) / L, (q - a_) / L
        s = wgt / L ** 2
        aAA, aBB, aAB = s + wgt * V * pA * pA, s + wgt * V * pB * pB, -s + wgt * V * pA * pB
        mAA, mBB, mAB = wgt * pA * pA, wgt * pB * pB, wgt * pA * pB
        m = iA >= 0
        np.add.at(dA, iA[m], aAA[m]); np.add.at(dB, iA[m], mAA[m])
        np.add.at(dA, iB, aBB);       np.add.at(dB, iB, mBB)
        np.add.at(oA, iA[m], aAB[m]); np.add.at(oB, iA[m], mAB[m])
    A = sparse.diags([oA, dA, oA], [-1, 0, 1], format="csc")
    B = sparse.diags([oB, dB, oB], [-1, 0, 1], format="csc")
    nev = 2 if kmode == 0 else 1
    vals = eigsh(A, k=nev, M=B, sigma=-1e-7, which="LM", return_eigenvectors=False)
    return float(np.sort(vals)[-1])

def stats(c):
    R = max(9.0, 1.0/c + 9.0/np.sqrt(c))
    r = np.linspace(1e-9, R, 400001)
    lw = -c*r**2/2 + np.log(np.sinh(r)); w = np.exp(lw - lw.max())
    Z = np.trapezoid(w, r)
    m1 = np.trapezoid(r*w, r)/Z; m2 = np.trapezoid(r**2*w, r)/Z
    return m1, m2 - m1**2

meas = {0.25: 0.0369, 0.5: 0.1739, 1.0: 0.5435, 2.0: 1.4636, 4.0: 3.3676}
v2 = vn(2)
print("      c   lam1(k=1)  lam1(k=0)   BE c-1   1/Var(r)   2c/v_2   sqrt(c)e^-1/2c   sim rate")
rows = {}
for c in [0.1, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0]:
    l1, l0 = spectrum(c, 1), spectrum(c, 0)
    _, var = stats(c)
    env = np.sqrt(c)*np.exp(-1/(2*c))
    rows[c] = (l1, l0, var, env)
    print(f"    {c:5.2f}  {l1:9.5f}  {l0:9.4f}  {c-1:7.3f}  {1/var:9.4f}  {2*c/v2:8.3f}  "
          f"{env:12.5f}   {meas.get(c, float('nan')):8.4f}")

print("\n    claim checks:")
be = all(rows[c][0] >= c - 1 - 1e-3 and rows[c][1] >= c - 1 - 1e-3 for c in rows if c > 1)
print(f"    Thm 3.1  lam1 >= c-(n-1) for c>1                        {ok(be)}")
up1 = all(min(rows[c][0], rows[c][1]) <= 1/rows[c][2] + 1e-6 for c in rows)
print(f"    Thm 3.2  lam1 <= 1/Var_mu(r)                            {ok(up1)}")
up2 = all(min(rows[c][0], rows[c][1]) <= 2*c/v2 for c in rows if c >= 1)
print(f"    Thm 3.2  lam1 <= 2c/v_n for c>=1                        {ok(up2)}")
cv = [c*rows[c][2] for c in rows]
print(f"    c*Var(r) -> v_2={v2:.4f}: at c=8 it is {8*rows[8.0][2]:.4f}      "
      f"{ok(abs(8*rows[8.0][2]-v2) < 0.1)}")
sub = [c for c in rows if c < 1]
C = {c: rows[c][0]/rows[c][3] for c in sub}
print(f"    Thm 3.6  lam1 <= C sqrt(c) e^(-1/2c), C = " +
      ", ".join(f"c={c}: {C[c]:.3f}" for c in sorted(sub)) + f"   {ok(max(C.values()) < 1)}")
print(f"    gap is angular (k=1 below k=0) below threshold          "
      f"{ok(all(rows[c][0] < rows[c][1] for c in sub))}")
print(f"    simulation rates vs lam1(k=1): " +
      ", ".join(f"c={c}: {meas[c]/rows[c][0]:.2f}x" for c in sorted(meas) if c in rows))
print("=" * 74)
