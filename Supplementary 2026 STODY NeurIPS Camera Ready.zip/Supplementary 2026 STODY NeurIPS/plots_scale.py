"""Figures for hierarchies C and W: the chart log_o (geodesic polar coordinates, which do not
compress the radius as the Poincare disk does) and a zoomed sector in (angle, radius).

Each panel shows 12,288 points: for the models, the three sample sets of the first training
seed (wn_*_s0_samples.npz, tree_*_s0_samples.npz); for the data, a fresh draw from the same
generator as the test set.  Runs after the sweeps: python3 plots_scale.py
"""
import os, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
import experiments as ex

matplotlib.rcParams.update({"pdf.fonttype": 42, "ps.fonttype": 42, "font.family": "serif", "mathtext.fontset": "cm", "font.size": 7, "axes.titlesize": 7.3, "axes.labelsize": 7, "xtick.labelsize": 6, "ytick.labelsize": 6})
BLUE = "#1f4e79"

def polar(P):
    y = ex.logmap(np.broadcast_to(ex.O_PT, P.shape).copy(), P)[:, :2]
    return np.arctan2(y[:, 1], y[:, 0]), np.linalg.norm(y, axis=1)

def figure(pre, data, window, rlim, rmax, out, titles):
    models = ["c1.0", "c0.25", "tangent"]
    files = [f"{pre}_{m}_s0_samples.npz" for m in models]
    if not all(os.path.exists(f) for f in files): print("missing", files); return
    sets = [data] + [np.concatenate([np.load(f)[k] for k in np.load(f).files]) for f in files]
    fig, axs = plt.subplots(2, 4, figsize=(5.5, 2.9), gridspec_kw={"height_ratios": [1.15, 1]})
    t0, t1 = window
    for j, (P, ttl) in enumerate(zip(sets, titles)):
        th, r = polar(P)
        a = axs[0, j]
        a.scatter(r * np.cos(th), r * np.sin(th), s=0.25, c=BLUE, alpha=0.35, linewidths=0)
        a.plot(rmax * np.cos(np.linspace(0, 2 * np.pi, 200)), rmax * np.sin(np.linspace(0, 2 * np.pi, 200)), "-", color="0.8", lw=0.6)
        for t in (t0, t1):
            a.plot([rlim[0] * np.cos(t), rlim[1] * np.cos(t)], [rlim[0] * np.sin(t), rlim[1] * np.sin(t)], "-", color="#CC3034", lw=0.6)
        a.set_xlim(-rmax * 1.03, rmax * 1.03); a.set_ylim(-rmax * 1.03, rmax * 1.03); a.set_aspect("equal"); a.axis("off"); a.set_title(ttl)
        b = axs[1, j]; m = (th > t0) & (th < t1)
        b.scatter(th[m], r[m], s=1.2, c=BLUE, alpha=0.6, linewidths=0)
        b.set_xlim(t0, t1); b.set_ylim(*rlim); b.set_xlabel(r"angle $\varphi$")
        if j == 0: b.set_ylabel("radius $r$")
        else: b.set_yticklabels([])
        b.tick_params(length=2, pad=1.5)
    fig.tight_layout(pad=0.3, h_pad=0.6, w_pad=0.4); fig.savefig(out, bbox_inches="tight"); print(out)

if __name__ == "__main__":
    import experiments_tree as T
    X, _ = T.make_tree_data(12288, np.random.default_rng(999))
    th_root = np.arctan2(T.NODES[1:5, 1], T.NODES[1:5, 0])          # the four depth one nodes
    t0 = float(th_root[np.argmin(np.abs(th_root))])                  # the branch nearest angle 0
    figure("tree", X, (t0 - 0.55, t0 + 0.55), (2.8, 4.3), 4.4, "fig_samples_C.pdf",
           ["data", "intrinsic, $c=1=n-1$", "intrinsic, $c=0.25<n-1$", "tangent (wrapped)"])
    import experiments_wordnet as W
    X, _ = W.make_data(12288, np.random.default_rng(999))
    idx = np.where(W.NODE_GROUP == W.GROUPS.index("primate.n.02"))[0]; thp = W.TH[idx]
    figure("wn", X, (float(thp.min()) - 0.02, float(thp.max()) + 0.02), (3.3, 6.3), 6.3, "fig_samples_W.pdf",
           ["data", "intrinsic, $c=1=n-1$", "intrinsic, $c=0.25<n-1$", "tangent (wrapped)"])
