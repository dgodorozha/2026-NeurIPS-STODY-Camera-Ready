"""Generative experiments on H^2 (hierarchies A and B, Section 5.2): repeated training
seeds and the confinement sweep.  Reuses the model, training and sampling code of
experiments.py unchanged, so the original training seed reproduces the models of
experiments.py exactly; only the data generator and the seed loops are added.

usage:  python3 experiments_cr.py <hier> <model> <trainseed_index>
        hier in {A, B}; model in {c0.25, c0.5, c1.0, c2.0, c4.0, tangent}; index in {0,1,2}
        python3 experiments_cr.py <hier> prior         (forward diagnostics, no network)
        python3 experiments_cr.py <hier> assemble
"""
import json, sys, os, glob
import numpy as np
import experiments as ex

# ----------------------------------------------------------------------------- data
def hier_A():
    """Hierarchy A, the hierarchy of experiments.py."""
    rgd = np.random.default_rng(42)
    Xtr, _ = ex.make_tree_data(8192, rgd)
    Xte, _ = ex.make_tree_data(4096, rgd)
    return Xtr, Xte, ex.leaf_centres(), ex.LEAF_W

# hierarchy B: three groups with weights 0.6/0.3/0.1 at different radii; the heavy
# group has three levels (2 subgroups x 2 leaves), the middle group three leaves, the
# light group one leaf.  Eight leaves in total.
B_LEAVES = []     # (angle, radius, weight)
for sg in (-0.30, 0.30):
    for lf in (-0.10, 0.10):
        B_LEAVES.append((0.0 + sg + lf, 4.5, 0.15))
for lf in (-0.35, 0.0, 0.35):
    B_LEAVES.append((2 * np.pi / 3 + lf, 2.5, 0.10))
B_LEAVES.append((4 * np.pi / 3, 3.5, 0.10))
B_W = np.array([w for _, _, w in B_LEAVES])
assert abs(B_W.sum() - 1) < 1e-12

def make_tree_data_B(n, rng_):
    leaf = rng_.choice(len(B_LEAVES), size=n, p=B_W)
    th = np.array([a for a, _, _ in B_LEAVES])[leaf]
    rr = np.array([r for _, r, _ in B_LEAVES])[leaf]
    v = np.stack([rr * np.cos(th), rr * np.sin(th), np.zeros(n)], -1)
    x = ex.expmap(np.broadcast_to(ex.O_PT, (n, 3)).copy(), v)
    return ex.expmap(x, 0.15 * ex.tangent_gauss(x, rng_)), leaf

def leaf_centres_B():
    th = np.array([a for a, _, _ in B_LEAVES]); rr = np.array([r for _, r, _ in B_LEAVES])
    v = np.stack([rr * np.cos(th), rr * np.sin(th), np.zeros(len(B_LEAVES))], -1)
    return ex.expmap(np.broadcast_to(ex.O_PT, (len(B_LEAVES), 3)).copy(), v)

def hier_B():
    rgd = np.random.default_rng(43)
    Xtr, _ = make_tree_data_B(8192, rgd)
    Xte, _ = make_tree_data_B(4096, rgd)
    return Xtr, Xte, leaf_centres_B(), B_W

def setup(hier):
    Xtr, Xte, centres, W = {"A": hier_A, "B": hier_B}[hier]()
    sub = Xte[:512]
    dd = ex.dist(sub[:, None, :], sub[None, :, :])
    bw = float(np.median(dd[dd > 0]))          # median heuristic, Laplacian kernel bandwidth
    return Xtr, Xte, centres, W, bw

def mmd2_laplace(Xa, Xb, bw, chunk=1024):
    """MMD^2 by the U-statistic formula (diagonal terms removed) with the geodesic Laplacian
    kernel exp(-d/bw), which is positive definite on H^n (Feragen, Lauze and Hauberg 2015); the
    geodesic Gaussian kernel is not. The formula is unbiased for a fixed bw; the scripts choose bw
    from the test data (median heuristic), and the paper therefore does not call the estimate unbiased."""
    def Ksum(A, B):
        tot = 0.0
        for i in range(0, A.shape[0], chunk):
            tot += np.exp(-ex.dist(A[i:i + chunk, None, :], B[None, :, :]) / bw).sum()
        return tot
    na, nb = len(Xa), len(Xb)
    return (Ksum(Xa, Xa) - na) / (na * (na - 1)) + (Ksum(Xb, Xb) - nb) / (nb * (nb - 1)) - 2 * Ksum(Xa, Xb) / (na * nb)

def evaluate(S, Xte, centres, W, sig2):
    """Divergence counts r > 6 and non-finite coordinates; MMD^2 and leaf TV are
    reported as NaN when any sample is non-finite (the sampler failed)."""
    fin = np.isfinite(S).all(-1)
    div = float(((ex.r_of(np.where(fin[:, None], S, 0.0)) > 6.0) | ~fin).mean())
    if not fin.all():
        return {"mmd2": float("nan"), "leaf_tv": float("nan"), "frac_r_gt6": div, "leaf_frac": None}
    d = ex.dist(S[:, None, :], centres[None, :, :])
    frac = np.bincount(d.argmin(1), minlength=len(W)) / len(S)
    return {"mmd2": float(mmd2_laplace(S, Xte, sig2)),
            "leaf_tv": 0.5 * float(np.abs(frac - W).sum()),
            "frac_r_gt6": div,
            "leaf_frac": frac.tolist()}

# ----------------------------------------------------------------------------- seeds
BASE = {"c0.25": 22, "c0.5": 23, "c1.0": 24, "c2.0": 21, "c4.0": 25, "tangent": 12}
HIER_OFF = {"A": 0, "B": 50}
SAMP = [100, 200, 300]

def seeds(hier, model, idx):
    s = BASE[model] + HIER_OFF[hier] + 1000 * idx
    if model == "tangent" and hier == "A" and idx == 0:
        return s, [31, 131, 231]          # the sampling seeds of experiments.py
    return s, [s + o for o in SAMP]

# ----------------------------------------------------------------------------- stages
def run(hier, model, idx):
    if os.path.exists(f"cr_{hier}_{model}_s{idx}.json"):
        print(f"[{hier} {model} seed{idx}] exists, skipping"); return
    Xtr, Xte, centres, W, sig2 = setup(hier)
    tseed, sseeds = seeds(hier, model, idx)
    out = {"hier": hier, "model": model, "train_seed": tseed, "samp_seeds": sseeds, "bandwidth": sig2}
    if model == "tangent":
        net, _ = ex.train_tangent_baseline(Xtr, T=ex.T2, seed=tseed)
        sets = [ex.sample_tangent(net, 4096, np.random.default_rng(s), T=ex.T2, K=ex.K2) for s in sseeds]
        rows = [evaluate(S, Xte, centres, W, sig2) for S in sets]
        if idx == 0:
            S = ex.sample_tangent(net, 1500, np.random.default_rng(sseeds[0]), T=ex.T2, K=ex.K2)
            json.dump(ex.to_disk(S).tolist(), open(f"cr_samples_{hier}_tangent.json", "w"))
    else:
        c = float(model[1:])
        rg = np.random.default_rng(tseed)
        paths = ex.simulate_paths(Xtr, c, ex.H2, ex.K2, rg)
        out["forward_Er"] = float(ex.r_of(paths[-1]).mean())
        net = ex.train_intrinsic(paths, c, ex.H2, ex.T2, seed=tseed)
        sets = [ex.sample_intrinsic(net, c, ex.H2, ex.K2, ex.T2, 4096, np.random.default_rng(s)) for s in sseeds]
        rows = [evaluate(S, Xte, centres, W, sig2) for S in sets]
        if idx == 0:
            S = ex.sample_intrinsic(net, c, ex.H2, ex.K2, ex.T2, 1500, np.random.default_rng(sseeds[0]))
            json.dump(ex.to_disk(S).tolist(), open(f"cr_samples_{hier}_{model}.json", "w"))
    out["rows"] = rows
    np.savez_compressed(f"cr_{hier}_{model}_s{idx}_samples.npz", *sets)
    json.dump(out, open(f"cr_{hier}_{model}_s{idx}.json", "w"), indent=1)
    a = np.array([[r["mmd2"], r["leaf_tv"], r["frac_r_gt6"]] for r in rows])
    print(f"[{hier} {model} seed{idx}] MMD2 {a[:,0].mean():.5f}+-{a[:,0].std():.5f}  "
          f"TV {a[:,1].mean():.3f}+-{a[:,1].std():.3f}  div {a[:,2].mean():.4f}", flush=True)

def prior(hier):
    """Forward diagnostics without any network: prior mismatch at T and E r(T)."""
    Xtr, Xte, centres, W, sig2 = setup(hier)
    out = {"bandwidth": sig2}
    json.dump(ex.to_disk(Xte[:1500]).tolist(), open(f"cr_samples_{hier}_data.json", "w"))
    for c in [0.25, 0.5, 1.0, 2.0, 4.0]:
        rg = np.random.default_rng(BASE[f"c{c}"] + HIER_OFF[hier])
        endp = ex.simulate_paths(Xtr, c, ex.H2, ex.K2, rg)[-1]
        P = ex.sample_prior(c, 4096, np.random.default_rng(7))
        out[f"prior_mismatch_c{c}"] = float(mmd2_laplace(endp[:4096], P, sig2))
        np.savez_compressed(f"cr_{hier}_endpoint_c{c}.npz", endp[:4096])
        out[f"forward_Er_c{c}"] = float(ex.r_of(endp).mean())
        out[f"forward_R4_c{c}"] = ex.circ_R4(endp)
        print(f"[{hier} prior] c={c}: mismatch {out[f'prior_mismatch_c{c}']:.5f}  "
              f"E r {out[f'forward_Er_c{c}']:.3f}  R4 {out[f'forward_R4_c{c}']:.3f}", flush=True)
    out["R4_data"] = ex.circ_R4(Xtr)
    json.dump(out, open(f"cr_{hier}_prior.json", "w"), indent=1)

def assemble(hier):
    res = {"prior": json.load(open(f"cr_{hier}_prior.json"))}
    for f in sorted(glob.glob(f"cr_{hier}_*_s[0-9].json")):
        d = json.load(open(f))
        res.setdefault(d["model"], {})[str(d["train_seed"])] = d
    summary = {}
    for model, runs in res.items():
        if model == "prior": continue
        all_rows = [[r["mmd2"], r["leaf_tv"], r["frac_r_gt6"]] for d in runs.values() for r in d["rows"]]
        per_train = [np.mean([[r["mmd2"], r["leaf_tv"], r["frac_r_gt6"]] for r in d["rows"]], 0)
                     for d in runs.values()]
        A, P = np.array(all_rows), np.array(per_train)
        summary[model] = {"n_train": len(runs), "n_total": len(all_rows),
                          "mean": A.mean(0).tolist(), "std_all": A.std(0, ddof=1).tolist(),
                          "std_train": P.std(0, ddof=1).tolist() if len(P) > 1 else [0, 0, 0],
                          "per_train_mean": P.tolist()}
        print(f"[{hier} {model}] runs={len(runs)}  MMD2 {A[:,0].mean():.5f} (sd all {A[:,0].std(ddof=1):.5f}, "
              f"sd over training seeds {P[:,0].std(ddof=1) if len(P)>1 else 0:.5f})  "
              f"TV {A[:,1].mean():.3f}+-{A[:,1].std(ddof=1):.3f}  div {A[:,2].mean():.4f}")
    res["summary"] = summary
    json.dump(res, open(f"cr_{hier}_all.json", "w"), indent=1)

if __name__ == "__main__":
    hier, stage = sys.argv[1], sys.argv[2]
    ex.self_test(); ex.net_gradcheck()
    if stage == "prior": prior(hier)
    elif stage == "assemble": assemble(hier)
    else: run(hier, stage, int(sys.argv[3]))
