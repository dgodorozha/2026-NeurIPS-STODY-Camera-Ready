#!/bin/bash
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python3 experiments_h3.py prior
for m in c4.0 c1.0 tangent c2.0 c0.5 c8.0; do
  for s in 0 1 2; do python3 experiments_h3.py $m $s; done
done
python3 experiments_h3.py assemble
echo ALL_H3_DONE
