"""Hierarchy C with a finer discretisation: 1000 steps of h = 0.004 over the same horizon T = 4,
for the forward bank, the training targets and the sampler.  Everything else as in
experiments_tree.py.  Diagnostic for the question whether the discretisation limits the resolution
of the leaves within a branch.

usage:  python3 experiments_tree_fine.py <model> <trainseed_index>     (model: c<value> or tangent)
        python3 experiments_tree_fine.py assemble
"""
import json, sys, os, glob
import numpy as np
import experiments as ex
import experiments_tree as T

ex.H2 = 0.004; ex.K2 = int(round(ex.T2 / ex.H2))      # 1000 steps, read at call time by run()

def run(model, idx):
    tag = f"tree_fine_{model}_s{idx}"
    if os.path.exists(tag + ".json"): print("exists"); return
    Xtr, Xte, centres, W, bw = T.setup()
    tseed = T.BASE[model] + 1000 * idx; sseeds = [tseed + o for o in (100, 200, 300)]
    out = {"model": model, "train_seed": tseed, "samp_seeds": sseeds, "bandwidth": bw, "h": ex.H2, "K": ex.K2}
    if model == "tangent":
        net = T.train_tangent(Xtr, T=ex.T2, seed=tseed)
        sampler = lambda n, s: T.sample_tangent(net, n, np.random.default_rng(s), T=ex.T2, K=ex.K2)
    else:
        c = float(model[1:])
        paths = ex.simulate_paths(Xtr, c, ex.H2, ex.K2, np.random.default_rng(tseed))
        net = T.train_intrinsic(paths, c, ex.H2, ex.T2, seed=tseed); del paths
        sampler = lambda n, s: T.sample_intrinsic(net, c, ex.H2, ex.K2, ex.T2, n, np.random.default_rng(s))
    sets = [sampler(4096, s) for s in sseeds]
    out["rows"] = [T.evaluate(S, Xte, centres, W, bw) for S in sets]
    np.savez_compressed(tag + "_samples.npz", *sets)
    json.dump(out, open(tag + ".json", "w"), indent=1)
    a = np.array([[r["mmd2"], r["leaf_tv"], r["frac_div"]] for r in out["rows"]])
    print(f"[tree fine {model} seed{idx}] MMD2 {a[:,0].mean():.5f}+-{a[:,0].std():.5f}  TV {a[:,1].mean():.3f}  div {a[:,2].mean():.4f}", flush=True)

def assemble():
    res = {}
    for f in sorted(glob.glob("tree_fine_c*_s[0-9].json") + glob.glob("tree_fine_tangent_s[0-9].json")):
        d = json.load(open(f)); res.setdefault(d["model"], {})[str(d["train_seed"])] = d
    summary = {}
    for model, runs in res.items():
        A = np.array([[r["mmd2"], r["leaf_tv"], r["frac_div"]] for d in runs.values() for r in d["rows"]])
        summary[model] = {"n_train": len(runs), "mean": A.mean(0).tolist(), "std_all": A.std(0, ddof=1).tolist()}
        print(f"[tree fine {model}] runs={len(runs)} MMD2 {A[:,0].mean():.5f}+-{A[:,0].std(ddof=1):.5f} TV {A[:,1].mean():.3f}+-{A[:,1].std(ddof=1):.3f} div {A[:,2].mean():.4f}")
    res["summary"] = summary; json.dump(res, open("tree_fine_all.json", "w"), indent=1)

if __name__ == "__main__":
    ex.self_test()
    stage = sys.argv[1]
    if stage == "assemble": assemble()
    else: run(stage, int(sys.argv[2]))
