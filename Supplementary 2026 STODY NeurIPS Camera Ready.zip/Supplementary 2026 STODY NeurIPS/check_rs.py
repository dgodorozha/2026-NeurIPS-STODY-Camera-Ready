# Independent check of lambda^[1], lambda^[2] via the ground state transform:
# -L^(1) on L^2(rho ds) is unitarily equivalent to H = -d^2/ds^2 + a^2/4 + a'/2 + (n-1)/sinh^2 s on L^2(ds),
# which is symmetric, so textbook Rayleigh-Schrodinger theory applies with the plain inner product.
import sympy as sp
x, y, c, n, eps = sp.symbols('x y c n epsilon', positive=True)
# Laurent series (SymPy can do these with numeric coefficients)
coth_ser = sp.series(sp.coth(x), x, 0, 8).removeO()
csch2_ser = sp.series(1/sp.sinh(x)**2, x, 0, 8).removeO()
print("coth x  =", coth_ser); print("1/sinh^2 x =", csch2_ser)
a  = (n-1)*coth_ser - c*x
V  = sp.expand(a**2/4 + sp.diff(a, x)/2 + (n-1)*csch2_ser)      # a' computed from the series, consistent to this order
Vy = sp.expand(V.subs(x, y*eps).subs(c, 1/eps**2))               # eps = 1/sqrt(c)
V0 = Vy.coeff(eps, -2); V1 = Vy.coeff(eps, 0); V2 = Vy.coeff(eps, 2)
print("V0 (coefficient of c)   :", sp.factor(V0))
print("V1 (coefficient of 1)   :", sp.factor(V1))
print("V2 (coefficient of 1/c) :", sp.factor(V2))
# u0 = y^((n+1)/2) exp(-y^2/4); E[y^(2m)] under u0^2 dy
M = lambda m: 2**((m-1)/sp.Integer(2))*sp.gamma((m+1)/sp.Integer(2))
E = lambda m: sp.gammasimp(M(n+1+2*m)/M(n+1))
Ey2, Ey4 = sp.factor(E(1)), sp.factor(E(2)); print("E[y^2] =", Ey2, "  E[y^4] =", Ey4)
expect = lambda P: sum(coef*{0:1, 2:Ey2, 4:Ey4}[deg] for (deg,), coef in sp.Poly(P, y).terms())
lam1 = sp.factor(sp.simplify(expect(V1)))
b = sp.Poly(V1, y).coeff_monomial(y**2)                           # V1 - <V1> = b (y^2 - E y^2), proportional to u1, gap 2
lam2 = sp.factor(sp.simplify(expect(V2) - b**2*(Ey4 - Ey2**2)/2))
print("lambda^[1] =", lam1, "   expected -2(n-1)/3")
print("lambda^[2] =", lam2, "   expected 4(n-1)(n+2)/45  ->  equal:", sp.simplify(lam2 - sp.Rational(4,45)*(n-1)*(n+2)) == 0)
