#!/bin/bash
cd "$(dirname "$0")"
python3 experiments_cr.py A prior
for m in c2.0 c0.25 tangent c0.5 c1.0 c4.0; do
  for s in 0 1 2; do python3 experiments_cr.py A $m $s; done
done
python3 experiments_cr.py A assemble
echo ALL_A_DONE
