import numpy as np
from scipy import sparse
from scipy.sparse.linalg import eigsh
from math import gamma
# generalised-n FEM gap from verify2.py (kmode=1 first harmonic, kmode=0 radial)
def gap(c, n, N=12000, kmode=1):
    R = max(9.0, (n - 1) / c + 10.0 / np.sqrt(c))
    r = np.linspace(0.0, R, N + 1)[1:]
    lw = lambda z: -c * z**2 / 2 + (n - 1) * np.log(np.sinh(np.clip(z, 1e-300, None)))
    sh = np.max(lw(r)); W = lambda z: np.exp(lw(np.clip(z, 1e-14, None)) - sh)
    if kmode:
        a_ = np.concatenate([[0.0], r[:-1]]); b_ = r.copy()
        iA, iB = np.arange(-1, N - 1), np.arange(0, N)
    else:
        a_, b_ = r[:-1], r[1:]; iA, iB = np.arange(N - 1), np.arange(1, N)
    L = b_ - a_
    dA, dB, oA, oB = np.zeros(N), np.zeros(N), np.zeros(N - 1), np.zeros(N - 1)
    for t in (0.5 - np.sqrt(3)/6, 0.5 + np.sqrt(3)/6):
        q = a_ + t * L; wgt = 0.5 * L * W(q)
        V = (n - 1) / np.sinh(np.clip(q, 1e-14, None))**2 if kmode else 0.0
        pA, pB = (b_ - q) / L, (q - a_) / L; s = wgt / L**2
        m = iA >= 0
        np.add.at(dA, iA[m], (s + wgt*V*pA*pA)[m]); np.add.at(dB, iA[m], (wgt*pA*pA)[m])
        np.add.at(dA, iB, s + wgt*V*pB*pB);        np.add.at(dB, iB, wgt*pB*pB)
        np.add.at(oA, iA[m], (-s + wgt*V*pA*pB)[m]); np.add.at(oB, iA[m], (wgt*pA*pB)[m])
    A = sparse.diags([oA, dA, oA], [-1, 0, 1], format="csc")
    B = sparse.diags([oB, dB, oB], [-1, 0, 1], format="csc")
    nev = 2 if kmode == 0 else 1
    v = eigsh(A, k=nev, M=B, sigma=0.0 if kmode else -1e-9, which="LM", return_eigenvectors=False)
    return float(np.sort(v)[-1])
def var_r(c, n):
    R = max(9.0, (n-1)/c + 10/np.sqrt(c)); r = np.linspace(1e-9, R, 400001)
    lw = -c*r**2/2 + (n-1)*np.log(np.sinh(r)); w = np.exp(lw - lw.max())
    Z = np.trapezoid(w, r); m1 = np.trapezoid(r*w, r)/Z; m2 = np.trapezoid(r**2*w, r)/Z
    return m2 - m1**2
vn = lambda n: float(n - 2*(gamma((n+1)/2)/gamma(n/2))**2)
print("  n     c    lam1(k=1)   lam1(k=0)   k0-k1-c     1/Var-c   old 1/Var   c-(n-1)  (1/vn-1)c")
for n in [2,3,4,5]:
    for c in [0.1, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0]:
        if n>=3 and c<0.25: continue
        l1 = gap(c,n,kmode=1); l0 = gap(c,n,kmode=0); v = var_r(c,n)
        print(f"{n:3d} {c:6.2f}  {l1:10.5f}  {l0:10.5f}  {l0-l1-c:+.2e}  {1/v-c:9.4f}  {1/v:9.4f}  {c-(n-1):8.3f}  {(1/vn(n)-1)*c:8.3f}   ok={l1 <= 1/v - c + 1e-6}")
