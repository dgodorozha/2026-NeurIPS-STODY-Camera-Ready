"""Verification of Theorem 3.5 (leading order at strong confinement).

Claim.  With x_1 = sinh(r) theta_1 the first ambient coordinate on H^n,
    Delta x_1 = n x_1,   grad r . grad x_1 = x_1 coth r,
so the Rayleigh quotient of x_1 in L^2(mu_c) is
    Q_n(c) = c E[r coth r sinh^2 r] / E[sinh^2 r] - n,
expectations under the radial law rho_c(r) ∝ e^{-c r^2/2} sinh^{n-1} r.  Hence
lambda_1(c) <= Q_n(c), and Q_n(c) - c -> -2(n-1)/3 as c -> infinity.
"""
import numpy as np, sympy as sp, mpmath as mp
from scipy import sparse
from scipy.sparse.linalg import eigsh
mp.mp.dps = 30
ok = lambda b: "PASS" if b else "**FAIL**"
print("=" * 76)

# ---- (1) Laplacian identity, symbolically, in geodesic polar coordinates
print("T1  Delta_{H^n}(sinh r * theta_1) = n sinh r * theta_1  (theta_1 a first harmonic)")
r = sp.symbols("r", positive=True)
for n in [2, 3, 4, 5]:
    # radial part of Delta on functions eta(r) psi(theta) with Delta_S psi = -(n-1) psi
    eta = sp.sinh(r)
    lhs = sp.diff(eta, r, 2) + (n - 1) * sp.coth(r) * sp.diff(eta, r) - (n - 1) * eta / sp.sinh(r) ** 2
    print(f"    n={n}: simplify(Delta eta - n eta) = {sp.simplify(lhs - n * eta)}   {ok(sp.simplify(lhs - n*eta) == 0)}")

# ---- (2) elementary inequality r coth r <= 1 + r^2/3
print("\nT2  r coth r <= 1 + r^2/3 on [0, inf)")
g = (1 + r**2 / 3) * sp.sinh(r) - r * sp.cosh(r)
gp = sp.simplify(sp.diff(g, r) - r * (r * sp.cosh(r) - sp.sinh(r)) / 3)
print(f"    g'(r) - (r/3)(r cosh r - sinh r) simplifies to {gp}   {ok(gp == 0)}")
xs = np.linspace(1e-6, 40, 400000)
viol = np.max(xs / np.tanh(xs) - 1 - xs**2 / 3)
print(f"    numerical max violation on (0,40]: {viol:+.2e}   {ok(viol <= 1e-12)}")

# ---- (3) Q_n(c) by quadrature, and its limit
def radial_moments(c, n):
    lw = lambda s: -c * s**2 / 2 + (n - 1) * mp.log(mp.sinh(s)) if s > 0 else mp.mpf(-1e9)
    R = max(12.0 / mp.sqrt(c) + (n - 1) / c + 2, 4.0)
    f = lambda s, h: mp.e**(-c * s**2 / 2) * mp.sinh(s)**(n - 1) * h(s)
    Z  = mp.quad(lambda s: f(s, lambda s: 1), [0, R])
    A  = mp.quad(lambda s: f(s, lambda s: mp.sinh(s)**2), [0, R]) / Z
    B  = mp.quad(lambda s: f(s, lambda s: s * mp.coth(s) * mp.sinh(s)**2), [0, R]) / Z
    C  = mp.quad(lambda s: f(s, lambda s: s**2 * mp.sinh(s)**2), [0, R]) / Z
    return float(A), float(B), float(C)

def Q(c, n):
    A, B, C = radial_moments(c, n)
    return c * B / A - n, c * C / A

print("\nT3  Q_n(c) - c  ->  -2(n-1)/3 ;  c E[r^2 sinh^2]/E[sinh^2] -> n+2")
for n in [2, 3, 5]:
    print(f"    n={n}  target Q-c -> {-2*(n-1)/3:+.4f},  moment ratio -> {n+2}")
    for c in [2, 4, 8, 32, 128, 512, 2048]:
        q, m = Q(c, n)
        print(f"      c={c:5d}:  Q-c = {q-c:+.5f}    c E[r^2 sh^2]/E[sh^2] = {m:.5f}")

# ---- (4) FEM lambda_1 (k=1 mode) and the bound, incl. attainment of the constant
def gap(c, n, N=16000, kmode=1):
    R = float(max((n - 1) / c + 12.0 / np.sqrt(c), 2.0))
    r_ = np.linspace(0.0, R, N + 1)[1:]
    lw = lambda z: -c * z**2 / 2 + (n - 1) * np.log(np.sinh(np.clip(z, 1e-300, None)))
    sh = np.max(lw(r_)); W = lambda z: np.exp(lw(np.clip(z, 1e-14, None)) - sh)
    if kmode:
        a_ = np.concatenate([[0.0], r_[:-1]]); b_ = r_.copy()
        iA, iB = np.arange(-1, N - 1), np.arange(0, N)
    else:
        a_, b_ = r_[:-1], r_[1:]; iA, iB = np.arange(N - 1), np.arange(1, N)
    L = b_ - a_
    dA, dB, oA, oB = np.zeros(N), np.zeros(N), np.zeros(N - 1), np.zeros(N - 1)
    for t in (0.5 - np.sqrt(3) / 6, 0.5 + np.sqrt(3) / 6):
        q = a_ + t * L; wgt = 0.5 * L * W(q)
        V = (n - 1) / np.sinh(np.clip(q, 1e-14, None))**2 if kmode else 0.0
        pA, pB = (b_ - q) / L, (q - a_) / L; s = wgt / L**2
        m = iA >= 0
        np.add.at(dA, iA[m], (s + wgt * V * pA * pA)[m]); np.add.at(dB, iA[m], (wgt * pA * pA)[m])
        np.add.at(dA, iB, s + wgt * V * pB * pB);        np.add.at(dB, iB, wgt * pB * pB)
        np.add.at(oA, iA[m], (-s + wgt * V * pA * pB)[m]); np.add.at(oB, iA[m], (wgt * pA * pB)[m])
    A = sparse.diags([oA, dA, oA], [-1, 0, 1], format="csc")
    B = sparse.diags([oB, dB, oB], [-1, 0, 1], format="csc")
    nev = 2 if kmode == 0 else 1
    v = eigsh(A, k=nev, M=B, sigma=0.0 if kmode else -1e-9, which="LM", return_eigenvectors=False)
    return float(np.sort(v)[-1])

print("\nT4  lambda_1 (FEM, k=1 and k=0 modes) against the bound Q_n(c) and the constant")
allok = True
for n in [2, 3]:
    print(f"    n={n}:   c     lam1(k=1)   lam1(k=0)    Q_n(c)    lam1-c    Q-c    -2(n-1)/3={-2*(n-1)/3:+.3f}")
    for c in [1.0, 2.0, 4.0, 8.0, 16.0, 32.0, 64.0, 128.0, 256.0]:
        if c < n - 1: continue
        l1, l0 = gap(c, n, kmode=1), gap(c, n, kmode=0)
        q, _ = Q(c, n)
        lam = min(l1, l0)
        allok &= (lam <= q + 1e-6)
        print(f"         {c:6.1f}   {l1:9.4f}   {l0:9.4f}   {q:9.4f}   {lam-c:+.4f}   {q-c:+.4f}")
print(f"    lambda_1 <= Q_n(c) at every tested point   {ok(allok)}")

# grid convergence at the largest c
print("\nT5  grid convergence of the FEM at c=256, n=2:",
      f"N=16000 {gap(256.0, 2, N=16000):.5f}   N=32000 {gap(256.0, 2, N=32000):.5f}")
print("=" * 76)

# ---- (6) the closed form 1 + n/E[sinh^2 r] must equal the r coth r form (integration by parts identity)
print("\nT6  Q_n(c) = c E[r coth r sh^2]/E[sh^2] - n  equals  1 + n/E[sinh^2 r]")
worst = 0.0
for n in [2, 3, 5]:
    for c in [0.5, 1.0, 2.0, 8.0, 64.0]:
        A, B, C = radial_moments(c, n)
        q1 = c * B / A - n; q2 = 1 + n / A
        worst = max(worst, abs(q1 - q2) / abs(q2))
print(f"    max relative discrepancy over 15 (n,c) pairs: {worst:.1e}   {ok(worst < 1e-9)}")

# ---- (7) table for the paper: FEM lambda_1, bound, differences
print("\nT7  table for the paper (n=2 and n=3)")
import json
tab = {}
for n in [2, 3]:
    tab[n] = []
    for c in [2.0, 4.0, 8.0, 32.0, 128.0, 256.0]:
        l1 = gap(c, n, kmode=1); A, _, _ = radial_moments(c, n); bnd = 1 + n / A
        tab[n].append({"c": c, "lam1": l1, "bound": bnd, "BE": c - (n - 1)})
        print(f"    n={n} c={c:6.1f}: BE {c-(n-1):8.3f}  lam1 {l1:9.4f}  bound {bnd:9.4f}  "
              f"lam1-c {l1-c:+.4f}  bound-c {bnd-c:+.4f}  target {-2*(n-1)/3:+.4f}")
json.dump(tab, open("largec_table.json", "w"), indent=1)
print("    written largec_table.json")
