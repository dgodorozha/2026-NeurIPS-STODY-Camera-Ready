#!/bin/bash
cd "$(dirname "$0")"
python3 experiments_h3.py mix
python3 experiments_h3.py prior
echo H3A_DONE
