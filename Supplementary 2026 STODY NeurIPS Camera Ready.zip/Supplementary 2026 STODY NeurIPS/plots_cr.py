"""Figures 3 to 5 of the paper (fig_sweep.pdf, fig_h3.pdf, fig_samples_B.pdf) and three
diagnostic figures that are not in the paper (diag_rates.pdf: simulated rates on H^2 and H^3
against the finite element gaps; diag_relax.pdf: R(t) on H^2 and H^3; diag_samples_A.pdf:
hierarchy A samples of the first repeated training seed).  Figures 1 and 2 are made by plots.py,
Figures 6 to 8 by plots_scale.py and plots_followup.py.  Reads only result files produced by
experiments.py, experiments_cr.py, experiments_h3.py and fem_lambda.py."""
import json, glob
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "pdf.fonttype": 42, "ps.fonttype": 42,  # embed TrueType, not Type 3 (NeurIPS font requirement)
    "font.family": "serif", "font.size": 8.5, "axes.labelsize": 9, "axes.titlesize": 9,
    "legend.fontsize": 6.6, "xtick.labelsize": 8, "ytick.labelsize": 8, "figure.dpi": 200,
    "axes.linewidth": 0.7, "mathtext.fontset": "cm",
})
VIR = plt.cm.viridis

E1 = json.load(open("r1.json")); E3 = json.load(open("h3_mix.json")); FEM = json.load(open("fem.json"))
t2, t3 = np.array(E1["t"]), np.array(E3["t"])

def fit(R, t):
    R = np.array(R); m = (R >= 0.05) & (R <= 0.7) & (t > 0.05)
    if m.sum() >= 5: return -np.polyfit(t[m], np.log(R[m]), 1)[0], True
    m2 = t >= t[-1] / 2; return -np.polyfit(t[m2], np.log(np.maximum(R[m2], 1e-12)), 1)[0], False

rates2 = {c: fit(E1["R"][str(c)], t2) for c in E1["c"]}
rates3 = {c: tuple(E3["rate"][str(c)]) for c in E3["c"]}

def bound(c, n):          # 1 + n / E_{mu_c}[sinh^2 r] by quadrature
    r = np.linspace(1e-6, max(4.0, (n - 1) / c + 14 / np.sqrt(c)), 200001)
    lw = -c * r**2 / 2 + (n - 1) * np.log(np.sinh(r)); w = np.exp(lw - lw.max())
    return 1 + n / (np.trapezoid(np.sinh(r)**2 * w, r) / np.trapezoid(w, r))

# ------------------------------------------------------------------ diagnostic: rates against the gaps
fig, ax = plt.subplots(1, 2, figsize=(5.5, 2.3))
for a, n, rates, cs_all in [(ax[0], 2, rates2, E1["c"]), (ax[1], 3, rates3, E3["c"])]:
    grid = [(r["c"], r["lam1"]) for r in FEM["grid"][str(n)] if r["lam1"] > 1e-7]
    gc, gl = np.array(grid).T
    a.loglog(gc, gl, "-", color="0.15", lw=1.1, label=r"$\lambda_1(c)$ (finite elements)")
    cg = np.geomspace(n - 1 + 0.02, 10, 100)
    a.loglog(cg, cg - (n - 1), "-", color="#CC3034", lw=1.0, label=r"$c-(n-1)$ (BE)")
    cb = np.geomspace(0.5, 10, 40)
    a.loglog(cb, [bound(c, n) for c in cb], ":", color="#CC3034", lw=1.1, label=r"$1+n/\mathbb{E}\sinh^2 r$")
    if n == 2:
        cs_small = np.geomspace(0.04, 1.0, 100)
        a.loglog(cs_small, np.sqrt(cs_small) * np.exp(-1 / (2 * cs_small)), "--", color="0.35", lw=1.0,
                 label=r"$\sqrt{c}\,e^{-1/(2c)}$")
    cols = VIR(np.linspace(0.05, 0.92, len(cs_all)))
    for c, col in zip(cs_all, cols):
        v, ok = rates[c]
        if ok: a.plot([c], [v], "o", color=col, ms=5.5, zorder=5, mec="0.25", mew=0.5)
        else:  a.plot([c], [v], "v", color=col, ms=6.5, zorder=5, mfc="none", mew=1.1)
    a.plot([], [], "o", color="0.5", ms=5, mec="0.25", mew=0.5, label="measured rate")
    a.plot([], [], "v", color="0.35", ms=6, mfc="none", mew=1.1, label="upper estimate")
    a.axvline(n - 1, color="0.5", lw=0.6, ls=":")
    a.set_xlabel("$c$"); a.set_ylabel("rate")
    a.set_title(f"({'ab'[n-2]}) $\\mathbb{{H}}^{n}$, threshold $c=n-1={n-1}$", fontsize=8.5)
a0 = ax[0]; a0.set_xlim(0.035, 10); a0.set_ylim(3e-3, 3e1)
a1 = ax[1]; a1.set_xlim(0.08, 12); a1.set_ylim(3e-4, 3e1)
a0.legend(frameon=False, loc="upper left", handlelength=1.3, labelspacing=0.3, borderaxespad=0.25)
a1.legend(frameon=False, loc="upper left", handlelength=1.3, labelspacing=0.3, borderaxespad=0.25)
fig.tight_layout(pad=0.4); fig.savefig("diag_rates.pdf", bbox_inches="tight"); print("diag_rates.pdf")

# ------------------------------------------------------------------ diagnostic: R(t)
fig, ax = plt.subplots(1, 2, figsize=(5.5, 2.2))
for a, n, E, tt, cs_all in [(ax[0], 2, E1, t2, E1["c"]), (ax[1], 3, E3, t3, E3["c"])]:
    cols = VIR(np.linspace(0.05, 0.92, len(cs_all)))
    for c, col in zip(cs_all, cols):
        a.semilogy(tt, E["R"][str(c)], color=col, lw=1.0, label=f"${c}$")
    floor = 1 / np.sqrt(E["N"])
    a.axhline(floor, color="0.55", lw=0.6, ls=":")
    a.set_xlim(0, 6); a.set_ylim(3.5e-3, 1.45); a.set_xlabel("$t$")
    a.set_ylabel(r"$R(t)$")
    a.legend(ncol=7, loc="lower center", bbox_to_anchor=(0.5, 1.0), frameon=False, handlelength=0.7,
             columnspacing=0.4, handletextpad=0.3, fontsize=6.2, borderpad=0.1, borderaxespad=0.0, title="$c=$", title_fontsize=6.2)
    a.set_title(f"({'ab'[n-2]}) $\\mathbb{{H}}^{n}$", fontsize=8.5, pad=15)
fig.tight_layout(pad=0.4); fig.savefig("diag_relax.pdf", bbox_inches="tight"); print("diag_relax.pdf")

# ------------------------------------------------------------------ disks
def disks(files, titles, out):
    fig2, axs = plt.subplots(1, 4, figsize=(5.5, 1.55))
    th = np.linspace(0, 2 * np.pi, 200)
    for a, f, ttl in zip(axs, files, titles):
        P = np.array(json.load(open(f)))
        a.plot(np.cos(th), np.sin(th), "-", color="0.75", lw=0.7)
        a.scatter(P[:, 0], P[:, 1], s=0.5, c="#1f4e79", alpha=0.5, linewidths=0)
        a.set_xlim(-1.02, 1.02); a.set_ylim(-1.02, 1.02); a.set_aspect("equal"); a.axis("off")
        a.set_title(ttl, fontsize=7.3)
    fig2.tight_layout(pad=0.25); fig2.savefig(out, bbox_inches="tight"); print(out)

for hier, out in [("A", "diag_samples_A.pdf"), ("B", "fig_samples_B.pdf")]:
    files = [f"cr_samples_{hier}_data.json", f"cr_samples_{hier}_c2.0.json", f"cr_samples_{hier}_c0.25.json", f"cr_samples_{hier}_tangent.json"]
    if all(glob.glob(f) for f in files):
        disks(files, ["data", "intrinsic, $c=2.0>n-1$", "intrinsic, $c=0.25<n-1$", "tangent (wrapped)"], out)
# hierarchies C and W: fig_samples_C.pdf and fig_samples_W.pdf are made by plots_scale.py

# ------------------------------------------------------------------ sweep: generation error against c
def summary(path):
    try: return json.load(open(path))["summary"], json.load(open(path))["prior"]
    except FileNotFoundError: return None, None
SA, PA = summary("cr_A_all.json"); SB, PB = summary("cr_B_all.json"); S3, P3 = summary("h3_all.json")
if SA and S3:
    fig, ax = plt.subplots(1, 2, figsize=(5.5, 2.45))
    def panel(a, S, P, cs, label, col, marker):
        m = np.array([S[f"c{c}"]["mean"][0] for c in cs]); s = np.array([S[f"c{c}"]["std_all"][0] for c in cs])
        a.errorbar(cs, m, yerr=s, fmt=marker + "-", color=col, ms=4.5, lw=1.0, capsize=2, label=label + ": generation")
        pm = np.array([P[f"prior_mismatch_c{c}"] for c in cs]); keep = pm > 1e-4
        a.plot(np.array(cs)[keep], pm[keep], marker, color=col, ms=6, mfc="none", mew=1.0, ls=":", lw=0.9,
               label=label + ": prior mismatch")
        if "tangent" in S:
            a.axhline(S["tangent"]["mean"][0], color=col, lw=0.8, ls="--", label=label + ": wrapped baseline")
    cs2 = [0.25, 0.5, 1.0, 2.0, 4.0]
    panel(ax[0], SA, PA, cs2, "A", "#1f4e79", "o")
    if SB: panel(ax[0], SB, PB, cs2, "B", "#CC3034", "s")
    SC, PC = summary("tree_all.json"); SW, PW = summary("wn_all.json")
    if SC: panel(ax[0], SC, PC, cs2, "C", "#2a7f62", "^")
    if SW: panel(ax[0], SW, PW, cs2, "W", "#8a6d1f", "D")
    ax[0].axvline(1.0, color="0.5", lw=0.6, ls=":"); ax[0].set_title(r"(a) $\mathbb{H}^2$, hierarchies A, B, C and W", fontsize=8.5)
    ax[0].set_xlim(0.19, 5.3)
    cs3 = [0.5, 1.0, 2.0, 4.0, 8.0]
    panel(ax[1], S3, P3, cs3, r"$\mathbb{H}^3$", "#1f4e79", "o")
    ax[1].axvline(2.0, color="0.5", lw=0.6, ls=":"); ax[1].set_title(r"(b) $\mathbb{H}^3$", fontsize=8.5)
    ax[1].set_xlim(0.38, 10.5)
    for a, cs in [(ax[0], cs2), (ax[1], cs3)]:
        a.set_xscale("log"); a.set_yscale("log"); a.set_xlabel("$c$"); a.set_ylabel(r"MMD$^2$")
        a.xaxis.set_major_locator(matplotlib.ticker.FixedLocator(cs))
        a.xaxis.set_major_formatter(matplotlib.ticker.FixedFormatter([str(c) for c in cs]))
        a.xaxis.set_minor_locator(matplotlib.ticker.NullLocator())
        a.set_ylim(5e-5, 6e-2)
    h0, l0 = ax[0].get_legend_handles_labels(); h1, l1 = ax[1].get_legend_handles_labels()
    fig.legend(h0 + h1, l0 + l1, frameon=False, loc="lower center", ncol=4, fontsize=6.0,
               handlelength=1.5, columnspacing=1.0, bbox_to_anchor=(0.5, -0.03))
    fig.tight_layout(pad=0.4, rect=(0, 0.2, 1, 1)); fig.savefig("fig_sweep.pdf", bbox_inches="tight"); print("fig_sweep.pdf")

# ------------------------------------------------------------------ H^3 samples: direction on S^2 as longitude/latitude, colour = radius
files = ["h3_samples_data.json", "h3_samples_c4.0.json", "h3_samples_c1.0.json", "h3_samples_tangent.json"]
if all(glob.glob(f) for f in files):
    fig3, axs = plt.subplots(1, 4, figsize=(5.5, 1.5))
    for a, f, ttl in zip(axs, files, ["data", "intrinsic, $c=4>n-1$", "intrinsic, $c=1<n-1$", "tangent (wrapped)"]):
        d = json.load(open(f)); D = np.array(d["dir"]); r = np.array(d["r"])
        lon = np.arctan2(D[:, 1], D[:, 0]); lat = np.arcsin(np.clip(D[:, 2], -1, 1))
        a.scatter(lon, lat, s=0.6, c=np.clip(r, 2.5, 4.5), cmap="viridis", alpha=0.6, linewidths=0, vmin=2.5, vmax=4.5)
        a.set_xlim(-np.pi, np.pi); a.set_ylim(-np.pi / 2, np.pi / 2)
        a.set_xticks([]); a.set_yticks([]); a.set_title(ttl, fontsize=7.3)
        for s in a.spines.values(): s.set_linewidth(0.5)
    fig3.tight_layout(pad=0.25); fig3.savefig("fig_h3.pdf", bbox_inches="tight"); print("fig_h3.pdf")
