# Experiment 1 on H^n for n = 2, 3, 4: polar Euler-Maruyama simulation of the confined diffusion,
#   dr = ((n-1) coth r - c r) dt + sqrt(2) dW,   dtheta = (sqrt(2)/sinh r) dB^{S^{n-1}} (geodesic random walk on the sphere),
# compared with the finite element sector gaps.  Two observables, two predictions of Proposition 3.3:
#   angular  E[theta_1(X_t)]        decays at lambda_1(c) = lambda^(1)(c)   (first harmonic sector)
#   radial   E[r_t] - E_mu[r]       decays at lambda^(0)(c) = lambda_1(c) + c (radial sector)
# Rates are least squares slopes of the log signal on fixed windows, over independent replicates (mean +- sd).
# Initial conditions: angular run = radial equilibrium law with the direction concentrated near e_1; radial run = the
# radial equilibrium law shifted outwards by 0.3 (a delta initial radius excites transient modes of opposite sign and
# biases the fitted radial rate low by up to 5% at large c; the shifted equilibrium law does not).
# Usage:  python exp1_highdim.py [--N 200000] [--reps 4] [--n 2 3 4] [--angular-from exp1_highdim.json]
#         (needs check_largec.py in the same folder; --angular-from reuses angular rates from an earlier run)
import numpy as np, json, time, argparse
from check_largec import gap as gap_ang     # first harmonic sector, generic n
from scipy import sparse
from scipy.sparse.linalg import eigsh

def gap_rad(c, n, N=12000):
    """Lowest nonzero eigenvalue of the radial sector (same FEM as check_intertwine.py, kmode=0)."""
    R = max(9.0, (n - 1) / c + 10.0 / np.sqrt(c)); r = np.linspace(0.0, R, N + 1)[1:]
    lw = lambda z: -c * z**2 / 2 + (n - 1) * np.log(np.sinh(np.clip(z, 1e-300, None)))
    sh = np.max(lw(r)); W = lambda z: np.exp(lw(np.clip(z, 1e-14, None)) - sh)
    a_, b_ = r[:-1], r[1:]; iA, iB = np.arange(N - 1), np.arange(1, N); L = b_ - a_
    dA, dB, oA, oB = np.zeros(N), np.zeros(N), np.zeros(N - 1), np.zeros(N - 1)
    for t in (0.5 - np.sqrt(3)/6, 0.5 + np.sqrt(3)/6):
        q = a_ + t * L; wgt = 0.5 * L * W(q); pA, pB = (b_ - q) / L, (q - a_) / L; s = wgt / L**2
        np.add.at(dA, iA, s); np.add.at(dB, iA, wgt*pA*pA); np.add.at(dA, iB, s); np.add.at(dB, iB, wgt*pB*pB)
        np.add.at(oA, iA, -s); np.add.at(oB, iA, wgt*pA*pB)
    A = sparse.diags([oA, dA, oA], [-1, 0, 1], format="csc"); B = sparse.diags([oB, dB, oB], [-1, 0, 1], format="csc")
    v = eigsh(A, k=2, M=B, sigma=-1e-9, which="LM", return_eigenvectors=False)
    return float(np.sort(v)[-1])

def radial_law(c, n):
    R = max(9.0, (n-1)/c + 10/np.sqrt(c)); r = np.linspace(1e-9, R, 400001)
    lw = -c*r**2/2 + (n-1)*np.log(np.sinh(r)); w = np.exp(lw - lw.max())
    cdf = np.cumsum(w); cdf /= cdf[-1]
    return r, cdf, float(np.trapezoid(r*w, r)/np.trapezoid(w, r))

def run(c, n, r_init, N, h, T, rg, ang_spread=0.2):
    K = int(round(T/h)); ts = np.arange(K+1)*h
    r = np.abs(np.asarray(r_init, dtype=float) if np.ndim(r_init) else r_init + 0.2*rg.standard_normal(N))
    th = np.zeros((N, n)); th[:, 0] = 1.0
    xi = ang_spread*rg.standard_normal((N, n)); xi[:, 0] = 0.0; th += xi; th /= np.linalg.norm(th, axis=1, keepdims=True)
    m1 = np.empty(K+1); Er = np.empty(K+1)
    for k in range(K+1):
        m1[k] = th[:, 0].mean(); Er[k] = r.mean()
        if k == K: break
        drift = np.clip((n-1)/np.tanh(np.maximum(r, 1e-9)) - c*r, -80.0, 80.0)
        sig = np.sqrt(2*h)/np.maximum(np.sinh(r), 1e-9)
        r = np.abs(r + drift*h + np.sqrt(2*h)*rg.standard_normal(N))
        xi = rg.standard_normal((N, n)); xi -= (xi*th).sum(1, keepdims=True)*th
        nx = np.linalg.norm(xi, axis=1); a = sig*nx; u = xi/np.maximum(nx, 1e-300)[:, None]
        th = np.cos(a)[:, None]*th + np.sin(a)[:, None]*u; th /= np.linalg.norm(th, axis=1, keepdims=True)
    return ts, m1, Er

def fit_rate(ts, sig, lo, hi):
    m = (sig <= hi) & (sig >= lo)
    if m.sum() < 10: return float('nan')
    A = np.vstack([ts[m], np.ones(m.sum())]).T
    return -float(np.linalg.lstsq(A, np.log(sig[m]), rcond=None)[0][0])

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--N", type=int, default=200000); ap.add_argument("--reps", type=int, default=4)
    ap.add_argument("--n", type=int, nargs="+", default=[2, 3, 4]); ap.add_argument("--out", default="exp1_highdim.json")
    ap.add_argument("--angular-from", default=None); ap.add_argument("--shift", type=float, default=0.3)
    args = ap.parse_args()
    grid = {2: [0.5, 1, 2, 4], 3: [1, 2, 4, 8], 4: [1, 2, 4, 8]}
    out = {}; t0 = time.time(); prev = json.load(open(args.angular_from)) if args.angular_from else {}
    print("  n     c   lam1(FEM)  angular rate (mean+-sd)  ratio |  lam1+c   radial rate (mean+-sd)  ratio | (rad-ang)/c")
    for n in args.n:
        for c in grid[n]:
            l1 = gap_ang(c, n, N=12000, R=max(9.0, (n-1)/c + 10/np.sqrt(c))); l0 = gap_rad(c, n)
            rr, cdf, rbar = radial_law(c, n); h = 0.001 if c >= 4 else 0.002
            Ta = min(6.0, 3.6/l1 + 0.5); Tr = min(6.0, 4.5/l0 + 0.5); angs, rads = [], []
            for rep in range(args.reps):
                rg = np.random.default_rng(10000*n + int(1000*c) + rep)
                r_eq = np.interp(rg.uniform(size=args.N), cdf, rr)
                if f"{n},{c}" in prev: angs = list(prev[f"{n},{c}"]["ang"])
                else:
                    ts, m1, _ = run(c, n, r_eq, args.N, h, Ta, rg); angs.append(fit_rate(ts, m1, 0.05, 0.2))
                r_sh = np.interp(rg.uniform(size=args.N), cdf, rr) + args.shift
                ts2, _, Er = run(c, n, r_sh, args.N, h, Tr, rg); rads.append(fit_rate(ts2, np.abs(Er - rbar), 0.02, 0.15))
            angs, rads = np.array(angs), np.array(rads); am, asd, rm, rsd = angs.mean(), angs.std(ddof=1), rads.mean(), rads.std(ddof=1)
            out[f"{n},{c}"] = dict(lam1=l1, lam0=l0, ang=angs.tolist(), rad=rads.tolist(), rbar=rbar, h=h, Ta=Ta, Tr=Tr, N=args.N)
            json.dump(out, open(args.out, "w"), indent=1)
            print(f"{n:3d} {c:6.2f}  {l1:9.4f}  {am:8.4f} +- {asd:6.4f}  {am/l1:5.3f} | {l0:7.4f}  {rm:8.4f} +- {rsd:6.4f}  {rm/l0:5.3f} | {(rm-am)/c:7.3f}   [{time.time()-t0:.0f}s]", flush=True)
