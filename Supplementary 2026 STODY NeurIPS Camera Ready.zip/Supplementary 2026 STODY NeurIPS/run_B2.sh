#!/bin/bash
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
for m in c4.0 c1.0 c0.5 tangent c0.25 c2.0; do
  for s in 2 1 0; do python3 experiments_cr.py B $m $s; done
done
echo B2_DONE
