#!/bin/bash
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
while ! (grep -q TREE1_DONE run_tree1.log && grep -q TREE2_DONE run_tree2.log); do sleep 60; done
( for m in c1.0 c2.0 c0.25 tangent c0.5 c4.0; do for s in 0 1 2; do python3 experiments_wordnet.py $m $s; done; done; echo WN1_DONE ) > run_wn1.log 2>&1 &
( sleep 60; for m in c4.0 c0.5 tangent c0.25 c2.0 c1.0; do for s in 2 1 0; do python3 experiments_wordnet.py $m $s; done; done; echo WN2_DONE ) > run_wn2.log 2>&1 &
wait
python3 experiments_wordnet.py assemble > run_wn_assemble.log 2>&1
echo WN_ALL_DONE >> run_wn_assemble.log
