#!/bin/bash
# two workers: hierarchy A models then H^3 models
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1
(for m in c0.25 c1.0 c4.0; do python3 sampler_caps.py A $m; done; for m in c1.0 c4.0; do python3 sampler_caps.py H3 $m; done) > caps_w1.log 2>&1 &
(for m in c0.5 c2.0; do python3 sampler_caps.py A $m; done; for m in c0.5 c2.0 c8.0; do python3 sampler_caps.py H3 $m; done) > caps_w2.log 2>&1 &
wait
python3 sampler_caps.py assemble > caps_assemble.log 2>&1
