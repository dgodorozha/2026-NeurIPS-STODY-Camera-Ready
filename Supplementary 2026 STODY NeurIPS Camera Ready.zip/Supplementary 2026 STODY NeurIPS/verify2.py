"""Follow-ups: (1) is the V1 failure cancellation in the test or an error in
Lemma B.1? (2) the n=2 branch of beta(n). (3) is the conjectured small-c
exponent sharp, and does beta(n) have the claimed value for n>=3?"""
import numpy as np, mpmath as mp
from scipy import sparse
from scipy.sparse.linalg import eigsh
mp.mp.dps = 60
print("=" * 74)

# (1) Lemma B.1 identity at 60-digit precision -- float64 loses it to cancellation
print("W1  Lemma B.1 identity, float64 vs 60-digit")
for r in [2.0, 5.0, 8.0]:
    th, R = mp.mpf("0.7"), mp.mpf(r)
    x = [mp.sinh(R) * mp.cos(th), mp.sinh(R) * mp.sin(th), mp.cosh(R)]
    w = [mp.mpf("0.3"), mp.mpf("-0.8"), mp.mpf("0.5")]
    L = lambda a, b: a[0]*b[0] + a[1]*b[1] - a[2]*b[2]
    xw = L(x, w); P = [w[i] + xw * x[i] for i in range(3)]
    lhs, rhs = L(P, P), L(w, w) + xw**2
    xf = np.array([float(v) for v in x]); wf = np.array([float(v) for v in w])
    mk = lambda a, b: a[0]*b[0] + a[1]*b[1] - a[2]*b[2]
    Pf = wf + mk(xf, wf) * xf
    print(f"    r={r}: |lhs-rhs| exact {float(abs(lhs-rhs)):.1e}   float64 {abs(mk(Pf,Pf)-float(rhs)):.1e}"
          f"   rel(float64) {abs(mk(Pf,Pf)-float(rhs))/float(abs(rhs)):.1e}")
print("    -> identity is exact; float64 error is cancellation of size ~eps*sinh^4 r,")
print("       which is the phenomenon Lemma B.1 and Section 4.3 are about.")

# (2) the n=2 case of beta(n)
print("\nW2  beta(n) = min{(n-1)^2/2, 2(n-2)} at n=2 gives 0, i.e. vacuous;")
print("    the theorem must state n=2 separately (sqrt(c) e^{-1/(2c)}). Checking the text:")
import subprocess, os
if os.path.exists("main.tex"):
    print(subprocess.run(["grep", "-o", r"n\\ge3[^.]*\|n=2[^.]*", "main.tex"],
                         capture_output=True, text=True).stdout[:400] or "    (grep found nothing)")
else:
    print("    (skipped: the paper source main.tex is not in this folder; the paper states n=2 separately)")

# (3) spectral gap on H^n, lowest angular mode: V = (n-1)/sinh^2 r
def gap(c, n, N=12000, kmode=1):
    R = max(9.0, (n - 1) / c + 10.0 / np.sqrt(c))
    r = np.linspace(0.0, R, N + 1)[1:]
    lw = lambda z: -c * z**2 / 2 + (n - 1) * np.log(np.sinh(np.clip(z, 1e-300, None)))
    sh = np.max(lw(r)); W = lambda z: np.exp(lw(np.clip(z, 1e-14, None)) - sh)
    if kmode:
        a_ = np.concatenate([[0.0], r[:-1]]); b_ = r.copy()
        iA, iB = np.arange(-1, N - 1), np.arange(0, N)
    else:
        a_, b_ = r[:-1], r[1:]; iA, iB = np.arange(N - 1), np.arange(1, N)
    L = b_ - a_
    dA, dB, oA, oB = np.zeros(N), np.zeros(N), np.zeros(N - 1), np.zeros(N - 1)
    for t in (0.5 - np.sqrt(3)/6, 0.5 + np.sqrt(3)/6):
        q = a_ + t * L; wgt = 0.5 * L * W(q)
        V = (n - 1) / np.sinh(np.clip(q, 1e-14, None))**2 if kmode else 0.0
        pA, pB = (b_ - q) / L, (q - a_) / L; s = wgt / L**2
        m = iA >= 0
        np.add.at(dA, iA[m], (s + wgt*V*pA*pA)[m]); np.add.at(dB, iA[m], (wgt*pA*pA)[m])
        np.add.at(dA, iB, s + wgt*V*pB*pB);        np.add.at(dB, iB, wgt*pB*pB)
        np.add.at(oA, iA[m], (-s + wgt*V*pA*pB)[m]); np.add.at(oB, iA[m], (wgt*pA*pB)[m])
    A = sparse.diags([oA, dA, oA], [-1, 0, 1], format="csc")
    B = sparse.diags([oB, dB, oB], [-1, 0, 1], format="csc")
    nev = 2 if kmode == 0 else 1
    v = eigsh(A, k=nev, M=B, sigma=0.0 if kmode else -1e-9, which="LM", return_eigenvectors=False)
    return float(np.sort(v)[-1])

print("\nW3  grid convergence (H^2, k=1)")
for c in [0.1, 0.5]:
    a, b = gap(c, 2, N=8000), gap(c, 2, N=16000)
    print(f"    c={c}: N=8000 {a:.6e}   N=16000 {b:.6e}   rel diff {abs(a-b)/b:.1e}")

print("\nW4  is the conjectured small-c law sharp?  ratio lam1 / (sqrt(c) e^{-1/(2c)}), H^2")
for c in [0.04, 0.05, 0.06, 0.08, 0.10, 0.15, 0.20, 0.25]:
    l = gap(c, 2); env = np.sqrt(c) * np.exp(-1 / (2 * c))
    print(f"    c={c:5.2f}  lam1={l:.6e}  envelope={env:.6e}  ratio={l/env:.4f}")

print("\nW5  exponent beta(n) from a log-linear fit of lam1 against 1/c")
for n, cs in [(2, [0.05, 0.06, 0.08, 0.10, 0.125]),
              (3, [0.10, 0.12, 0.15, 0.18, 0.22]),
              (4, [0.18, 0.22, 0.26, 0.30, 0.35]),
              (5, [0.26, 0.30, 0.35, 0.40, 0.45])]:
    ls = np.array([gap(c, n) for c in cs]); inv = 1.0 / np.array(cs)
    # fit log lam1 = A - beta/c  (n=2 also carries a sqrt(c) prefactor)
    y = np.log(ls) - (0.5 * np.log(cs) if n == 2 else 0.0)
    sl, ic = np.polyfit(inv, y, 1)
    claim = 0.5 if n == 2 else min((n - 1)**2 / 2, 2 * (n - 2))
    print(f"    n={n}: fitted exponent {-sl:7.4f}   claimed beta={claim:5.2f}   "
          f"prefactor e^{ic:+.2f}   {'PASS' if abs(-sl - claim) < 0.12 * max(claim,1) else '**MISMATCH**'}")
print("=" * 74)
