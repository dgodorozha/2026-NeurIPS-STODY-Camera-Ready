"""Sampler caps and step size at fixed trained network (Appendix D, "Sampler caps and step size").

For the first training seed of every intrinsic model on hierarchy A (H^2) and on the H^3
hierarchy, the network is retrained exactly as in experiments_cr.py / experiments_h3.py and then
sampled three times (the same sampling seeds) with the reverse step h = 0.01 (K = 400, the
paper's setting), h = 0.005 (K = 800) and h = 0.0025 (K = 1600).  For every run we record the
fraction of reverse steps at which the geodesic step cap (0.5) and the drift cap (50) engaged,
together with MMD^2 and leaf TV.  The networks are conditioned on t/T, so a finer reverse step
needs no retraining.

usage: python3 sampler_caps.py A <model>      model in c0.25 c0.5 c1.0 c2.0 c4.0
       python3 sampler_caps.py H3 <model>     model in c0.5 c1.0 c2.0 c4.0 c8.0
       python3 sampler_caps.py assemble       -> sampler_caps.json
"""
import json, sys, os, glob
import numpy as np

STEPS = [(0.01, 400), (0.005, 800), (0.0025, 1600)]


def sample_counting(mod, net, c, h, K, T, n, rng_, dmax=50.0, vcap=0.5, kind="A"):
    """Copy of the module's sample_intrinsic that also counts capped steps."""
    x = mod.sample_prior(c, n, rng_)
    n_step = n_drift = 0; total = 0
    for k in range(K, 0, -1):
        if kind == "A":
            F, er, ephi, r = mod.feats(x, np.full(n, k * h), T)
            ab = net.forward(F)
            sres = ab[..., :1] * er + ab[..., 1:] * ephi
        else:
            F, er, th, r = mod.feats(x, np.full(n, k * h), T)
            sres = mod.residual(net.forward(F), er, th)
        s = -(c * r)[..., None] * er + sres
        drift = (c * r)[..., None] * er + 2.0 * s
        nd = np.sqrt(np.maximum(mod.mink(drift, drift), 0.0))
        n_drift += int((nd > dmax).sum())
        drift *= np.minimum(1.0, dmax / np.maximum(nd, 1e-12))[..., None]
        v = drift * h + np.sqrt(2 * h) * mod.tangent_gauss(x, rng_)
        nv = np.sqrt(np.maximum(mod.mink(v, v), 0.0))
        n_step += int((nv > vcap).sum()); total += n
        v *= np.minimum(1.0, vcap / np.maximum(nv, 1e-12))[..., None]
        x = mod.rwall(mod.normalize(mod.expmap(x, v)))
    return x, n_step / total, n_drift / total


def run(kind, model):
    tag = f"caps_{kind}_{model}"
    if os.path.exists(tag + ".json"): print("exists"); return
    c = float(model[1:])
    if kind == "A":
        import experiments as ex, experiments_cr as cr
        Xtr, Xte, centres, W, bw = cr.setup("A")
        tseed, sseeds = cr.seeds("A", model, 0)
        paths = ex.simulate_paths(Xtr, c, ex.H2, ex.K2, np.random.default_rng(tseed))
        net = ex.train_intrinsic(paths, c, ex.H2, ex.T2, seed=tseed); del paths
        T = ex.T2; mod = ex
        evaluate = lambda S: cr.evaluate(S, Xte, centres, W, bw)
    else:
        import experiments_h3 as h3
        Xtr, Xte, centres, W, sig2 = h3.setup()
        tseed = h3.BASE[model]; sseeds = [tseed + o for o in (100, 200, 300)]
        paths = h3.simulate_paths(Xtr, c, h3.H2, h3.K2, np.random.default_rng(tseed))
        net, _ = h3.train_intrinsic(paths, c, h3.H2, h3.T2, seed=tseed); del paths
        T = h3.T2; mod = h3
        evaluate = lambda S: h3.evaluate(S, Xte, centres, W, sig2)
    out = {"kind": kind, "model": model, "c": c, "train_seed": tseed, "rows": []}
    for h, K in STEPS:
        for s in sseeds:
            S, f_step, f_drift = sample_counting(mod, net, c, h, K, T, 4096, np.random.default_rng(s), kind=kind)
            ev = evaluate(S)
            out["rows"].append({"h": h, "K": K, "seed": s, "frac_step_cap": f_step, "frac_drift_cap": f_drift,
                                "mmd2": ev["mmd2"], "leaf_tv": ev["leaf_tv"]})
            print(f"[caps {kind} {model}] h={h} K={K} seed={s}: step cap {100*f_step:.2f}%  drift cap {100*f_drift:.3f}%  "
                  f"MMD2 {ev['mmd2']*1e3:.2f}e-3  leaf TV {ev['leaf_tv']:.3f}", flush=True)
    json.dump(out, open(tag + ".json", "w"), indent=1)


def assemble():
    res = {}
    for f in sorted(glob.glob("caps_*_c*.json")):
        d = json.load(open(f)); rows = d["rows"]
        summ = {}
        for h, K in STEPS:
            R = [r for r in rows if r["h"] == h]
            a = np.array([[r["frac_step_cap"], r["frac_drift_cap"], r["mmd2"], r["leaf_tv"]] for r in R])
            summ[str(h)] = {"K": K, "frac_step_cap": a[:, 0].mean(), "frac_drift_cap": a[:, 1].mean(),
                            "mmd2_mean": a[:, 2].mean(), "mmd2_std": a[:, 2].std(ddof=1), "leaf_tv_mean": a[:, 3].mean()}
        res[f"{d['kind']}_{d['model']}"] = summ
        print(d["kind"], d["model"], {h: (round(100 * v["frac_step_cap"], 2), round(1e3 * v["mmd2_mean"], 2)) for h, v in summ.items()})
    json.dump(res, open("sampler_caps.json", "w"), indent=1)


if __name__ == "__main__":
    if sys.argv[1] == "assemble": assemble()
    else: run(sys.argv[1], sys.argv[2])
