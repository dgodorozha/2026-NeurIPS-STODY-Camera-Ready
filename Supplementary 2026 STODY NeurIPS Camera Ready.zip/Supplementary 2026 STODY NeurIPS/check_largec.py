# Large c check for Remark B.2: lambda_1(c) = c - 2(n-1)/3 + O(1/c) on H^n.
# Same linear FEM as check_intertwine.py, with R shrunk to the scale of the
# eigenfunction for large c and a grid refinement check in the last column.
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import eigsh

def gap(c, n, N=16000, R=None):
    if R is None: R = min(9.0, 1.0 + 12.0 / np.sqrt(c))
    r = np.linspace(0.0, R, N + 1)[1:]
    lw = lambda z: -c * z**2 / 2 + (n - 1) * np.log(np.sinh(np.clip(z, 1e-300, None)))
    sh = np.max(lw(r)); W = lambda z: np.exp(lw(np.clip(z, 1e-14, None)) - sh)
    a_ = np.concatenate([[0.0], r[:-1]]); b_ = r.copy()
    iA, iB = np.arange(-1, N - 1), np.arange(0, N)
    L = b_ - a_
    dA, dB, oA, oB = np.zeros(N), np.zeros(N), np.zeros(N - 1), np.zeros(N - 1)
    for t in (0.5 - np.sqrt(3)/6, 0.5 + np.sqrt(3)/6):
        q = a_ + t * L; wgt = 0.5 * L * W(q)
        V = (n - 1) / np.sinh(np.clip(q, 1e-14, None))**2
        pA, pB = (b_ - q) / L, (q - a_) / L; s = wgt / L**2
        m = iA >= 0
        np.add.at(dA, iA[m], (s + wgt*V*pA*pA)[m]); np.add.at(dB, iA[m], (wgt*pA*pA)[m])
        np.add.at(dA, iB, s + wgt*V*pB*pB);        np.add.at(dB, iB, wgt*pB*pB)
        np.add.at(oA, iA[m], (-s + wgt*V*pA*pB)[m]); np.add.at(oB, iA[m], (wgt*pA*pB)[m])
    A = sparse.diags([oA, dA, oA], [-1, 0, 1], format="csc")
    B = sparse.diags([oB, dB, oB], [-1, 0, 1], format="csc")
    v = eigsh(A, k=1, M=B, sigma=0.0, which="LM", return_eigenvectors=False)
    return float(v[0])

if __name__ == "__main__":
  print("  n      c      lam1       lam1-c    lam1-c+2(n-1)/3   c*(...)   refine   4(n-1)(n+2)/45")
  for n in [2, 3, 4, 5]:
      prev = None
      for c in [4, 8, 16, 32, 64, 128, 256]:
          l = gap(c, n); l2 = gap(c, n, N=32000)
          d = l - c + 2*(n-1)/3
          extra = f"   Richardson(128,256) = {2*c*d - prev:.4f}" if (c == 256 and prev is not None) else ""
          print(f"{n:3d} {c:7.1f}  {l:10.5f}  {l-c:9.4f}  {d:+12.5f}  {c*d:+9.4f}  {abs(l2-l):.1e}   {4*(n-1)*(n+2)/45:.4f}{extra}")
          if c == 128: prev = c*d
